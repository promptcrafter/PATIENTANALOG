/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - Renderer
 * Beautiful visuals for maximum fun!
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

KennethGame.Renderer = (function() {
    
    const CONSTANTS = KennethGame.CONSTANTS;
    
    // DOM references
    let gridContainer = null;
    let connectionsSvg = null;
    let moduleTray = null;
    let gridEffects = null;
    
    // State
    let cellPositions = {};
    let currentDragModule = null;
    
    // ═══════════════════════════════════════════════════════════════════════
    // INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════
    
    function init() {
        gridContainer = document.getElementById('game-grid');
        connectionsSvg = document.getElementById('connections-svg');
        moduleTray = document.getElementById('module-tray');
        gridEffects = document.getElementById('grid-effects');
        
        // Setup drag and drop
        setupDragAndDrop();
        
        console.log('🎨 Renderer initialized!');
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // GRID RENDERING
    // ═══════════════════════════════════════════════════════════════════════
    
    function renderGrid(grid, cols, rows) {
        if (!gridContainer) return;
        
        gridContainer.innerHTML = '';
        gridContainer.style.gridTemplateColumns = `repeat(${cols}, var(--cell-size))`;
        gridContainer.style.gridTemplateRows = `repeat(${rows}, var(--cell-size))`;
        
        cellPositions = {};
        
        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const cell = createCell(col, row, grid[row][col]);
                gridContainer.appendChild(cell);
                
                // Store position for effects
                cellPositions[`${col},${row}`] = cell;
            }
        }
        
        // Clear connections
        if (connectionsSvg) {
            connectionsSvg.innerHTML = '';
        }
    }
    
    function createCell(col, row, module = null) {
        const cell = document.createElement('div');
        cell.className = 'grid-cell';
        cell.dataset.col = col;
        cell.dataset.row = row;
        
        if (module) {
            cell.classList.add('occupied');
            cell.appendChild(createPlacedModule(module));
        }
        
        // Drag and drop events
        cell.addEventListener('dragover', handleDragOver);
        cell.addEventListener('dragleave', handleDragLeave);
        cell.addEventListener('drop', handleDrop);
        
        return cell;
    }
    
    function createPlacedModule(module) {
        const placed = document.createElement('div');
        placed.className = `placed-module tier-${module.tier}`;
        placed.dataset.moduleId = module.id;
        
        // Icon
        const icon = document.createElement('div');
        icon.className = 'module-icon';
        icon.textContent = module.icon;
        placed.appendChild(icon);
        
        // Ports
        Object.entries(module.ports).forEach(([direction, type]) => {
            const port = document.createElement('div');
            port.className = `port ${direction} ${type}`;
            port.title = `${type} port`;
            placed.appendChild(port);
        });
        
        // Glow effect
        placed.style.setProperty('--glow-color', module.glowColor || 'rgba(0, 245, 255, 0.5)');
        
        return placed;
    }
    
    function updateCell(col, row, module) {
        const cell = cellPositions[`${col},${row}`];
        if (!cell) return;
        
        cell.innerHTML = '';
        cell.classList.remove('occupied', 'valid-drop', 'invalid-drop');
        
        if (module) {
            cell.classList.add('occupied');
            cell.appendChild(createPlacedModule(module));
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // MODULE TRAY
    // ═══════════════════════════════════════════════════════════════════════
    
    function renderModuleTray(modules) {
        if (!moduleTray) return;
        
        moduleTray.innerHTML = '';
        
        modules.forEach(module => {
            if (module.count <= 0) return;
            
            const card = createModuleCard(module);
            moduleTray.appendChild(card);
        });
    }
    
    function createModuleCard(module) {
        const card = document.createElement('div');
        card.className = `module-card tier-${module.tier}`;
        card.dataset.moduleId = module.id;
        card.draggable = true;
        
        // Icon
        const icon = document.createElement('div');
        icon.className = 'module-icon';
        icon.textContent = module.icon;
        card.appendChild(icon);
        
        // Name
        const name = document.createElement('div');
        name.className = 'module-name';
        name.textContent = module.name;
        card.appendChild(name);
        
        // Count badge
        if (module.count > 1) {
            const count = document.createElement('div');
            count.className = 'module-count';
            count.textContent = module.count;
            card.appendChild(count);
        }
        
        // Drag events
        card.addEventListener('dragstart', handleDragStart);
        card.addEventListener('dragend', handleDragEnd);
        
        // Click to select
        card.addEventListener('click', () => selectModule(module));
        
        // Hover for info
        card.addEventListener('mouseenter', () => showModulePreview(module));
        
        return card;
    }
    
    function updateModuleTray(modules) {
        renderModuleTray(modules);
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // DRAG AND DROP
    // ═══════════════════════════════════════════════════════════════════════
    
    function setupDragAndDrop() {
        document.addEventListener('dragover', (e) => e.preventDefault());
    }
    
    function handleDragStart(e) {
        const moduleId = e.target.dataset.moduleId;
        currentDragModule = moduleId;
        
        e.target.classList.add('dragging');
        e.dataTransfer.setData('text/plain', moduleId);
        e.dataTransfer.effectAllowed = 'move';
        
        // Highlight valid cells
        highlightValidCells(moduleId);
        
        KennethGame.Audio?.playClick?.();
    }
    
    function handleDragEnd(e) {
        e.target.classList.remove('dragging');
        currentDragModule = null;
        clearHighlights();
    }
    
    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        
        const cell = e.target.closest('.grid-cell');
        if (!cell || cell.classList.contains('occupied')) return;
        
        const col = parseInt(cell.dataset.col);
        const row = parseInt(cell.dataset.row);
        
        if (KennethGame.Logic.canPlaceModule(currentDragModule, col, row)) {
            cell.classList.add('valid-drop');
            cell.classList.remove('invalid-drop');
        } else {
            cell.classList.add('invalid-drop');
            cell.classList.remove('valid-drop');
        }
    }
    
    function handleDragLeave(e) {
        const cell = e.target.closest('.grid-cell');
        if (cell) {
            cell.classList.remove('valid-drop', 'invalid-drop');
        }
    }
    
    function handleDrop(e) {
        e.preventDefault();
        
        const moduleId = e.dataTransfer.getData('text/plain');
        const cell = e.target.closest('.grid-cell');
        
        if (!cell) return;
        
        const col = parseInt(cell.dataset.col);
        const row = parseInt(cell.dataset.row);
        
        clearHighlights();
        
        KennethGame.Logic.placeModule(moduleId, col, row);
    }
    
    function highlightValidCells(moduleId) {
        const grid = KennethGame.Logic.getGrid();
        
        Object.entries(cellPositions).forEach(([key, cell]) => {
            const [col, row] = key.split(',').map(Number);
            
            if (KennethGame.Logic.canPlaceModule(moduleId, col, row)) {
                cell.classList.add('valid-drop');
            }
        });
    }
    
    function clearHighlights() {
        Object.values(cellPositions).forEach(cell => {
            cell.classList.remove('valid-drop', 'invalid-drop');
        });
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // CONNECTIONS
    // ═══════════════════════════════════════════════════════════════════════
    
    function updateConnections(connections) {
        if (!connectionsSvg) return;
        
        connectionsSvg.innerHTML = '';
        
        connections.forEach(conn => {
            drawConnection(conn);
        });
    }
    
    function drawConnection(connection) {
        const fromPos = getCellCenter(connection.from.col, connection.from.row);
        const toPos = getCellCenter(connection.to.col, connection.to.row);
        
        if (!fromPos || !toPos) return;
        
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', fromPos.x);
        line.setAttribute('y1', fromPos.y);
        line.setAttribute('x2', toPos.x);
        line.setAttribute('y2', toPos.y);
        line.setAttribute('class', `connection-line ${connection.type} animated`);
        
        connectionsSvg.appendChild(line);
    }
    
    function getCellCenter(col, row) {
        const cell = cellPositions[`${col},${row}`];
        if (!cell) return null;
        
        const rect = cell.getBoundingClientRect();
        const containerRect = connectionsSvg.getBoundingClientRect();
        
        return {
            x: rect.left - containerRect.left + rect.width / 2,
            y: rect.top - containerRect.top + rect.height / 2
        };
    }
    
    function getCellPosition(col, row) {
        const cell = cellPositions[`${col},${row}`];
        if (!cell) return { x: 0, y: 0 };
        
        const rect = cell.getBoundingClientRect();
        return {
            x: rect.left + rect.width / 2,
            y: rect.top + rect.height / 2
        };
    }
    
    function animateConnection(connection) {
        // Flash the connected modules
        const fromCell = cellPositions[`${connection.from.col},${connection.from.row}`];
        const toCell = cellPositions[`${connection.to.col},${connection.to.row}`];
        
        [fromCell, toCell].forEach(cell => {
            if (!cell) return;
            const port = cell.querySelector(`.port.${connection.from.portType}, .port.${connection.to.portType}`);
            if (port) {
                port.classList.add('connected');
            }
        });
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // ANIMATIONS
    // ═══════════════════════════════════════════════════════════════════════
    
    function animatePlacement(col, row) {
        const cell = cellPositions[`${col},${row}`];
        if (!cell) return;
        
        const module = cell.querySelector('.placed-module');
        if (module) {
            module.style.animation = 'modulePlaceIn 0.3s ease-out';
        }
    }
    
    function highlightHint(col, row) {
        const cell = cellPositions[`${col},${row}`];
        if (!cell) return;
        
        cell.style.animation = 'validPulse 0.5s ease-in-out 3';
        cell.style.boxShadow = '0 0 30px var(--color-gold), inset 0 0 20px rgba(255, 215, 0, 0.3)';
        
        setTimeout(() => {
            cell.style.animation = '';
            cell.style.boxShadow = '';
        }, 3000);
    }
    
    function highlightTargetReached() {
        const scoreDisplay = document.querySelector('.score-value');
        if (scoreDisplay) {
            scoreDisplay.style.color = 'var(--color-green)';
            scoreDisplay.style.animation = 'starShine 0.5s ease-in-out 3';
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // UI UPDATES
    // ═══════════════════════════════════════════════════════════════════════
    
    function updateUI(data) {
        // Score
        const scoreEl = document.getElementById('game-score');
        if (scoreEl) {
            animateNumber(scoreEl, parseInt(scoreEl.textContent) || 0, data.score);
        }
        
        // Target
        const targetEl = document.getElementById('game-target');
        if (targetEl) {
            targetEl.textContent = data.target.toLocaleString();
        }
        
        // Level info
        if (data.levelName) {
            const levelNameEl = document.getElementById('game-level-name');
            if (levelNameEl) levelNameEl.textContent = data.levelName;
        }
        
        if (data.levelSubtitle) {
            const levelSubEl = document.getElementById('game-level-subtitle');
            if (levelSubEl) levelSubEl.textContent = data.levelSubtitle;
        }
    }
    
    function updateTimer(seconds, total) {
        const timerEl = document.getElementById('game-timer');
        const fillEl = document.getElementById('timer-fill');
        
        if (timerEl) {
            timerEl.textContent = KennethGame.Utils.formatTime(seconds);
        }
        
        if (fillEl) {
            const percent = (seconds / total) * 100;
            fillEl.style.width = `${percent}%`;
        }
    }
    
    function setTimerWarning(level) {
        const container = document.getElementById('timer-container');
        if (container) {
            container.classList.remove('warning', 'critical');
            if (level) {
                container.classList.add(level);
            }
        }
    }
    
    function updateCombo(combo) {
        const indicator = document.getElementById('combo-indicator');
        const valueEl = document.getElementById('combo-value');
        
        if (indicator && valueEl) {
            if (combo > 1.0) {
                indicator.classList.add('active');
                valueEl.textContent = `x${combo.toFixed(1)}`;
            } else {
                indicator.classList.remove('active');
            }
        }
    }
    
    function updateObjectives(objectives) {
        const list = document.getElementById('objectives-list');
        if (!list) return;
        
        list.innerHTML = '';
        
        objectives.forEach(obj => {
            const item = document.createElement('li');
            item.className = `objective-item ${obj.completed ? 'completed' : ''}`;
            item.textContent = obj.description;
            list.appendChild(item);
        });
    }
    
    function addSynergyToPanel(synergy) {
        const panel = document.getElementById('synergy-list');
        if (!panel) return;
        
        // Remove empty state
        const empty = panel.querySelector('.empty-state');
        if (empty) empty.remove();
        
        const item = document.createElement('div');
        item.className = 'synergy-item';
        item.innerHTML = `
            <span class="synergy-name">${synergy.name}</span>
            <span class="synergy-bonus">+${synergy.bonus}</span>
        `;
        
        item.style.animation = 'feedbackPop 0.5s ease-out';
        panel.appendChild(item);
    }
    
    function updateSynergiesPanel(synergies) {
        const panel = document.getElementById('synergy-list');
        if (!panel) return;
        
        panel.innerHTML = '';
        
        if (synergies.length === 0) {
            panel.innerHTML = '<p class="empty-state">Connect modules to create synergies!</p>';
            return;
        }
        
        synergies.forEach(synergy => {
            const item = document.createElement('div');
            item.className = 'synergy-item';
            item.innerHTML = `
                <span class="synergy-name">${synergy.name}</span>
                <span class="synergy-bonus">+${synergy.bonus}</span>
            `;
            panel.appendChild(item);
        });
    }
    
    function updatePowerUps() {
        document.querySelectorAll('.power-up-btn').forEach(btn => {
            const type = btn.dataset.power;
            const count = KennethGame.State.getPowerUpCount(type);
            
            const countEl = btn.querySelector('.power-count');
            if (countEl) {
                countEl.textContent = count;
            }
            
            btn.disabled = count <= 0;
        });
    }
    
    function showFeedback(message) {
        const area = document.getElementById('feedback-area');
        if (!area) return;
        
        const msg = document.createElement('div');
        msg.className = 'feedback-message';
        msg.textContent = message;
        
        area.innerHTML = '';
        area.appendChild(msg);
        
        setTimeout(() => {
            msg.style.opacity = '0';
            setTimeout(() => msg.remove(), 300);
        }, 2000);
    }
    
    function showModulePreview(module) {
        const preview = document.getElementById('module-preview');
        if (!preview) return;
        
        preview.innerHTML = `
            <div class="preview-header">
                <span class="preview-icon">${module.icon}</span>
                <span class="preview-name">${module.name}</span>
            </div>
            <p class="preview-desc">${module.description}</p>
            <div class="preview-ports">
                <strong>Ports:</strong>
                ${Object.entries(module.ports).map(([dir, type]) => 
                    `<span class="port-tag ${type}">${dir}: ${type}</span>`
                ).join('')}
            </div>
            <p class="preview-fun-fact"><em>💡 ${module.funFact}</em></p>
        `;
    }
    
    function selectModule(module) {
        // Highlight in tray
        document.querySelectorAll('.module-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        const card = document.querySelector(`.module-card[data-module-id="${module.id}"]`);
        if (card) {
            card.classList.add('selected');
        }
        
        showModulePreview(module);
    }
    
    // Helper: Animate number change
    function animateNumber(element, from, to) {
        const duration = 300;
        const start = performance.now();
        
        function update(currentTime) {
            const elapsed = currentTime - start;
            const progress = Math.min(elapsed / duration, 1);
            
            const current = Math.floor(from + (to - from) * progress);
            element.textContent = current.toLocaleString();
            
            if (progress < 1) {
                requestAnimationFrame(update);
            }
        }
        
        requestAnimationFrame(update);
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════
    
    return {
        init,
        renderGrid,
        updateCell,
        renderModuleTray,
        updateModuleTray,
        updateConnections,
        animateConnection,
        animatePlacement,
        highlightHint,
        highlightTargetReached,
        updateUI,
        updateTimer,
        setTimerWarning,
        updateCombo,
        updateObjectives,
        addSynergyToPanel,
        updateSynergiesPanel,
        updatePowerUps,
        showFeedback,
        showModulePreview,
        getCellPosition
    };
})();
