/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - Utilities
 * Helper functions and DOM utilities for maximum awesomeness!
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

KennethGame.Utils = (function() {
    
    // ═══════════════════════════════════════════════════════════════════════
    // DOM Utilities
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Get element by ID
     * @param {string} id - Element ID
     * @returns {HTMLElement|null}
     */
    function $(id) {
        return document.getElementById(id);
    }
    
    /**
     * Query selector
     * @param {string} selector - CSS selector
     * @param {HTMLElement} [parent=document] - Parent element
     * @returns {HTMLElement|null}
     */
    function $$(selector, parent = document) {
        return parent.querySelector(selector);
    }
    
    /**
     * Query selector all (returns array)
     * @param {string} selector - CSS selector
     * @param {HTMLElement} [parent=document] - Parent element
     * @returns {HTMLElement[]}
     */
    function $$$(selector, parent = document) {
        return Array.from(parent.querySelectorAll(selector));
    }
    
    /**
     * Create element with attributes and children
     * @param {string} tag - Tag name
     * @param {Object} [attrs={}] - Attributes
     * @param {Array} [children=[]] - Child elements or strings
     * @returns {HTMLElement}
     */
    function createElement(tag, attrs = {}, children = []) {
        const el = document.createElement(tag);
        
        Object.entries(attrs).forEach(([key, value]) => {
            if (key === 'className') {
                el.className = value;
            } else if (key === 'textContent') {
                el.textContent = value;
            } else if (key === 'innerHTML') {
                el.innerHTML = value;
            } else if (key === 'style' && typeof value === 'object') {
                Object.assign(el.style, value);
            } else if (key.startsWith('data-')) {
                el.setAttribute(key, value);
            } else if (key.startsWith('on') && typeof value === 'function') {
                el.addEventListener(key.slice(2).toLowerCase(), value);
            } else {
                el.setAttribute(key, value);
            }
        });
        
        children.forEach(child => {
            if (typeof child === 'string') {
                el.appendChild(document.createTextNode(child));
            } else if (child instanceof Element) {
                el.appendChild(child);
            }
        });
        
        return el;
    }
    
    /**
     * Create SVG element
     * @param {string} tag - SVG tag name
     * @param {Object} [attrs={}] - Attributes
     * @returns {SVGElement}
     */
    function createSVG(tag, attrs = {}) {
        const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
        Object.entries(attrs).forEach(([key, value]) => {
            el.setAttribute(key, value);
        });
        return el;
    }
    
    /**
     * Remove all children from element
     * @param {HTMLElement} element
     */
    function clearElement(element) {
        while (element.firstChild) {
            element.removeChild(element.firstChild);
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // Formatting
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Format time as M:SS
     * @param {number} seconds - Time in seconds
     * @returns {string}
     */
    function formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
    
    /**
     * Format number with locale and optional abbreviation
     * @param {number} num - Number to format
     * @param {boolean} [abbreviate=false] - Use K, M abbreviations
     * @returns {string}
     */
    function formatNumber(num, abbreviate = false) {
        if (abbreviate) {
            if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
            if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
        }
        return num.toLocaleString();
    }
    
    /**
     * Format percentage
     * @param {number} value - Value (0-1)
     * @param {number} [decimals=0] - Decimal places
     * @returns {string}
     */
    function formatPercent(value, decimals = 0) {
        return (value * 100).toFixed(decimals) + '%';
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // Math Utilities
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Clamp value between min and max
     * @param {number} value - Value to clamp
     * @param {number} min - Minimum
     * @param {number} max - Maximum
     * @returns {number}
     */
    function clamp(value, min, max) {
        return Math.min(Math.max(value, min), max);
    }
    
    /**
     * Linear interpolation
     * @param {number} a - Start value
     * @param {number} b - End value
     * @param {number} t - Progress (0-1)
     * @returns {number}
     */
    function lerp(a, b, t) {
        return a + (b - a) * t;
    }
    
    /**
     * Map value from one range to another
     * @param {number} value - Input value
     * @param {number} inMin - Input minimum
     * @param {number} inMax - Input maximum
     * @param {number} outMin - Output minimum
     * @param {number} outMax - Output maximum
     * @returns {number}
     */
    function mapRange(value, inMin, inMax, outMin, outMax) {
        return outMin + (outMax - outMin) * ((value - inMin) / (inMax - inMin));
    }
    
    /**
     * Get random item from array
     * @param {Array} array - Source array
     * @returns {*}
     */
    function randomItem(array) {
        if (!array || array.length === 0) return null;
        return array[Math.floor(Math.random() * array.length)];
    }
    
    /**
     * Get random integer between min and max (inclusive)
     * @param {number} min
     * @param {number} max
     * @returns {number}
     */
    function randomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    
    /**
     * Shuffle array (Fisher-Yates)
     * @param {Array} array
     * @returns {Array} - New shuffled array
     */
    function shuffle(array) {
        const result = [...array];
        for (let i = result.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [result[i], result[j]] = [result[j], result[i]];
        }
        return result;
    }
    
    /**
     * Generate unique ID
     * @returns {string}
     */
    function generateId() {
        return 'id_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    /**
     * Calculate distance between two points
     * @param {number} x1
     * @param {number} y1
     * @param {number} x2
     * @param {number} y2
     * @returns {number}
     */
    function distance(x1, y1, x2, y2) {
        return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // Grid Utilities
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Get adjacent cells (top, right, bottom, left)
     * @param {number} col - Column
     * @param {number} row - Row
     * @returns {Array} Adjacent cell positions with directions
     */
    function getAdjacentCells(col, row) {
        return [
            { col, row: row - 1, direction: 'top', opposite: 'bottom' },
            { col: col + 1, row, direction: 'right', opposite: 'left' },
            { col, row: row + 1, direction: 'bottom', opposite: 'top' },
            { col: col - 1, row, direction: 'left', opposite: 'right' }
        ];
    }
    
    /**
     * Get opposite port direction
     * @param {string} port - Port direction
     * @returns {string}
     */
    function getOppositePort(port) {
        const opposites = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
        return opposites[port];
    }
    
    /**
     * Check if cell is within grid bounds
     * @param {number} col
     * @param {number} row
     * @param {number} cols - Total columns
     * @param {number} rows - Total rows
     * @returns {boolean}
     */
    function isInBounds(col, row, cols, rows) {
        return col >= 0 && col < cols && row >= 0 && row < rows;
    }
    
    /**
     * Convert grid position to cell key
     * @param {number} col
     * @param {number} row
     * @returns {string}
     */
    function cellKey(col, row) {
        return `${col},${row}`;
    }
    
    /**
     * Parse cell key to position
     * @param {string} key
     * @returns {{col: number, row: number}}
     */
    function parseKey(key) {
        const [col, row] = key.split(',').map(Number);
        return { col, row };
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // Timing
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Wait for specified milliseconds
     * @param {number} ms - Milliseconds
     * @returns {Promise}
     */
    function wait(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    /**
     * Debounce function
     * @param {Function} fn - Function to debounce
     * @param {number} delay - Delay in ms
     * @returns {Function}
     */
    function debounce(fn, delay) {
        let timeoutId;
        return function(...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => fn.apply(this, args), delay);
        };
    }
    
    /**
     * Throttle function
     * @param {Function} fn - Function to throttle
     * @param {number} limit - Minimum time between calls
     * @returns {Function}
     */
    function throttle(fn, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                fn.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // Animation
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Easing functions
     */
    const easings = {
        linear: t => t,
        easeInQuad: t => t * t,
        easeOutQuad: t => t * (2 - t),
        easeInOutQuad: t => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
        easeOutCubic: t => (--t) * t * t + 1,
        easeInOutCubic: t => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
        easeOutElastic: t => {
            const p = 0.3;
            return Math.pow(2, -10 * t) * Math.sin((t - p / 4) * (2 * Math.PI) / p) + 1;
        },
        easeOutBounce: t => {
            if (t < 1 / 2.75) return 7.5625 * t * t;
            if (t < 2 / 2.75) return 7.5625 * (t -= 1.5 / 2.75) * t + 0.75;
            if (t < 2.5 / 2.75) return 7.5625 * (t -= 2.25 / 2.75) * t + 0.9375;
            return 7.5625 * (t -= 2.625 / 2.75) * t + 0.984375;
        }
    };
    
    /**
     * Animate a value from start to end
     * @param {number} from - Start value
     * @param {number} to - End value
     * @param {number} duration - Duration in ms
     * @param {Function} onUpdate - Called each frame with current value
     * @param {Function} [onComplete] - Called when complete
     * @param {string} [easing='easeOutQuad'] - Easing function name
     */
    function animate(from, to, duration, onUpdate, onComplete, easing = 'easeOutQuad') {
        const easeFn = easings[easing] || easings.linear;
        const startTime = performance.now();
        
        function tick(now) {
            const elapsed = now - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easedProgress = easeFn(progress);
            
            onUpdate(lerp(from, to, easedProgress));
            
            if (progress < 1) {
                requestAnimationFrame(tick);
            } else if (onComplete) {
                onComplete();
            }
        }
        
        requestAnimationFrame(tick);
    }
    
    /**
     * Animate counter from start to end
     * @param {HTMLElement} element - Element to update
     * @param {number} from - Start value
     * @param {number} to - End value
     * @param {number} duration - Duration in ms
     * @param {string} [prefix=''] - Text before number
     * @param {string} [suffix=''] - Text after number
     */
    function animateCounter(element, from, to, duration, prefix = '', suffix = '') {
        animate(from, to, duration, value => {
            element.textContent = prefix + Math.round(value).toLocaleString() + suffix;
        });
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // UI Utilities
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Show a toast notification
     * @param {string} message - Message to display
     * @param {string} [type='info'] - Type: 'success', 'error', 'info', 'warning'
     * @param {number} [duration=3000] - Duration in ms
     */
    function showToast(message, type = 'info', duration = 3000) {
        const container = $('toast-container');
        if (!container) return;
        
        const icons = {
            success: '✓',
            error: '✗',
            info: 'ℹ',
            warning: '⚠'
        };
        
        const toast = createElement('div', { className: `toast ${type}` }, [
            createElement('span', { className: 'toast-icon', textContent: icons[type] || icons.info }),
            createElement('span', { className: 'toast-message', textContent: message })
        ]);
        
        container.appendChild(toast);
        
        // Auto-remove
        setTimeout(() => {
            toast.style.animation = 'toastSlideIn 0.3s ease reverse';
            setTimeout(() => toast.remove(), 300);
        }, duration);
        
        return toast;
    }
    
    /**
     * Show floating encouragement message
     * @param {string} message - Message to show
     * @param {number} [duration=2000] - Duration in ms
     */
    function showFloatingMessage(message, duration = 2000) {
        const floater = $('floating-message');
        if (!floater) return;
        
        floater.textContent = message;
        floater.classList.remove('active');
        
        // Force reflow
        void floater.offsetWidth;
        
        floater.classList.add('active');
        
        setTimeout(() => {
            floater.classList.remove('active');
        }, duration);
    }
    
    /**
     * Personalize message by replacing "Kenneth" with player name
     * @param {string} message - Original message
     * @returns {string} - Personalized message
     */
    function personalizeMessage(message) {
        if (!message) return '';
        const playerName = KennethGame.State?.getPlayerName() || 'Scientist';
        return message.replace(/Kenneth/g, playerName);
    }

    /**
     * Get random encouragement message (personalized with player name)
     * @param {string} type - Message type from CONSTANTS.ENCOURAGEMENT
     * @returns {string}
     */
    function getEncouragement(type) {
        const messages = KennethGame.CONSTANTS?.ENCOURAGEMENT?.[type];
        if (!messages || messages.length === 0) return '';
        return personalizeMessage(randomItem(messages));
    }

    /**
     * Get random tip (personalized)
     * @returns {string}
     */
    function getRandomTip() {
        const tips = KennethGame.CONSTANTS?.TIPS;
        if (!tips || tips.length === 0) return 'Have fun!';
        return personalizeMessage(randomItem(tips));
    }
    
    /**
     * Check if user prefers reduced motion
     * @returns {boolean}
     */
    function prefersReducedMotion() {
        return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    
    /**
     * Screen shake effect
     * @param {HTMLElement} element - Element to shake
     * @param {number} [intensity=5] - Shake intensity
     * @param {number} [duration=300] - Duration in ms
     */
    function screenShake(element, intensity = 5, duration = 300) {
        if (prefersReducedMotion()) return;
        
        const startTime = performance.now();
        const originalTransform = element.style.transform;
        
        function shake(now) {
            const elapsed = now - startTime;
            if (elapsed >= duration) {
                element.style.transform = originalTransform;
                return;
            }
            
            const progress = elapsed / duration;
            const currentIntensity = intensity * (1 - progress);
            const x = (Math.random() - 0.5) * currentIntensity * 2;
            const y = (Math.random() - 0.5) * currentIntensity * 2;
            
            element.style.transform = `${originalTransform} translate(${x}px, ${y}px)`;
            requestAnimationFrame(shake);
        }
        
        requestAnimationFrame(shake);
    }
    
    /**
     * Vibrate device (if supported)
     * @param {number|number[]} pattern - Vibration pattern
     */
    function vibrate(pattern = 50) {
        if (navigator.vibrate) {
            navigator.vibrate(pattern);
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // Color Utilities
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Convert hex to RGB
     * @param {string} hex - Hex color string
     * @returns {{r: number, g: number, b: number}}
     */
    function hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : { r: 0, g: 0, b: 0 };
    }
    
    /**
     * Convert RGB to hex
     * @param {number} r - Red (0-255)
     * @param {number} g - Green (0-255)
     * @param {number} b - Blue (0-255)
     * @returns {string}
     */
    function rgbToHex(r, g, b) {
        return '#' + [r, g, b].map(x => {
            const hex = x.toString(16);
            return hex.length === 1 ? '0' + hex : hex;
        }).join('');
    }
    
    /**
     * Lighten or darken a color
     * @param {string} hex - Hex color
     * @param {number} percent - Positive to lighten, negative to darken
     * @returns {string}
     */
    function adjustColor(hex, percent) {
        const rgb = hexToRgb(hex);
        const adjust = (value) => Math.min(255, Math.max(0, Math.round(value + (value * percent / 100))));
        return rgbToHex(adjust(rgb.r), adjust(rgb.g), adjust(rgb.b));
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // Storage Helpers
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Safely get from localStorage
     * @param {string} key
     * @param {*} defaultValue
     * @returns {*}
     */
    function storageGet(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (e) {
            console.warn('Storage get failed:', e);
            return defaultValue;
        }
    }
    
    /**
     * Safely set to localStorage
     * @param {string} key
     * @param {*} value
     * @returns {boolean}
     */
    function storageSet(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (e) {
            console.warn('Storage set failed:', e);
            return false;
        }
    }
    
    /**
     * Remove from localStorage
     * @param {string} key
     */
    function storageRemove(key) {
        try {
            localStorage.removeItem(key);
        } catch (e) {
            console.warn('Storage remove failed:', e);
        }
    }
    
    // Public API
    return {
        $,
        $$,
        $$$,
        createElement,
        createSVG,
        clearElement,
        formatTime,
        formatNumber,
        formatPercent,
        clamp,
        lerp,
        mapRange,
        randomItem,
        randomInt,
        shuffle,
        generateId,
        distance,
        getAdjacentCells,
        getOppositePort,
        isInBounds,
        cellKey,
        parseKey,
        wait,
        debounce,
        throttle,
        easings,
        animate,
        animateCounter,
        showToast,
        showFloatingMessage,
        personalizeMessage,
        getEncouragement,
        getRandomTip,
        prefersReducedMotion,
        screenShake,
        vibrate,
        hexToRgb,
        rgbToHex,
        adjustColor,
        storageGet,
        storageSet,
        storageRemove
    };
})();

console.log('🔧 Utilities loaded!');
