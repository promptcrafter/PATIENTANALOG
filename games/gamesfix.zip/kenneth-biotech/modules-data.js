/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - Modules Data
 * 50+ Bio-Modules for Kenneth to discover and master!
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Each module has:
 * - Unique visuals and animations
 * - Connection ports (neural, vascular, data, energy, fluid, universal)
 * - Fun facts Kenneth can learn!
 * - Tier and category for progression
 * - Synergy bonuses with other modules
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

KennethGame.Modules = (function() {
    
    /**
     * ═══════════════════════════════════════════════════════════════════════
     * MODULE DEFINITIONS - Kenneth's Bio-Collection!
     * ═══════════════════════════════════════════════════════════════════════
     */
    const MODULES = {
        
        // ═══════════════════════════════════════════════════════════════════
        // ERA 1: BASIC ORGANS - The Building Blocks of Life!
        // ═══════════════════════════════════════════════════════════════════
        
        heart: {
            id: 'heart',
            name: 'Heart',
            icon: '❤️',
            category: 'organs',
            tier: 1,
            description: 'The powerful pump that sends blood everywhere!',
            funFact: 'Your heart beats about 100,000 times every day! That\'s like bouncing a basketball non-stop!',
            scienceNote: 'The heart pumps 2,000 gallons of blood daily through 60,000 miles of blood vessels.',
            ports: {
                top: 'vascular',
                right: 'vascular',
                bottom: 'vascular',
                left: 'vascular'
            },
            basePoints: 100,
            synergyBonus: ['lung', 'blood_vessel'],
            unlockLevel: 1,
            color: '#ff4466',
            glowColor: 'rgba(255, 68, 102, 0.6)',
            animation: 'pulse',
            rarity: 'common'
        },
        
        brain: {
            id: 'brain',
            name: 'Brain',
            icon: '🧠',
            category: 'organs',
            tier: 1,
            description: 'The supercomputer of your body! Controls EVERYTHING!',
            funFact: 'Your brain has 86 BILLION neurons! That\'s more than stars you can see in the night sky!',
            scienceNote: 'The brain uses 20% of your body\'s energy but is only 2% of your weight.',
            ports: {
                top: 'neural',
                right: 'neural',
                bottom: 'neural',
                left: 'neural'
            },
            basePoints: 150,
            synergyBonus: ['nerve_connector', 'eye', 'spinal_cord'],
            unlockLevel: 1,
            color: '#ff77ff',
            glowColor: 'rgba(255, 119, 255, 0.6)',
            animation: 'sparkle',
            rarity: 'common'
        },
        
        lung: {
            id: 'lung',
            name: 'Lungs',
            icon: '🫁',
            category: 'organs',
            tier: 1,
            description: 'Breathe in the good air, breathe out the bad!',
            funFact: 'You breathe about 22,000 times a day! Your lungs would cover a tennis court if flattened!',
            scienceNote: 'Lungs contain 300 million tiny air sacs called alveoli for gas exchange.',
            ports: {
                top: 'vascular',
                right: 'fluid',
                bottom: 'vascular',
                left: 'fluid'
            },
            basePoints: 90,
            synergyBonus: ['heart', 'blood_vessel'],
            unlockLevel: 1,
            color: '#ffaaaa',
            glowColor: 'rgba(255, 170, 170, 0.6)',
            animation: 'breathe',
            rarity: 'common'
        },
        
        liver: {
            id: 'liver',
            name: 'Liver',
            icon: '🫀',
            category: 'organs',
            tier: 1,
            description: 'The body\'s cleaning factory! Filters out bad stuff.',
            funFact: 'Your liver does over 500 different jobs! It\'s like having 500 tiny workers inside you!',
            scienceNote: 'The liver can regenerate itself even if 75% of it is removed!',
            ports: {
                top: 'vascular',
                right: 'fluid',
                bottom: 'vascular',
                left: 'fluid'
            },
            basePoints: 85,
            synergyBonus: ['stomach', 'intestine', 'kidney'],
            unlockLevel: 1,
            color: '#cc6644',
            glowColor: 'rgba(204, 102, 68, 0.6)',
            animation: 'glow',
            rarity: 'common'
        },
        
        kidney: {
            id: 'kidney',
            name: 'Kidney',
            icon: '🫘',
            category: 'organs',
            tier: 1,
            description: 'The body\'s water filter! Makes pee to clean your blood.',
            funFact: 'Your kidneys filter ALL your blood about 40 times every day!',
            scienceNote: 'Each kidney has about 1 million tiny filters called nephrons.',
            ports: {
                top: 'vascular',
                right: 'fluid',
                bottom: 'fluid',
                left: 'vascular'
            },
            basePoints: 80,
            synergyBonus: ['liver', 'bladder'],
            unlockLevel: 1,
            color: '#aa5544',
            glowColor: 'rgba(170, 85, 68, 0.6)',
            animation: 'flow',
            rarity: 'common'
        },
        
        stomach: {
            id: 'stomach',
            name: 'Stomach',
            icon: '🟤',
            category: 'organs',
            tier: 1,
            description: 'The food blender! Mixes and mashes your meals.',
            funFact: 'Your stomach acid is strong enough to dissolve metal! Good thing your stomach has a special coating!',
            scienceNote: 'The stomach can stretch to hold up to 1 liter of food.',
            ports: {
                top: 'fluid',
                right: 'fluid',
                bottom: 'fluid',
                left: 'vascular'
            },
            basePoints: 75,
            synergyBonus: ['intestine', 'liver', 'pancreas'],
            unlockLevel: 2,
            color: '#dd8866',
            glowColor: 'rgba(221, 136, 102, 0.6)',
            animation: 'churn',
            rarity: 'common'
        },
        
        intestine: {
            id: 'intestine',
            name: 'Intestines',
            icon: '🪱',
            category: 'organs',
            tier: 1,
            description: 'The super-long food tube! Absorbs all the good nutrients.',
            funFact: 'Your intestines are about 25 feet long! That\'s as long as a school bus!',
            scienceNote: 'The small intestine has millions of tiny finger-like projections called villi.',
            ports: {
                top: 'fluid',
                right: 'vascular',
                bottom: 'fluid',
                left: 'vascular'
            },
            basePoints: 70,
            synergyBonus: ['stomach', 'liver'],
            unlockLevel: 2,
            color: '#ee9977',
            glowColor: 'rgba(238, 153, 119, 0.6)',
            animation: 'wiggle',
            rarity: 'common'
        },
        
        pancreas: {
            id: 'pancreas',
            name: 'Pancreas',
            icon: '🥖',
            category: 'organs',
            tier: 1,
            description: 'Makes special juices to help digest food and control sugar!',
            funFact: 'Your pancreas makes insulin, which is like a key that lets sugar into your cells!',
            scienceNote: 'The pancreas produces about 1.5 liters of digestive enzymes daily.',
            ports: {
                top: 'fluid',
                right: 'vascular',
                bottom: 'fluid',
                left: 'energy'
            },
            basePoints: 80,
            synergyBonus: ['stomach', 'intestine', 'liver'],
            unlockLevel: 3,
            color: '#ffcc88',
            glowColor: 'rgba(255, 204, 136, 0.6)',
            animation: 'drip',
            rarity: 'uncommon'
        },
        
        spleen: {
            id: 'spleen',
            name: 'Spleen',
            icon: '🟣',
            category: 'organs',
            tier: 1,
            description: 'The blood filter and immune helper!',
            funFact: 'Your spleen is like a police station for your blood - it catches bad guys (germs)!',
            scienceNote: 'The spleen stores about 1/3 of your body\'s platelets.',
            ports: {
                top: 'vascular',
                right: 'vascular',
                bottom: 'vascular',
                left: 'energy'
            },
            basePoints: 75,
            synergyBonus: ['bone_marrow', 'blood_vessel'],
            unlockLevel: 3,
            color: '#9944aa',
            glowColor: 'rgba(153, 68, 170, 0.6)',
            animation: 'filter',
            rarity: 'uncommon'
        },
        
        bone_marrow: {
            id: 'bone_marrow',
            name: 'Bone Marrow',
            icon: '🦴',
            category: 'organs',
            tier: 1,
            description: 'The blood cell factory inside your bones!',
            funFact: 'Your bone marrow makes 200 BILLION red blood cells every single day!',
            scienceNote: 'Red marrow produces blood cells while yellow marrow stores fat.',
            ports: {
                top: 'vascular',
                right: 'energy',
                bottom: 'vascular',
                left: 'energy'
            },
            basePoints: 85,
            synergyBonus: ['spleen', 'blood_vessel'],
            unlockLevel: 4,
            color: '#ffddcc',
            glowColor: 'rgba(255, 221, 204, 0.6)',
            animation: 'produce',
            rarity: 'uncommon'
        },
        
        skin: {
            id: 'skin',
            name: 'Skin',
            icon: '🖐️',
            category: 'organs',
            tier: 1,
            description: 'Your body\'s protective suit! The largest organ!',
            funFact: 'Your skin weighs about 8 pounds and would cover 20 square feet if spread flat!',
            scienceNote: 'Skin has 3 layers: epidermis, dermis, and hypodermis.',
            ports: {
                top: 'neural',
                right: 'vascular',
                bottom: 'universal',
                left: 'vascular'
            },
            basePoints: 65,
            synergyBonus: ['muscle', 'nerve_connector'],
            unlockLevel: 4,
            color: '#ffcc99',
            glowColor: 'rgba(255, 204, 153, 0.6)',
            animation: 'shield',
            rarity: 'common'
        },
        
        muscle: {
            id: 'muscle',
            name: 'Muscle',
            icon: '💪',
            category: 'organs',
            tier: 1,
            description: 'The movers of your body! Over 600 muscles work together!',
            funFact: 'It takes 17 muscles to smile but 43 to frown. Keep smiling, Kenneth! 😊',
            scienceNote: 'Muscles can only pull, never push. They work in pairs!',
            ports: {
                top: 'neural',
                right: 'energy',
                bottom: 'vascular',
                left: 'energy'
            },
            basePoints: 70,
            synergyBonus: ['bone_marrow', 'nerve_connector'],
            unlockLevel: 5,
            color: '#cc4444',
            glowColor: 'rgba(204, 68, 68, 0.6)',
            animation: 'flex',
            rarity: 'common'
        },
        
        eye: {
            id: 'eye',
            name: 'Eye',
            icon: '👁️',
            category: 'organs',
            tier: 1,
            description: 'Your amazing cameras! See the world in full color!',
            funFact: 'Your eyes can see about 10 million different colors! That\'s a LOT of crayons!',
            scienceNote: 'Eyes blink about 15-20 times per minute without you even thinking about it!',
            ports: {
                top: 'neural',
                right: 'neural',
                bottom: 'vascular',
                left: 'data'
            },
            basePoints: 90,
            synergyBonus: ['brain', 'nerve_connector'],
            unlockLevel: 5,
            color: '#3399ff',
            glowColor: 'rgba(51, 153, 255, 0.6)',
            animation: 'blink',
            rarity: 'uncommon'
        },
        
        ear: {
            id: 'ear',
            name: 'Ear',
            icon: '👂',
            category: 'organs',
            tier: 1,
            description: 'Hear all the sounds and keep your balance!',
            funFact: 'The smallest bones in your body are in your ear - smaller than a grain of rice!',
            scienceNote: 'Your ear also helps you balance! That\'s why you feel dizzy when spinning.',
            ports: {
                top: 'neural',
                right: 'data',
                bottom: 'neural',
                left: 'universal'
            },
            basePoints: 75,
            synergyBonus: ['brain', 'nerve_connector'],
            unlockLevel: 5,
            color: '#ffbb99',
            glowColor: 'rgba(255, 187, 153, 0.6)',
            animation: 'listen',
            rarity: 'common'
        },
        
        thyroid: {
            id: 'thyroid',
            name: 'Thyroid',
            icon: '🦋',
            category: 'organs',
            tier: 1,
            description: 'The metabolism controller! Decides how fast your body works.',
            funFact: 'Your thyroid is shaped like a butterfly! It controls how fast you burn energy!',
            scienceNote: 'The thyroid produces hormones that regulate metabolism, growth, and development.',
            ports: {
                top: 'vascular',
                right: 'energy',
                bottom: 'vascular',
                left: 'energy'
            },
            basePoints: 70,
            synergyBonus: ['brain', 'heart'],
            unlockLevel: 6,
            color: '#ff88cc',
            glowColor: 'rgba(255, 136, 204, 0.6)',
            animation: 'flutter',
            rarity: 'uncommon'
        },
        
        // ═══════════════════════════════════════════════════════════════════
        // CONNECTORS - Link Everything Together!
        // ═══════════════════════════════════════════════════════════════════
        
        blood_vessel: {
            id: 'blood_vessel',
            name: 'Blood Vessel',
            icon: '🔴',
            category: 'connectors',
            tier: 1,
            description: 'The highways for blood! Arteries, veins, and capillaries.',
            funFact: 'If you lined up all your blood vessels, they would go around Earth TWICE!',
            scienceNote: 'Arteries carry blood away from the heart, veins carry it back.',
            ports: {
                top: 'vascular',
                right: 'vascular',
                bottom: 'vascular',
                left: 'vascular'
            },
            basePoints: 40,
            isConnector: true,
            synergyBonus: ['heart', 'lung'],
            unlockLevel: 1,
            color: '#ff4444',
            glowColor: 'rgba(255, 68, 68, 0.6)',
            animation: 'flow',
            rarity: 'common'
        },
        
        nerve_connector: {
            id: 'nerve_connector',
            name: 'Nerve Bundle',
            icon: '⚡',
            category: 'connectors',
            tier: 1,
            description: 'Super-fast message cables! Sends signals everywhere.',
            funFact: 'Nerve signals travel up to 250 mph! Faster than a race car!',
            scienceNote: 'Nerves use electrical and chemical signals to communicate.',
            ports: {
                top: 'neural',
                right: 'neural',
                bottom: 'neural',
                left: 'neural'
            },
            basePoints: 45,
            isConnector: true,
            synergyBonus: ['brain', 'eye', 'muscle'],
            unlockLevel: 1,
            color: '#ffff00',
            glowColor: 'rgba(255, 255, 0, 0.6)',
            animation: 'zap',
            rarity: 'common'
        },
        
        fluid_channel: {
            id: 'fluid_channel',
            name: 'Fluid Channel',
            icon: '💧',
            category: 'connectors',
            tier: 1,
            description: 'Pipes for bodily fluids! Carries water and nutrients.',
            funFact: 'Your body is about 60% water! Water is in every single cell!',
            scienceNote: 'Lymph fluid helps remove waste and fight infections.',
            ports: {
                top: 'fluid',
                right: 'fluid',
                bottom: 'fluid',
                left: 'fluid'
            },
            basePoints: 35,
            isConnector: true,
            synergyBonus: ['kidney', 'intestine'],
            unlockLevel: 2,
            color: '#00ccff',
            glowColor: 'rgba(0, 204, 255, 0.6)',
            animation: 'ripple',
            rarity: 'common'
        },
        
        universal_hub: {
            id: 'universal_hub',
            name: 'Universal Hub',
            icon: '✨',
            category: 'connectors',
            tier: 2,
            description: 'The ULTIMATE connector! Links ANY type of port!',
            funFact: 'Like a power adapter that works everywhere in the world!',
            scienceNote: 'In biotech, multi-functional interfaces connect different biological systems.',
            ports: {
                top: 'universal',
                right: 'universal',
                bottom: 'universal',
                left: 'universal'
            },
            basePoints: 60,
            isConnector: true,
            synergyBonus: [],
            unlockLevel: 8,
            color: '#ffffff',
            glowColor: 'rgba(255, 255, 255, 0.8)',
            animation: 'rainbow',
            rarity: 'rare'
        },
        
        spinal_cord: {
            id: 'spinal_cord',
            name: 'Spinal Cord',
            icon: '🦴',
            category: 'connectors',
            tier: 1,
            description: 'The information superhighway between brain and body!',
            funFact: 'Your spinal cord is protected by 33 bones called vertebrae!',
            scienceNote: 'The spinal cord transmits motor and sensory information.',
            ports: {
                top: 'neural',
                right: 'vascular',
                bottom: 'neural',
                left: 'vascular'
            },
            basePoints: 55,
            isConnector: true,
            synergyBonus: ['brain', 'nerve_connector'],
            unlockLevel: 4,
            color: '#ddddaa',
            glowColor: 'rgba(221, 221, 170, 0.6)',
            animation: 'pulse',
            rarity: 'uncommon'
        },
        
        // ═══════════════════════════════════════════════════════════════════
        // ERA 2: ORGANOIDS - Mini Lab-Grown Organs!
        // ═══════════════════════════════════════════════════════════════════
        
        brain_organoid: {
            id: 'brain_organoid',
            name: 'Brain Organoid',
            icon: '🧫',
            category: 'organoids',
            tier: 2,
            description: 'A tiny brain grown in a lab dish! Real neurons that fire!',
            funFact: 'Scientists have grown brain organoids that show brain wave activity, just like a real brain!',
            scienceNote: 'Brain organoids are used to study diseases like Alzheimer\'s without using real brains.',
            ports: {
                top: 'neural',
                right: 'data',
                bottom: 'neural',
                left: 'data'
            },
            basePoints: 200,
            synergyBonus: ['brain', 'ai_predictor', 'heart_organoid'],
            unlockLevel: 6,
            color: '#ff88ff',
            glowColor: 'rgba(255, 136, 255, 0.7)',
            animation: 'think',
            rarity: 'rare'
        },
        
        heart_organoid: {
            id: 'heart_organoid',
            name: 'Heart Organoid',
            icon: '💓',
            category: 'organoids',
            tier: 2,
            description: 'A beating mini-heart! Grown from real heart cells!',
            funFact: 'Heart organoids can actually BEAT in the lab dish, just like a real heart!',
            scienceNote: 'Used to test new heart medicines without putting patients at risk.',
            ports: {
                top: 'vascular',
                right: 'data',
                bottom: 'vascular',
                left: 'energy'
            },
            basePoints: 180,
            synergyBonus: ['heart', 'brain_organoid', 'sensor_array'],
            unlockLevel: 7,
            color: '#ff6688',
            glowColor: 'rgba(255, 102, 136, 0.7)',
            animation: 'beat',
            rarity: 'rare'
        },
        
        liver_organoid: {
            id: 'liver_organoid',
            name: 'Liver Organoid',
            icon: '🫙',
            category: 'organoids',
            tier: 2,
            description: 'A mini-liver that actually processes chemicals!',
            funFact: 'Liver organoids can detoxify substances just like a full-size liver!',
            scienceNote: 'Critical for testing drug safety before human trials.',
            ports: {
                top: 'fluid',
                right: 'data',
                bottom: 'vascular',
                left: 'fluid'
            },
            basePoints: 170,
            synergyBonus: ['liver', 'kidney_organoid', 'bioreactor'],
            unlockLevel: 8,
            color: '#cc8866',
            glowColor: 'rgba(204, 136, 102, 0.7)',
            animation: 'process',
            rarity: 'rare'
        },
        
        kidney_organoid: {
            id: 'kidney_organoid',
            name: 'Kidney Organoid',
            icon: '🫛',
            category: 'organoids',
            tier: 2,
            description: 'A filtering mini-kidney! Cleans fluids like the real thing!',
            funFact: 'Kidney organoids can form the same structures as real kidneys!',
            scienceNote: 'Used to study kidney disease and develop new treatments.',
            ports: {
                top: 'fluid',
                right: 'data',
                bottom: 'fluid',
                left: 'vascular'
            },
            basePoints: 165,
            synergyBonus: ['kidney', 'liver_organoid'],
            unlockLevel: 9,
            color: '#bb6655',
            glowColor: 'rgba(187, 102, 85, 0.7)',
            animation: 'filter',
            rarity: 'rare'
        },
        
        lung_organoid: {
            id: 'lung_organoid',
            name: 'Lung Organoid',
            icon: '🎈',
            category: 'organoids',
            tier: 2,
            description: 'Breathing mini-lungs! Tests how lungs react to air.',
            funFact: 'Scientists used lung organoids to study COVID-19 without risking patients!',
            scienceNote: 'Lung organoids have the same cell types as real lung tissue.',
            ports: {
                top: 'fluid',
                right: 'vascular',
                bottom: 'data',
                left: 'fluid'
            },
            basePoints: 160,
            synergyBonus: ['lung', 'perfusion_system'],
            unlockLevel: 10,
            color: '#ffaacc',
            glowColor: 'rgba(255, 170, 204, 0.7)',
            animation: 'inflate',
            rarity: 'rare'
        },
        
        gut_organoid: {
            id: 'gut_organoid',
            name: 'Gut Organoid',
            icon: '🔬',
            category: 'organoids',
            tier: 2,
            description: 'A mini-intestine! Studies digestion and gut bacteria.',
            funFact: 'Gut organoids help scientists understand the "gut-brain connection"!',
            scienceNote: 'Contains multiple intestinal cell types that absorb nutrients.',
            ports: {
                top: 'fluid',
                right: 'vascular',
                bottom: 'fluid',
                left: 'neural'
            },
            basePoints: 155,
            synergyBonus: ['intestine', 'brain_organoid'],
            unlockLevel: 11,
            color: '#ffbb99',
            glowColor: 'rgba(255, 187, 153, 0.7)',
            animation: 'absorb',
            rarity: 'rare'
        },
        
        retina_organoid: {
            id: 'retina_organoid',
            name: 'Retina Organoid',
            icon: '👀',
            category: 'organoids',
            tier: 2,
            description: 'A mini eye-sensor! Can detect light like real eyes!',
            funFact: 'Retina organoids can actually sense light! Scientists hope to use them to cure blindness!',
            scienceNote: 'Contains photoreceptor cells that respond to light stimulation.',
            ports: {
                top: 'neural',
                right: 'data',
                bottom: 'data',
                left: 'neural'
            },
            basePoints: 175,
            synergyBonus: ['eye', 'brain_organoid', 'sensor_array'],
            unlockLevel: 12,
            color: '#66aaff',
            glowColor: 'rgba(102, 170, 255, 0.7)',
            animation: 'scan',
            rarity: 'epic'
        },
        
        // ═══════════════════════════════════════════════════════════════════
        // ERA 3: MPS - Microphysiological Systems (Organs-on-Chips!)
        // ═══════════════════════════════════════════════════════════════════
        
        organ_chip: {
            id: 'organ_chip',
            name: 'Organ-on-Chip',
            icon: '💎',
            category: 'mps',
            tier: 3,
            description: 'A tiny chip that simulates a whole organ! Super high-tech!',
            funFact: 'Organ chips are about the size of a USB drive but contain living cells!',
            scienceNote: 'MPS devices mimic organ-level physiology on a miniaturized platform.',
            ports: {
                top: 'data',
                right: 'fluid',
                bottom: 'data',
                left: 'fluid'
            },
            basePoints: 250,
            synergyBonus: ['microfluidic_channel', 'sensor_array'],
            unlockLevel: 13,
            color: '#aa66ff',
            glowColor: 'rgba(170, 102, 255, 0.8)',
            animation: 'compute',
            rarity: 'epic'
        },
        
        microfluidic_channel: {
            id: 'microfluidic_channel',
            name: 'Microfluidic Channel',
            icon: '🌊',
            category: 'mps',
            tier: 3,
            description: 'Tiny channels smaller than a hair! Moves fluids precisely.',
            funFact: 'These channels are so small that fluids behave differently than in big pipes!',
            scienceNote: 'Microfluidics enables precise control of fluid flow at the cellular scale.',
            ports: {
                top: 'fluid',
                right: 'fluid',
                bottom: 'fluid',
                left: 'fluid'
            },
            basePoints: 180,
            isConnector: true,
            synergyBonus: ['organ_chip', 'perfusion_system'],
            unlockLevel: 14,
            color: '#00aaff',
            glowColor: 'rgba(0, 170, 255, 0.8)',
            animation: 'flow',
            rarity: 'rare'
        },
        
        bioreactor: {
            id: 'bioreactor',
            name: 'Bioreactor',
            icon: '⚗️',
            category: 'mps',
            tier: 3,
            description: 'Keeps organoids alive and happy! Controls temperature and nutrients.',
            funFact: 'Bioreactors are like luxury apartments for cells - perfect temperature, food, and air!',
            scienceNote: 'Provides optimal conditions for cell growth and tissue development.',
            ports: {
                top: 'energy',
                right: 'fluid',
                bottom: 'data',
                left: 'fluid'
            },
            basePoints: 220,
            synergyBonus: ['organ_chip', 'perfusion_system'],
            unlockLevel: 15,
            color: '#44ddaa',
            glowColor: 'rgba(68, 221, 170, 0.8)',
            animation: 'bubble',
            rarity: 'epic'
        },
        
        sensor_array: {
            id: 'sensor_array',
            name: 'Sensor Array',
            icon: '📡',
            category: 'mps',
            tier: 3,
            description: 'Watches EVERYTHING! Monitors cells in real-time.',
            funFact: 'These sensors can detect single molecules - smaller than you can imagine!',
            scienceNote: 'Enables real-time monitoring of cellular responses and biomarkers.',
            ports: {
                top: 'data',
                right: 'data',
                bottom: 'data',
                left: 'data'
            },
            basePoints: 200,
            isConnector: true,
            synergyBonus: ['organ_chip', 'digital_twin'],
            unlockLevel: 16,
            color: '#ffcc00',
            glowColor: 'rgba(255, 204, 0, 0.8)',
            animation: 'scan',
            rarity: 'rare'
        },
        
        perfusion_system: {
            id: 'perfusion_system',
            name: 'Perfusion System',
            icon: '🔄',
            category: 'mps',
            tier: 3,
            description: 'Pumps nutrients like real blood flow! Keeps everything running.',
            funFact: 'Without perfusion, cells would starve in just a few hours!',
            scienceNote: 'Mimics blood circulation to deliver oxygen and nutrients continuously.',
            ports: {
                top: 'fluid',
                right: 'energy',
                bottom: 'fluid',
                left: 'vascular'
            },
            basePoints: 210,
            synergyBonus: ['bioreactor', 'microfluidic_channel'],
            unlockLevel: 17,
            color: '#ff6699',
            glowColor: 'rgba(255, 102, 153, 0.8)',
            animation: 'pump',
            rarity: 'epic'
        },
        
        // ═══════════════════════════════════════════════════════════════════
        // ERA 4: DIGITAL & ADVANCED - The Future of Medicine!
        // ═══════════════════════════════════════════════════════════════════
        
        digital_twin: {
            id: 'digital_twin',
            name: 'Digital Twin',
            icon: '👾',
            category: 'digital',
            tier: 4,
            description: 'A virtual copy of a WHOLE PERSON! Simulates everything!',
            funFact: 'Digital twins could let doctors practice surgery on YOUR virtual copy before the real thing!',
            scienceNote: 'Patient-specific computational models that predict individual responses.',
            ports: {
                top: 'data',
                right: 'neural',
                bottom: 'data',
                left: 'energy'
            },
            basePoints: 350,
            synergyBonus: ['ai_predictor', 'data_hub', 'organ_chip'],
            unlockLevel: 18,
            color: '#00ffcc',
            glowColor: 'rgba(0, 255, 204, 0.9)',
            animation: 'hologram',
            rarity: 'legendary'
        },
        
        ai_predictor: {
            id: 'ai_predictor',
            name: 'AI Predictor',
            icon: '🤖',
            category: 'digital',
            tier: 4,
            description: 'Artificial intelligence that predicts what will happen!',
            funFact: 'AI can spot patterns that would take humans years to find - in just seconds!',
            scienceNote: 'Machine learning algorithms analyze vast datasets to predict outcomes.',
            ports: {
                top: 'data',
                right: 'data',
                bottom: 'neural',
                left: 'energy'
            },
            basePoints: 300,
            synergyBonus: ['digital_twin', 'sensor_array', 'data_hub'],
            unlockLevel: 19,
            color: '#ff00aa',
            glowColor: 'rgba(255, 0, 170, 0.9)',
            animation: 'think',
            rarity: 'legendary'
        },
        
        data_hub: {
            id: 'data_hub',
            name: 'Data Hub',
            icon: '🌐',
            category: 'digital',
            tier: 4,
            description: 'The brain of the system! Collects and shares all data.',
            funFact: 'Modern labs generate more data in a day than existed in all libraries 100 years ago!',
            scienceNote: 'Central data management enables integrated multi-organ analysis.',
            ports: {
                top: 'data',
                right: 'data',
                bottom: 'data',
                left: 'data'
            },
            basePoints: 275,
            isConnector: true,
            synergyBonus: ['digital_twin', 'ai_predictor', 'sensor_array'],
            unlockLevel: 20,
            color: '#00ff88',
            glowColor: 'rgba(0, 255, 136, 0.9)',
            animation: 'network',
            rarity: 'epic'
        },
        
        quantum_analyzer: {
            id: 'quantum_analyzer',
            name: 'Quantum Analyzer',
            icon: '⚛️',
            category: 'digital',
            tier: 4,
            description: 'Uses QUANTUM PHYSICS to analyze molecules! Sci-fi is real!',
            funFact: 'Quantum computers can solve problems that would take regular computers billions of years!',
            scienceNote: 'Quantum computing enables simulation of molecular interactions.',
            ports: {
                top: 'energy',
                right: 'data',
                bottom: 'energy',
                left: 'data'
            },
            basePoints: 400,
            synergyBonus: ['digital_twin', 'brain_organoid', 'ai_predictor'],
            unlockLevel: 21,
            color: '#8844ff',
            glowColor: 'rgba(136, 68, 255, 0.9)',
            animation: 'quantum',
            rarity: 'legendary'
        },
        
        synth_tissue: {
            id: 'synth_tissue',
            name: 'Synthetic Tissue',
            icon: '🧬',
            category: 'synthetic',
            tier: 4,
            description: 'Lab-made tissue that could replace damaged organs!',
            funFact: 'Scientists are 3D-printing tissues using real cells as "ink"!',
            scienceNote: 'Bioprinted tissues may one day solve the organ transplant shortage.',
            ports: {
                top: 'vascular',
                right: 'universal',
                bottom: 'vascular',
                left: 'universal'
            },
            basePoints: 325,
            synergyBonus: ['bioreactor', 'perfusion_system'],
            unlockLevel: 22,
            color: '#ff9944',
            glowColor: 'rgba(255, 153, 68, 0.9)',
            animation: 'grow',
            rarity: 'legendary'
        },
        
        nanobots: {
            id: 'nanobots',
            name: 'Nanobots',
            icon: '🔮',
            category: 'synthetic',
            tier: 4,
            description: 'Tiny robots smaller than cells! The future of medicine!',
            funFact: 'Nanobots could one day travel through your blood to fight diseases!',
            scienceNote: 'Nanoscale robots for targeted drug delivery and precision surgery.',
            ports: {
                top: 'universal',
                right: 'data',
                bottom: 'vascular',
                left: 'energy'
            },
            basePoints: 375,
            synergyBonus: ['ai_predictor', 'blood_vessel'],
            unlockLevel: 23,
            color: '#00ffff',
            glowColor: 'rgba(0, 255, 255, 0.9)',
            animation: 'swarm',
            rarity: 'legendary'
        },
        
        crispr_editor: {
            id: 'crispr_editor',
            name: 'CRISPR Editor',
            icon: '✂️',
            category: 'synthetic',
            tier: 4,
            description: 'Gene editing scissors! Can fix DNA mistakes!',
            funFact: 'CRISPR won the 2020 Nobel Prize! It can edit genes like editing a document!',
            scienceNote: 'Revolutionary gene-editing technology for treating genetic diseases.',
            ports: {
                top: 'data',
                right: 'neural',
                bottom: 'energy',
                left: 'universal'
            },
            basePoints: 350,
            synergyBonus: ['brain_organoid', 'digital_twin'],
            unlockLevel: 24,
            color: '#ff4488',
            glowColor: 'rgba(255, 68, 136, 0.9)',
            animation: 'splice',
            rarity: 'legendary'
        },

        // ═══════════════════════════════════════════════════════════════════
        // MORE ORGANS - Expanding Kenneth's Knowledge!
        // ═══════════════════════════════════════════════════════════════════

        bladder: {
            id: 'bladder',
            name: 'Bladder',
            icon: '🎈',
            category: 'organs',
            tier: 1,
            description: 'The stretchy storage balloon for pee!',
            funFact: 'Your bladder can hold about 2 cups of pee! It stretches like a balloon!',
            scienceNote: 'The bladder can stretch to 6 times its empty size.',
            ports: {
                top: 'fluid',
                right: 'neural',
                bottom: 'fluid',
                left: 'vascular'
            },
            basePoints: 65,
            synergyBonus: ['kidney', 'nerve_connector'],
            unlockLevel: 3,
            color: '#ffdd66',
            glowColor: 'rgba(255, 221, 102, 0.6)',
            animation: 'expand',
            rarity: 'common'
        },

        gallbladder: {
            id: 'gallbladder',
            name: 'Gallbladder',
            icon: '🫒',
            category: 'organs',
            tier: 1,
            description: 'Stores bile to help digest fatty foods!',
            funFact: 'Your gallbladder is shaped like a tiny pear and helps you digest pizza!',
            scienceNote: 'Bile breaks down fats so your body can absorb them.',
            ports: {
                top: 'fluid',
                right: 'vascular',
                bottom: 'fluid',
                left: 'fluid'
            },
            basePoints: 60,
            synergyBonus: ['liver', 'intestine'],
            unlockLevel: 4,
            color: '#88cc44',
            glowColor: 'rgba(136, 204, 68, 0.6)',
            animation: 'drip',
            rarity: 'common'
        },

        appendix: {
            id: 'appendix',
            name: 'Appendix',
            icon: '🪄',
            category: 'organs',
            tier: 1,
            description: 'A mystery organ! May help your immune system!',
            funFact: 'Scientists now think the appendix is a safe house for good bacteria!',
            scienceNote: 'The appendix may serve as a reservoir for beneficial gut bacteria.',
            ports: {
                top: 'vascular',
                right: 'fluid',
                bottom: 'energy',
                left: 'vascular'
            },
            basePoints: 55,
            synergyBonus: ['intestine', 'spleen'],
            unlockLevel: 5,
            color: '#ff9999',
            glowColor: 'rgba(255, 153, 153, 0.6)',
            animation: 'pulse',
            rarity: 'uncommon'
        },

        adrenal_gland: {
            id: 'adrenal_gland',
            name: 'Adrenal Gland',
            icon: '⚡',
            category: 'organs',
            tier: 1,
            description: 'The energy factory! Makes adrenaline for superpowers!',
            funFact: 'When you get scared, these tiny glands give you superhero speed and strength!',
            scienceNote: 'Produces adrenaline, cortisol, and other hormones that regulate stress.',
            ports: {
                top: 'vascular',
                right: 'energy',
                bottom: 'energy',
                left: 'vascular'
            },
            basePoints: 80,
            synergyBonus: ['kidney', 'heart', 'brain'],
            unlockLevel: 6,
            color: '#ffaa00',
            glowColor: 'rgba(255, 170, 0, 0.7)',
            animation: 'zap',
            rarity: 'uncommon'
        },

        pituitary: {
            id: 'pituitary',
            name: 'Pituitary Gland',
            icon: '👑',
            category: 'organs',
            tier: 2,
            description: 'The master gland! Controls ALL other glands!',
            funFact: 'This pea-sized gland is the boss of your whole hormone system!',
            scienceNote: 'Called the "master gland" because it controls other endocrine glands.',
            ports: {
                top: 'neural',
                right: 'energy',
                bottom: 'vascular',
                left: 'energy'
            },
            basePoints: 95,
            synergyBonus: ['brain', 'thyroid', 'adrenal_gland'],
            unlockLevel: 7,
            color: '#ff66ff',
            glowColor: 'rgba(255, 102, 255, 0.7)',
            animation: 'crown',
            rarity: 'rare'
        },

        lymph_node: {
            id: 'lymph_node',
            name: 'Lymph Node',
            icon: '🛡️',
            category: 'organs',
            tier: 1,
            description: 'Immune system checkpoints! Fights germs!',
            funFact: 'You have 600-700 lymph nodes working as security guards in your body!',
            scienceNote: 'Lymph nodes filter lymph fluid and house immune cells.',
            ports: {
                top: 'fluid',
                right: 'vascular',
                bottom: 'fluid',
                left: 'vascular'
            },
            basePoints: 70,
            synergyBonus: ['spleen', 'bone_marrow'],
            unlockLevel: 5,
            color: '#44dd88',
            glowColor: 'rgba(68, 221, 136, 0.6)',
            animation: 'shield',
            rarity: 'common'
        },

        tonsils: {
            id: 'tonsils',
            name: 'Tonsils',
            icon: '🔴',
            category: 'organs',
            tier: 1,
            description: 'Throat guards! First defense against germs you breathe!',
            funFact: 'Your tonsils are like bouncers at a club - they decide what gets in!',
            scienceNote: 'Tonsils trap pathogens entering through the mouth and nose.',
            ports: {
                top: 'fluid',
                right: 'vascular',
                bottom: 'neural',
                left: 'vascular'
            },
            basePoints: 55,
            synergyBonus: ['lymph_node', 'lung'],
            unlockLevel: 3,
            color: '#ff6666',
            glowColor: 'rgba(255, 102, 102, 0.6)',
            animation: 'guard',
            rarity: 'common'
        },

        hypothalamus: {
            id: 'hypothalamus',
            name: 'Hypothalamus',
            icon: '🌡️',
            category: 'organs',
            tier: 2,
            description: 'Your body\'s thermostat and hunger control!',
            funFact: 'This tiny brain part controls if you feel hot, cold, hungry, or tired!',
            scienceNote: 'Regulates body temperature, hunger, thirst, sleep, and emotions.',
            ports: {
                top: 'neural',
                right: 'neural',
                bottom: 'energy',
                left: 'vascular'
            },
            basePoints: 100,
            synergyBonus: ['brain', 'pituitary'],
            unlockLevel: 8,
            color: '#ff88aa',
            glowColor: 'rgba(255, 136, 170, 0.7)',
            animation: 'regulate',
            rarity: 'rare'
        },

        // ═══════════════════════════════════════════════════════════════════
        // MORE ORGANOIDS - Growing in the Lab!
        // ═══════════════════════════════════════════════════════════════════

        pancreas_organoid: {
            id: 'pancreas_organoid',
            name: 'Pancreas Organoid',
            icon: '🧁',
            category: 'organoids',
            tier: 2,
            description: 'Mini pancreas that makes real insulin!',
            funFact: 'These tiny organoids could help cure diabetes someday!',
            scienceNote: 'Contains insulin-producing beta cells for diabetes research.',
            ports: {
                top: 'fluid',
                right: 'data',
                bottom: 'energy',
                left: 'vascular'
            },
            basePoints: 185,
            synergyBonus: ['pancreas', 'liver_organoid'],
            unlockLevel: 10,
            color: '#ffcc66',
            glowColor: 'rgba(255, 204, 102, 0.7)',
            animation: 'secrete',
            rarity: 'rare'
        },

        skin_organoid: {
            id: 'skin_organoid',
            name: 'Skin Organoid',
            icon: '🧴',
            category: 'organoids',
            tier: 2,
            description: 'Lab-grown skin with hair follicles!',
            funFact: 'Scientists can grow skin that even has tiny hairs!',
            scienceNote: 'Used for testing cosmetics and studying skin diseases.',
            ports: {
                top: 'neural',
                right: 'data',
                bottom: 'vascular',
                left: 'universal'
            },
            basePoints: 150,
            synergyBonus: ['skin', 'sensor_array'],
            unlockLevel: 9,
            color: '#ffccaa',
            glowColor: 'rgba(255, 204, 170, 0.7)',
            animation: 'layer',
            rarity: 'rare'
        },

        bone_organoid: {
            id: 'bone_organoid',
            name: 'Bone Organoid',
            icon: '🦴',
            category: 'organoids',
            tier: 2,
            description: 'Mini bones grown in a dish!',
            funFact: 'These tiny bone structures could help heal broken bones faster!',
            scienceNote: 'Models bone development and diseases like osteoporosis.',
            ports: {
                top: 'vascular',
                right: 'data',
                bottom: 'energy',
                left: 'vascular'
            },
            basePoints: 155,
            synergyBonus: ['bone_marrow', 'bioreactor'],
            unlockLevel: 11,
            color: '#eeeecc',
            glowColor: 'rgba(238, 238, 204, 0.7)',
            animation: 'grow',
            rarity: 'rare'
        },

        thyroid_organoid: {
            id: 'thyroid_organoid',
            name: 'Thyroid Organoid',
            icon: '🦋',
            category: 'organoids',
            tier: 2,
            description: 'A mini butterfly gland that makes hormones!',
            funFact: 'Can produce actual thyroid hormone in a petri dish!',
            scienceNote: 'Used to study thyroid diseases and test treatments.',
            ports: {
                top: 'vascular',
                right: 'data',
                bottom: 'energy',
                left: 'energy'
            },
            basePoints: 145,
            synergyBonus: ['thyroid', 'pituitary'],
            unlockLevel: 12,
            color: '#ff99dd',
            glowColor: 'rgba(255, 153, 221, 0.7)',
            animation: 'flutter',
            rarity: 'rare'
        },

        inner_ear_organoid: {
            id: 'inner_ear_organoid',
            name: 'Inner Ear Organoid',
            icon: '🔊',
            category: 'organoids',
            tier: 2,
            description: 'Tiny hearing sensors grown in the lab!',
            funFact: 'Could help restore hearing to people who lost it!',
            scienceNote: 'Contains hair cells that detect sound vibrations.',
            ports: {
                top: 'neural',
                right: 'data',
                bottom: 'neural',
                left: 'data'
            },
            basePoints: 170,
            synergyBonus: ['ear', 'brain_organoid'],
            unlockLevel: 13,
            color: '#88aaff',
            glowColor: 'rgba(136, 170, 255, 0.7)',
            animation: 'vibrate',
            rarity: 'epic'
        },

        // ═══════════════════════════════════════════════════════════════════
        // MORE MPS - Advanced Chip Technology!
        // ═══════════════════════════════════════════════════════════════════

        lung_on_chip: {
            id: 'lung_on_chip',
            name: 'Lung-on-Chip',
            icon: '🫁',
            category: 'mps',
            tier: 3,
            description: 'Breathing chip! Simulates how lungs work!',
            funFact: 'This chip can actually "breathe" by stretching like real lungs!',
            scienceNote: 'Mimics the air-blood barrier for respiratory disease research.',
            ports: {
                top: 'fluid',
                right: 'data',
                bottom: 'fluid',
                left: 'data'
            },
            basePoints: 260,
            synergyBonus: ['lung_organoid', 'microfluidic_channel'],
            unlockLevel: 14,
            color: '#ffaadd',
            glowColor: 'rgba(255, 170, 221, 0.8)',
            animation: 'breathe',
            rarity: 'epic'
        },

        liver_on_chip: {
            id: 'liver_on_chip',
            name: 'Liver-on-Chip',
            icon: '🧫',
            category: 'mps',
            tier: 3,
            description: 'Detox chip! Tests how drugs affect the liver!',
            funFact: 'Can detect if a medicine might be toxic in just days instead of years!',
            scienceNote: 'Replicates liver zonation and drug metabolism.',
            ports: {
                top: 'fluid',
                right: 'data',
                bottom: 'vascular',
                left: 'fluid'
            },
            basePoints: 255,
            synergyBonus: ['liver_organoid', 'sensor_array'],
            unlockLevel: 15,
            color: '#cc9966',
            glowColor: 'rgba(204, 153, 102, 0.8)',
            animation: 'process',
            rarity: 'epic'
        },

        heart_on_chip: {
            id: 'heart_on_chip',
            name: 'Heart-on-Chip',
            icon: '💓',
            category: 'mps',
            tier: 3,
            description: 'Beating heart chip! Tests cardiac safety!',
            funFact: 'Can beat just like a real heart and detect dangerous drug effects!',
            scienceNote: 'Models cardiac tissue with functional beating cardiomyocytes.',
            ports: {
                top: 'vascular',
                right: 'data',
                bottom: 'energy',
                left: 'data'
            },
            basePoints: 270,
            synergyBonus: ['heart_organoid', 'perfusion_system'],
            unlockLevel: 16,
            color: '#ff6688',
            glowColor: 'rgba(255, 102, 136, 0.8)',
            animation: 'beat',
            rarity: 'epic'
        },

        kidney_on_chip: {
            id: 'kidney_on_chip',
            name: 'Kidney-on-Chip',
            icon: '🫘',
            category: 'mps',
            tier: 3,
            description: 'Filtering chip! Models how kidneys clean blood!',
            funFact: 'Tests if drugs might damage your kidneys before you take them!',
            scienceNote: 'Replicates nephron function including filtration and reabsorption.',
            ports: {
                top: 'fluid',
                right: 'data',
                bottom: 'fluid',
                left: 'vascular'
            },
            basePoints: 245,
            synergyBonus: ['kidney_organoid', 'bioreactor'],
            unlockLevel: 17,
            color: '#bb7766',
            glowColor: 'rgba(187, 119, 102, 0.8)',
            animation: 'filter',
            rarity: 'epic'
        },

        gut_on_chip: {
            id: 'gut_on_chip',
            name: 'Gut-on-Chip',
            icon: '🪱',
            category: 'mps',
            tier: 3,
            description: 'Digestion chip with real gut bacteria!',
            funFact: 'Can study how gut bacteria affect your whole body!',
            scienceNote: 'Models intestinal epithelium with microbiome interactions.',
            ports: {
                top: 'fluid',
                right: 'data',
                bottom: 'fluid',
                left: 'neural'
            },
            basePoints: 240,
            synergyBonus: ['gut_organoid', 'microfluidic_channel'],
            unlockLevel: 18,
            color: '#ffbb88',
            glowColor: 'rgba(255, 187, 136, 0.8)',
            animation: 'digest',
            rarity: 'epic'
        },

        brain_on_chip: {
            id: 'brain_on_chip',
            name: 'Brain-on-Chip',
            icon: '🧠',
            category: 'mps',
            tier: 3,
            description: 'Thinking chip! Studies brain diseases!',
            funFact: 'Can model Alzheimer\'s and Parkinson\'s to find cures!',
            scienceNote: 'Contains multiple brain cell types forming neural networks.',
            ports: {
                top: 'neural',
                right: 'data',
                bottom: 'neural',
                left: 'data'
            },
            basePoints: 280,
            synergyBonus: ['brain_organoid', 'ai_predictor'],
            unlockLevel: 19,
            color: '#ff88ff',
            glowColor: 'rgba(255, 136, 255, 0.8)',
            animation: 'think',
            rarity: 'epic'
        },

        blood_brain_barrier_chip: {
            id: 'blood_brain_barrier_chip',
            name: 'BBB Chip',
            icon: '🚧',
            category: 'mps',
            tier: 3,
            description: 'Brain\'s security gate! Tests what can enter!',
            funFact: 'Your brain has a special barrier that blocks most drugs - this chip tests how to get past it!',
            scienceNote: 'Models the selective permeability of the blood-brain barrier.',
            ports: {
                top: 'vascular',
                right: 'data',
                bottom: 'neural',
                left: 'data'
            },
            basePoints: 290,
            synergyBonus: ['brain_on_chip', 'nanobots'],
            unlockLevel: 20,
            color: '#aa88ff',
            glowColor: 'rgba(170, 136, 255, 0.8)',
            animation: 'barrier',
            rarity: 'legendary'
        },

        multi_organ_chip: {
            id: 'multi_organ_chip',
            name: 'Multi-Organ Chip',
            icon: '🎰',
            category: 'mps',
            tier: 3,
            description: 'Multiple organs on one chip! Body-on-chip!',
            funFact: 'Like having a tiny human body on a chip for testing!',
            scienceNote: 'Integrates multiple organ systems for systemic drug testing.',
            ports: {
                top: 'universal',
                right: 'data',
                bottom: 'universal',
                left: 'data'
            },
            basePoints: 350,
            synergyBonus: ['organ_chip', 'digital_twin', 'perfusion_system'],
            unlockLevel: 21,
            color: '#ff00ff',
            glowColor: 'rgba(255, 0, 255, 0.9)',
            animation: 'integrate',
            rarity: 'legendary'
        },

        // ═══════════════════════════════════════════════════════════════════
        // MORE DIGITAL TWINS - The Future is Here!
        // ═══════════════════════════════════════════════════════════════════

        virtual_heart: {
            id: 'virtual_heart',
            name: 'Virtual Heart',
            icon: '❤️‍🔥',
            category: 'digital',
            tier: 4,
            description: 'Digital beating heart! Simulates YOUR heart!',
            funFact: 'Doctors can practice heart surgery on your virtual heart first!',
            scienceNote: 'Patient-specific cardiac models for surgical planning.',
            ports: {
                top: 'data',
                right: 'vascular',
                bottom: 'data',
                left: 'energy'
            },
            basePoints: 320,
            synergyBonus: ['digital_twin', 'heart_on_chip'],
            unlockLevel: 22,
            color: '#ff4466',
            glowColor: 'rgba(255, 68, 102, 0.9)',
            animation: 'hologram',
            rarity: 'legendary'
        },

        virtual_brain: {
            id: 'virtual_brain',
            name: 'Virtual Brain',
            icon: '🌐',
            category: 'digital',
            tier: 4,
            description: 'Simulates brain function! Maps YOUR neurons!',
            funFact: 'Could help plan brain surgery and understand consciousness!',
            scienceNote: 'Computational model of neural connectivity and function.',
            ports: {
                top: 'data',
                right: 'neural',
                bottom: 'data',
                left: 'neural'
            },
            basePoints: 380,
            synergyBonus: ['digital_twin', 'brain_on_chip', 'ai_predictor'],
            unlockLevel: 23,
            color: '#aa66ff',
            glowColor: 'rgba(170, 102, 255, 0.9)',
            animation: 'hologram',
            rarity: 'legendary'
        },

        drug_simulator: {
            id: 'drug_simulator',
            name: 'Drug Simulator',
            icon: '💊',
            category: 'digital',
            tier: 4,
            description: 'Tests millions of drugs virtually! Super fast!',
            funFact: 'Can test more drugs in one day than a lab could in 100 years!',
            scienceNote: 'In silico screening of drug candidates using molecular modeling.',
            ports: {
                top: 'data',
                right: 'data',
                bottom: 'energy',
                left: 'data'
            },
            basePoints: 340,
            synergyBonus: ['ai_predictor', 'quantum_analyzer'],
            unlockLevel: 24,
            color: '#00ff66',
            glowColor: 'rgba(0, 255, 102, 0.9)',
            animation: 'compute',
            rarity: 'legendary'
        },

        genome_mapper: {
            id: 'genome_mapper',
            name: 'Genome Mapper',
            icon: '🗺️',
            category: 'digital',
            tier: 4,
            description: 'Maps your entire DNA! 3 billion letters!',
            funFact: 'Your DNA code would fill 200 phone books if printed out!',
            scienceNote: 'Whole genome sequencing and variant analysis.',
            ports: {
                top: 'data',
                right: 'universal',
                bottom: 'data',
                left: 'energy'
            },
            basePoints: 360,
            synergyBonus: ['crispr_editor', 'ai_predictor'],
            unlockLevel: 25,
            color: '#88ff88',
            glowColor: 'rgba(136, 255, 136, 0.9)',
            animation: 'map',
            rarity: 'legendary'
        },

        immune_simulator: {
            id: 'immune_simulator',
            name: 'Immune Simulator',
            icon: '🛡️',
            category: 'digital',
            tier: 4,
            description: 'Simulates your immune system fighting disease!',
            funFact: 'Can predict how YOUR body will fight a specific virus!',
            scienceNote: 'Models immune responses for vaccine development.',
            ports: {
                top: 'data',
                right: 'vascular',
                bottom: 'data',
                left: 'data'
            },
            basePoints: 330,
            synergyBonus: ['digital_twin', 'lymph_node'],
            unlockLevel: 26,
            color: '#44ddaa',
            glowColor: 'rgba(68, 221, 170, 0.9)',
            animation: 'defend',
            rarity: 'legendary'
        },

        population_twin: {
            id: 'population_twin',
            name: 'Population Twin',
            icon: '👥',
            category: 'digital',
            tier: 4,
            description: 'Simulates millions of people at once!',
            funFact: 'Can predict how a new drug would work for everyone in a city!',
            scienceNote: 'Population-scale modeling for clinical trial simulation.',
            ports: {
                top: 'data',
                right: 'data',
                bottom: 'data',
                left: 'data'
            },
            basePoints: 400,
            synergyBonus: ['digital_twin', 'ai_predictor', 'data_hub'],
            unlockLevel: 27,
            color: '#ff66aa',
            glowColor: 'rgba(255, 102, 170, 0.9)',
            animation: 'multiply',
            rarity: 'legendary'
        },

        // ═══════════════════════════════════════════════════════════════════
        // ULTIMATE TIER - Kenneth's Ultimate Creations!
        // ═══════════════════════════════════════════════════════════════════

        human_body_chip: {
            id: 'human_body_chip',
            name: 'Human Body Chip',
            icon: '🧍',
            category: 'mps',
            tier: 4,
            description: 'THE ULTIMATE! A complete human body on a chip!',
            funFact: 'Everything connected - like building a tiny YOU in the lab!',
            scienceNote: 'Full physiome-on-chip for comprehensive drug testing.',
            ports: {
                top: 'universal',
                right: 'universal',
                bottom: 'universal',
                left: 'universal'
            },
            basePoints: 500,
            synergyBonus: ['multi_organ_chip', 'digital_twin', 'ai_predictor'],
            unlockLevel: 28,
            color: '#ffdd00',
            glowColor: 'rgba(255, 221, 0, 1)',
            animation: 'ultimate',
            rarity: 'mythic'
        },

        bio_computer: {
            id: 'bio_computer',
            name: 'Bio-Computer',
            icon: '🖥️',
            category: 'digital',
            tier: 4,
            description: 'A computer made from living cells!',
            funFact: 'Uses DNA instead of silicon chips to compute! Living computer!',
            scienceNote: 'Biological computing using engineered cellular circuits.',
            ports: {
                top: 'neural',
                right: 'data',
                bottom: 'neural',
                left: 'data'
            },
            basePoints: 450,
            synergyBonus: ['brain_organoid', 'quantum_analyzer'],
            unlockLevel: 29,
            color: '#00ffaa',
            glowColor: 'rgba(0, 255, 170, 1)',
            animation: 'compute',
            rarity: 'mythic'
        },

        time_lapse_organoid: {
            id: 'time_lapse_organoid',
            name: 'Time-Lapse Organoid',
            icon: '⏰',
            category: 'organoids',
            tier: 4,
            description: 'Watch aging happen in fast-forward!',
            funFact: 'Can simulate 80 years of aging in just weeks!',
            scienceNote: 'Accelerated aging models for longevity research.',
            ports: {
                top: 'data',
                right: 'energy',
                bottom: 'data',
                left: 'universal'
            },
            basePoints: 420,
            synergyBonus: ['digital_twin', 'genome_mapper'],
            unlockLevel: 30,
            color: '#ffaa00',
            glowColor: 'rgba(255, 170, 0, 1)',
            animation: 'timewarp',
            rarity: 'mythic'
        },

        regeneration_engine: {
            id: 'regeneration_engine',
            name: 'Regeneration Engine',
            icon: '♻️',
            category: 'synthetic',
            tier: 4,
            description: 'Regrows damaged organs like a salamander!',
            funFact: 'Could one day regrow entire limbs for humans!',
            scienceNote: 'Tissue regeneration using stem cell programming.',
            ports: {
                top: 'universal',
                right: 'energy',
                bottom: 'vascular',
                left: 'data'
            },
            basePoints: 480,
            synergyBonus: ['synth_tissue', 'crispr_editor'],
            unlockLevel: 30,
            color: '#44ff88',
            glowColor: 'rgba(68, 255, 136, 1)',
            animation: 'regenerate',
            rarity: 'mythic'
        }
    };
    
    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Get all modules
     * @returns {Array}
     */
    function getAll() {
        return Object.values(MODULES);
    }
    
    /**
     * Get module by ID
     * @param {string} id
     * @returns {Object|null}
     */
    function getById(id) {
        return MODULES[id] || null;
    }
    
    /**
     * Get modules by category
     * @param {string} category
     * @returns {Array}
     */
    function getByCategory(category) {
        return Object.values(MODULES).filter(m => m.category === category);
    }
    
    /**
     * Get modules by tier
     * @param {number} tier
     * @returns {Array}
     */
    function getByTier(tier) {
        return Object.values(MODULES).filter(m => m.tier === tier);
    }
    
    /**
     * Get unlocked modules for player level
     * @param {number} playerLevel
     * @returns {Array}
     */
    function getUnlockedFor(playerLevel) {
        return Object.values(MODULES).filter(m => m.unlockLevel <= playerLevel);
    }
    
    /**
     * Get connector modules
     * @returns {Array}
     */
    function getConnectors() {
        return Object.values(MODULES).filter(m => m.isConnector);
    }
    
    /**
     * Check if two ports are compatible
     * @param {string} port1Type
     * @param {string} port2Type
     * @returns {boolean}
     */
    function arePortsCompatible(port1Type, port2Type) {
        if (port1Type === 'universal' || port2Type === 'universal') return true;
        
        const compatibility = KennethGame.CONSTANTS.CONNECTION_TYPES[port1Type]?.compatibleWith;
        if (!compatibility) return port1Type === port2Type;
        
        return compatibility.includes(port2Type);
    }
    
    /**
     * Get connection score between two ports
     * @param {string} port1Type
     * @param {string} port2Type
     * @returns {number}
     */
    function getConnectionScore(port1Type, port2Type) {
        if (!arePortsCompatible(port1Type, port2Type)) return 0;
        
        const type1 = KennethGame.CONSTANTS.CONNECTION_TYPES[port1Type];
        const type2 = KennethGame.CONSTANTS.CONNECTION_TYPES[port2Type];
        
        // Perfect match
        if (port1Type === port2Type) {
            return (type1?.bonusPoints || 25) * 2;
        }
        
        // Universal connection
        if (port1Type === 'universal' || port2Type === 'universal') {
            return 20;
        }
        
        // Compatible connection
        return (type1?.bonusPoints || 25);
    }
    
    /**
     * Get random fun fact
     * @returns {string}
     */
    function getRandomFunFact() {
        const allModules = Object.values(MODULES);
        const module = allModules[Math.floor(Math.random() * allModules.length)];
        return `${module.icon} ${module.name}: ${module.funFact}`;
    }
    
    /**
     * Get total module count
     * @returns {number}
     */
    function getTotalCount() {
        return Object.keys(MODULES).length;
    }
    
    return {
        getAll,
        getById,
        getByCategory,
        getByTier,
        getUnlockedFor,
        getConnectors,
        arePortsCompatible,
        getConnectionScore,
        getRandomFunFact,
        getTotalCount,
        MODULES
    };
})();

console.log(`🧬 Kenneth's Bio-Modules loaded: ${KennethGame.Modules.getTotalCount()} modules ready!`);
