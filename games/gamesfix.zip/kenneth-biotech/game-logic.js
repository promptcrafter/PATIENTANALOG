/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - Game Logic
 * Core gameplay mechanics with deep synergies and combos!
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

KennethGame.Logic = (function() {
    
    const CONSTANTS = KennethGame.CONSTANTS;
    
    // Game state
    let currentLevel = null;
    let grid = [];
    let gridCols = 6;
    let gridRows = 5;
    let score = 0;
    let combo = 1.0;
    let lastPlacementTime = 0;
    let connections = [];
    let activeSynergies = [];
    let placedModules = [];
    let availableModules = [];
    let timeRemaining = 180;
    let timerInterval = null;
    let isPlaying = false;
    let isPaused = false;
    let moveHistory = [];
    let boostActive = false;
    
    // Stats for this level
    let levelStats = {
        modulesPlaced: 0,
        connectionsFormed: 0,
        synergiesCreated: 0,
        hintsUsed: 0,
        undosUsed: 0,
        maxCombo: 1.0
    };
    
    // ═══════════════════════════════════════════════════════════════════════
    // LEVEL MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════
    
    function startLevel(levelId) {
        const level = KennethGame.Levels.getLevel(levelId);
        if (!level) {
            console.error('Level not found:', levelId);
            return false;
        }
        
        currentLevel = level;
        
        // Reset state
        gridCols = level.gridSize.cols;
        gridRows = level.gridSize.rows;
        grid = createEmptyGrid(gridCols, gridRows);
        score = 0;
        combo = 1.0;
        connections = [];
        activeSynergies = [];
        placedModules = [];
        moveHistory = [];
        boostActive = false;
        
        // Reset stats
        levelStats = {
            modulesPlaced: 0,
            connectionsFormed: 0,
            synergiesCreated: 0,
            hintsUsed: 0,
            undosUsed: 0,
            maxCombo: 1.0
        };
        
        // Setup available modules
        availableModules = level.availableModules.map(m => ({
            ...KennethGame.Modules.getById(m.id),
            count: m.count,
            originalCount: m.count
        }));
        
        // Setup timer
        timeRemaining = level.timeLimit;
        
        isPlaying = true;
        isPaused = false;
        
        // Start timer
        startTimer();
        
        // Show encouragement
        const message = KennethGame.Utils?.getEncouragement?.('onLevelStart') || 'Let\'s go, Kenneth!';
        if (message) KennethGame.Utils?.showToast?.(message, 'success');
        
        // Render
        KennethGame.Renderer?.renderGrid?.(grid, gridCols, gridRows);
        KennethGame.Renderer?.renderModuleTray?.(availableModules);
        KennethGame.Renderer?.updateUI?.({
            score,
            target: level.targetScore,
            time: timeRemaining,
            combo,
            levelName: level.name,
            levelSubtitle: level.subtitle
        });
        
        // Play sound
        KennethGame.Audio?.playClick?.();
        
        console.log('🎮 Starting level:', level.name);
        return true;
    }
    
    function createEmptyGrid(cols, rows) {
        const newGrid = [];
        for (let row = 0; row < rows; row++) {
            newGrid[row] = [];
            for (let col = 0; col < cols; col++) {
                newGrid[row][col] = null;
            }
        }
        return newGrid;
    }
    
    function endLevel(completed = false) {
        isPlaying = false;
        stopTimer();
        
        if (completed) {
            const stars = calculateStars();
            const result = KennethGame.State?.completeLevel?.(
                currentLevel.id,
                score,
                stars,
                timeRemaining,
                levelStats
            ) || { xpEarned: 0, levelUp: false, newLevel: 1, newAchievements: [] };
            
            // Play victory sound and effects
            KennethGame.Audio?.playSuccess?.();
            KennethGame.Particles?.emitConfetti?.();
            KennethGame.Particles?.flash?.('#ffd700', 200);
            
            // Show completion modal
            KennethGame.UI?.showLevelComplete?.({
                score,
                stars,
                target: currentLevel.targetScore,
                connections: levelStats.connectionsFormed,
                synergies: levelStats.synergiesCreated,
                timeBonus: Math.floor(timeRemaining * (CONSTANTS?.SCORING?.TIME_BONUS_RATE || 3)),
                xpEarned: result.xpEarned,
                levelUp: result.levelUp,
                newLevel: result.newLevel,
                newAchievements: result.newAchievements
            });
            
            // Three-star celebration!
            if (stars === 3) {
                const message = KennethGame.Utils?.getEncouragement?.('onThreeStars') || 'AMAZING!';
                setTimeout(() => {
                    if (message) KennethGame.Utils?.showToast?.(message, 'success', 5000);
                }, 1500);
            }
        } else {
            // Time's up
            KennethGame.Audio?.playTimeUp?.();
            KennethGame.UI?.showGameOver?.({
                score,
                target: currentLevel.targetScore,
                tip: getRandomTip()
            });
        }
    }
    
    function pauseGame() {
        if (!isPlaying) return;
        isPaused = true;
        stopTimer();
        KennethGame.UI?.showPauseModal?.({
            score,
            timeRemaining
        });
    }
    
    function resumeGame() {
        if (!isPlaying) return;
        isPaused = false;
        startTimer();
        KennethGame.UI?.hidePauseModal?.();
    }
    
    function restartLevel() {
        if (currentLevel) {
            startLevel(currentLevel.id);
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // TIMER
    // ═══════════════════════════════════════════════════════════════════════
    
    function startTimer() {
        stopTimer();
        
        timerInterval = setInterval(() => {
            if (isPaused) return;
            
            timeRemaining--;
            
            // Update UI
            KennethGame.Renderer?.updateTimer?.(timeRemaining, currentLevel?.timeLimit || 180);
            
            // Time warnings
            const warningTime = CONSTANTS?.TIMERS?.WARNING_TIME || 60;
            const criticalTime = CONSTANTS?.TIMERS?.CRITICAL_TIME || 30;
            
            if (timeRemaining === warningTime) {
                KennethGame.Audio?.playWarning?.();
                KennethGame.Renderer?.setTimerWarning?.('warning');
            } else if (timeRemaining === criticalTime) {
                KennethGame.Audio?.playWarning?.();
                KennethGame.Renderer?.setTimerWarning?.('critical');
            }
            
            // Game over
            if (timeRemaining <= 0) {
                endLevel(false);
            }
        }, 1000);
    }
    
    function stopTimer() {
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // MODULE PLACEMENT
    // ═══════════════════════════════════════════════════════════════════════
    
    function canPlaceModule(moduleId, col, row) {
        // Check bounds
        if (col < 0 || col >= gridCols || row < 0 || row >= gridRows) {
            return false;
        }
        
        // Check if cell is occupied
        if (grid[row][col] !== null) {
            return false;
        }
        
        // Check if module is available
        const trayModule = availableModules.find(m => m.id === moduleId);
        if (!trayModule || trayModule.count <= 0) {
            return false;
        }
        
        return true;
    }
    
    function placeModule(moduleId, col, row) {
        if (!canPlaceModule(moduleId, col, row)) {
            KennethGame.Audio?.playError?.();
            return false;
        }
        
        const module = KennethGame.Modules.getById(moduleId);
        if (!module) return false;
        
        // Place on grid
        const placedModule = {
            ...module,
            col,
            row,
            placedAt: Date.now()
        };
        
        grid[row][col] = placedModule;
        placedModules.push(placedModule);
        
        // Reduce available count
        const trayModule = availableModules.find(m => m.id === moduleId);
        trayModule.count--;
        
        // Save to history for undo
        moveHistory.push({
            type: 'place',
            module: placedModule,
            col,
            row
        });
        
        // Update combo
        updateCombo();
        
        // Calculate score
        let points = calculatePlacementScore(placedModule, col, row);
        
        // Apply boost if active
        if (boostActive) {
            points *= 3;
            boostActive = false;
            KennethGame.Particles.flash('#ffd700', 100);
        }
        
        addScore(points);
        levelStats.modulesPlaced++;
        
        // Check for new connections
        const newConnections = findNewConnections(col, row);
        newConnections.forEach(conn => {
            connections.push(conn);
            levelStats.connectionsFormed++;
            
            const connPoints = calculateConnectionScore(conn);
            addScore(connPoints);
            
            // Visual feedback
            KennethGame.Renderer?.animateConnection?.(conn);
            KennethGame.Audio?.playConnection?.();
            
            // Particles along connection
            const cell1 = KennethGame.Renderer?.getCellPosition?.(conn.from.col, conn.from.row);
            const cell2 = KennethGame.Renderer?.getCellPosition?.(conn.to.col, conn.to.row);
            if (cell1 && cell2) {
                KennethGame.Particles?.emitConnection?.(cell1.x, cell1.y, {
                    endX: cell2.x,
                    endY: cell2.y,
                    color: CONSTANTS?.CONNECTION_TYPES?.[conn.type]?.color
                });
            }
        });
        
        // Check for synergies
        const newSynergies = checkSynergies();
        newSynergies.forEach(synergy => {
            if (!activeSynergies.find(s => s.id === synergy.id)) {
                activeSynergies.push(synergy);
                levelStats.synergiesCreated++;
                
                addScore(synergy.bonus);
                
                // Big celebration!
                KennethGame.Audio?.playSynergy?.();
                const cellPos = KennethGame.Renderer?.getCellPosition?.(col, row);
                if (cellPos) {
                    KennethGame.Particles?.emitSynergy?.(cellPos.x, cellPos.y);
                }
                KennethGame.Particles?.shake?.(8, 300);
                
                // Show synergy message
                const message = KennethGame.Utils?.getEncouragement?.('onSynergy') || 'Amazing!';
                showFloatingMessage(`${synergy.name}! +${synergy.bonus}`);
                KennethGame.Utils?.showToast?.(`${message} ${synergy.name}!`, 'success');
                
                KennethGame.Renderer?.addSynergyToPanel?.(synergy);
            }
        });
        
        // Show encouragement occasionally
        if (Math.random() < 0.3 && newConnections.length > 0) {
            const message = KennethGame.Utils?.getEncouragement?.('onConnection') || 'Nice connection!';
            KennethGame.Utils?.showToast?.(message, 'info', 2000);
        } else if (Math.random() < 0.4) {
            const message = KennethGame.Utils?.getEncouragement?.('onModulePlace') || 'Great!';
            showFeedback(message);
        }
        
        // Visual feedback
        KennethGame.Audio?.playPlacement?.();
        KennethGame.Renderer?.animatePlacement?.(col, row);
        const pos = KennethGame.Renderer?.getCellPosition?.(col, row);
        if (pos) {
            KennethGame.Particles?.emitPlacement?.(pos.x, pos.y);
            KennethGame.Particles?.emitScore?.(pos.x, pos.y - 30, points);
        }
        
        // Update render
        KennethGame.Renderer.updateCell(col, row, placedModule);
        KennethGame.Renderer.updateModuleTray(availableModules);
        KennethGame.Renderer.updateConnections(connections);
        updateUI();
        
        // Check objectives
        checkObjectives();
        
        // Check if level is complete
        checkLevelComplete();
        
        return true;
    }
    
    function removeModule(col, row) {
        if (grid[row][col] === null) return false;
        
        const module = grid[row][col];
        
        // Remove from grid
        grid[row][col] = null;
        
        // Remove from placed modules
        const index = placedModules.findIndex(m => m.col === col && m.row === row);
        if (index !== -1) {
            placedModules.splice(index, 1);
        }
        
        // Restore to tray
        const trayModule = availableModules.find(m => m.id === module.id);
        if (trayModule) {
            trayModule.count++;
        }
        
        // Remove connections involving this cell
        connections = connections.filter(conn => 
            !(conn.from.col === col && conn.from.row === row) &&
            !(conn.to.col === col && conn.to.row === row)
        );
        
        // Recalculate synergies
        recalculateSynergies();
        
        // Update render
        KennethGame.Renderer.updateCell(col, row, null);
        KennethGame.Renderer.updateModuleTray(availableModules);
        KennethGame.Renderer.updateConnections(connections);
        KennethGame.Renderer.updateSynergiesPanel(activeSynergies);
        
        return true;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // SCORING
    // ═══════════════════════════════════════════════════════════════════════
    
    function calculatePlacementScore(module, col, row) {
        let points = CONSTANTS.SCORING.BASE_PLACEMENT;
        points += module.basePoints || 0;
        return Math.floor(points * combo);
    }
    
    function calculateConnectionScore(connection) {
        let points = CONSTANTS.SCORING.CONNECTION_POINTS;
        
        // Bonus for matching types
        if (connection.from.portType === connection.to.portType) {
            points += CONSTANTS.SCORING.PERFECT_CONNECTION;
        }
        
        // Add type-specific bonus
        const typeBonus = CONSTANTS.CONNECTION_TYPES[connection.type]?.bonusPoints || 0;
        points += typeBonus;
        
        return Math.floor(points * combo);
    }
    
    function addScore(points) {
        score += points;
        
        // Check for target reached
        if (score >= currentLevel.targetScore) {
            KennethGame.Renderer.highlightTargetReached();
        }
        
        updateUI();
    }
    
    function updateCombo() {
        const now = Date.now();
        const timeSinceLast = now - lastPlacementTime;
        
        if (timeSinceLast < CONSTANTS.TIMERS.COMBO_DECAY) {
            // Increase combo
            combo = Math.min(
                CONSTANTS.SCORING.MAX_COMBO,
                combo + CONSTANTS.SCORING.COMBO_INCREMENT
            );
            
            if (combo > levelStats.maxCombo) {
                levelStats.maxCombo = combo;
            }
            
            // Combo effects
            if (combo >= 2.0) {
                KennethGame.Audio.playCombo(Math.floor(combo));
                const pos = KennethGame.Renderer.getCellPosition(gridCols / 2, gridRows / 2);
                KennethGame.Particles.emitCombo(pos.x, pos.y, combo);
                
                if (combo >= 3.0 && Math.random() < 0.5) {
                    const message = KennethGame.Utils.getEncouragement('onCombo');
                    showFloatingMessage(`COMBO x${combo.toFixed(1)}!`);
                }
            }
        } else {
            // Reset combo
            combo = 1.0;
        }
        
        lastPlacementTime = now;
        KennethGame.Renderer.updateCombo(combo);
    }
    
    function calculateStars() {
        const percent = score / currentLevel.targetScore;
        const thresholds = currentLevel.starThresholds || {
            one: currentLevel.targetScore * 0.4,
            two: currentLevel.targetScore * 0.7,
            three: currentLevel.targetScore * 0.95
        };
        
        if (score >= thresholds.three) return 3;
        if (score >= thresholds.two) return 2;
        if (score >= thresholds.one) return 1;
        return 0;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // CONNECTIONS
    // ═══════════════════════════════════════════════════════════════════════
    
    function findNewConnections(col, row) {
        const module = grid[row][col];
        if (!module) return [];
        
        const newConnections = [];
        const adjacentCells = KennethGame.Utils.getAdjacentCells(col, row);
        
        adjacentCells.forEach(adj => {
            // Check bounds
            if (adj.col < 0 || adj.col >= gridCols || adj.row < 0 || adj.row >= gridRows) {
                return;
            }
            
            const adjModule = grid[adj.row][adj.col];
            if (!adjModule) return;
            
            // Check if already connected
            const alreadyConnected = connections.some(conn =>
                (conn.from.col === col && conn.from.row === row && 
                 conn.to.col === adj.col && conn.to.row === adj.row) ||
                (conn.to.col === col && conn.to.row === row && 
                 conn.from.col === adj.col && conn.from.row === adj.row)
            );
            if (alreadyConnected) return;
            
            // Get ports
            const myPort = module.ports[adj.direction];
            const theirPort = adjModule.ports[KennethGame.Utils.getOppositePort(adj.direction)];
            
            if (!myPort || !theirPort) return;
            
            // Check compatibility
            if (KennethGame.Modules.arePortsCompatible(myPort, theirPort)) {
                newConnections.push({
                    from: { col, row, portType: myPort, module },
                    to: { col: adj.col, row: adj.row, portType: theirPort, module: adjModule },
                    type: myPort === 'universal' ? theirPort : myPort,
                    direction: adj.direction
                });
            }
        });
        
        return newConnections;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // SYNERGIES
    // ═══════════════════════════════════════════════════════════════════════
    
    function checkSynergies() {
        const newSynergies = [];
        const allSynergies = CONSTANTS.SYNERGIES;
        const placedIds = placedModules.map(m => m.id);
        
        Object.entries(allSynergies).forEach(([id, synergy]) => {
            // Check if we have all required modules
            const hasAll = synergy.modules.every(reqModule => placedIds.includes(reqModule));
            
            if (hasAll) {
                // Check if modules are connected
                const areConnected = checkModulesConnected(synergy.modules);
                
                if (areConnected && !activeSynergies.find(s => s.id === id)) {
                    newSynergies.push({
                        id,
                        ...synergy
                    });
                }
            }
        });
        
        return newSynergies;
    }
    
    function checkModulesConnected(moduleIds) {
        // Find all placed instances of required modules
        const requiredModules = placedModules.filter(m => moduleIds.includes(m.id));
        
        if (requiredModules.length < moduleIds.length) return false;
        
        // Check if they form a connected graph
        // For simplicity, just check if any of them are connected to each other
        for (let i = 0; i < requiredModules.length; i++) {
            for (let j = i + 1; j < requiredModules.length; j++) {
                const connected = areModulesConnected(requiredModules[i], requiredModules[j]);
                if (connected) return true;
            }
        }
        
        return requiredModules.length <= 2; // If only 1-2 modules, they don't need direct connection
    }
    
    function areModulesConnected(module1, module2) {
        // Direct connection
        const directConn = connections.some(conn =>
            (conn.from.col === module1.col && conn.from.row === module1.row &&
             conn.to.col === module2.col && conn.to.row === module2.row) ||
            (conn.to.col === module1.col && conn.to.row === module1.row &&
             conn.from.col === module2.col && conn.from.row === module2.row)
        );
        
        if (directConn) return true;
        
        // Check for indirect connection (through other modules)
        return findPath(module1, module2) !== null;
    }
    
    function findPath(start, end, visited = new Set()) {
        const key = `${start.col},${start.row}`;
        if (visited.has(key)) return null;
        visited.add(key);
        
        // Direct connection
        const directConnections = connections.filter(conn =>
            (conn.from.col === start.col && conn.from.row === start.row) ||
            (conn.to.col === start.col && conn.to.row === start.row)
        );
        
        for (const conn of directConnections) {
            const next = conn.from.col === start.col && conn.from.row === start.row
                ? { col: conn.to.col, row: conn.to.row }
                : { col: conn.from.col, row: conn.from.row };
            
            if (next.col === end.col && next.row === end.row) {
                return [start, end];
            }
            
            const nextModule = grid[next.row][next.col];
            if (nextModule) {
                const path = findPath(nextModule, end, visited);
                if (path) return [start, ...path];
            }
        }
        
        return null;
    }
    
    function recalculateSynergies() {
        activeSynergies = [];
        const newSynergies = checkSynergies();
        newSynergies.forEach(s => activeSynergies.push(s));
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // OBJECTIVES
    // ═══════════════════════════════════════════════════════════════════════
    
    function checkObjectives() {
        if (!currentLevel.objectives) return;
        
        const objectives = currentLevel.objectives.map(obj => {
            let completed = false;
            
            switch (obj.type) {
                case 'place':
                    const placedCount = placedModules.filter(m => m.id === obj.moduleId).length;
                    completed = placedCount >= obj.count;
                    break;
                    
                case 'connect':
                    completed = levelStats.connectionsFormed >= obj.count;
                    break;
                    
                case 'synergy':
                    if (obj.synergyId) {
                        completed = activeSynergies.some(s => s.id === obj.synergyId);
                    } else {
                        completed = levelStats.synergiesCreated >= (obj.count || 1);
                    }
                    break;
                    
                case 'score':
                    completed = score >= obj.amount;
                    break;
                    
                case 'combo':
                    completed = levelStats.maxCombo >= obj.multiplier;
                    break;
            }
            
            return { ...obj, completed };
        });
        
        KennethGame.Renderer.updateObjectives(objectives);
    }
    
    function checkLevelComplete() {
        if (!currentLevel.objectives) {
            // No objectives - just check score
            if (score >= currentLevel.targetScore) {
                setTimeout(() => endLevel(true), 500);
            }
            return;
        }
        
        // Check all objectives
        const allComplete = currentLevel.objectives.every(obj => {
            switch (obj.type) {
                case 'place':
                    return placedModules.filter(m => m.id === obj.moduleId).length >= obj.count;
                case 'connect':
                    return levelStats.connectionsFormed >= obj.count;
                case 'synergy':
                    if (obj.synergyId) {
                        return activeSynergies.some(s => s.id === obj.synergyId);
                    }
                    return levelStats.synergiesCreated >= (obj.count || 1);
                case 'score':
                    return score >= obj.amount;
                case 'combo':
                    return levelStats.maxCombo >= obj.multiplier;
                default:
                    return true;
            }
        });
        
        if (allComplete && score >= currentLevel.targetScore) {
            setTimeout(() => endLevel(true), 500);
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // POWER-UPS
    // ═══════════════════════════════════════════════════════════════════════
    
    function usePowerUp(type) {
        if (!KennethGame.State.usePowerUp(type)) {
            KennethGame.Utils.showToast('No more of this power-up!', 'warning');
            return false;
        }
        
        KennethGame.Audio.playPowerUp();
        
        switch (type) {
            case 'hint':
                showHint();
                levelStats.hintsUsed++;
                break;
                
            case 'undo':
                undoLastMove();
                levelStats.undosUsed++;
                break;
                
            case 'boost':
                boostActive = true;
                KennethGame.Utils?.showToast?.('🚀 Next placement gives 3x points!', 'success');
                KennethGame.Particles?.flash?.('#ffd700', 150);
                break;
                
            case 'time':
                timeRemaining += 30;
                KennethGame.Utils?.showToast?.('⏰ +30 seconds!', 'success');
                KennethGame.Particles?.flash?.('#00ff88', 150);
                break;
                
            case 'shuffle':
                shuffleModules();
                break;
                
            case 'superConnect':
                activateSuperConnect();
                break;
        }
        
        KennethGame.Renderer?.updatePowerUps?.();
        return true;
    }
    
    function showHint() {
        // Find best placement
        let bestCell = null;
        let bestScore = 0;
        
        availableModules.forEach(mod => {
            if (mod.count <= 0) return;
            
            for (let row = 0; row < gridRows; row++) {
                for (let col = 0; col < gridCols; col++) {
                    if (grid[row][col] !== null) continue;
                    
                    // Temporarily place and score
                    const potentialConnections = countPotentialConnections(mod.id, col, row);
                    const score = potentialConnections * 50 + (mod.basePoints || 0);
                    
                    if (score > bestScore) {
                        bestScore = score;
                        bestCell = { col, row, moduleId: mod.id };
                    }
                }
            }
        });
        
        if (bestCell) {
            KennethGame.Renderer?.highlightHint?.(bestCell.col, bestCell.row);
            const moduleName = KennethGame.Modules?.getById?.(bestCell.moduleId)?.name || 'module';
            KennethGame.Utils?.showToast?.(`💡 Try placing ${moduleName} here!`, 'info');
        }
    }
    
    function countPotentialConnections(moduleId, col, row) {
        const module = KennethGame.Modules?.getById?.(moduleId);
        if (!module) return 0;
        let count = 0;
        
        const adjacent = KennethGame.Utils?.getAdjacentCells?.(col, row) || [];
        adjacent.forEach(adj => {
            if (adj.col < 0 || adj.col >= gridCols || adj.row < 0 || adj.row >= gridRows) return;
            
            const adjModule = grid[adj.row]?.[adj.col];
            if (!adjModule) return;
            
            const myPort = module.ports?.[adj.direction];
            const theirPort = adjModule.ports?.[KennethGame.Utils?.getOppositePort?.(adj.direction)];
            
            if (myPort && theirPort && KennethGame.Modules?.arePortsCompatible?.(myPort, theirPort)) {
                count++;
            }
        });
        
        return count;
    }
    
    function undoLastMove() {
        if (moveHistory.length === 0) {
            KennethGame.Utils?.showToast?.('Nothing to undo!', 'warning');
            return;
        }
        
        const lastMove = moveHistory.pop();
        
        if (lastMove.type === 'place') {
            removeModule(lastMove.col, lastMove.row);
            KennethGame.Utils?.showToast?.('↩️ Move undone!', 'info');
        }
    }
    
    function shuffleModules() {
        // Reset module counts
        availableModules.forEach(mod => {
            mod.count = mod.originalCount - placedModules.filter(p => p.id === mod.id).length;
        });
        
        // Shuffle order
        for (let i = availableModules.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [availableModules[i], availableModules[j]] = [availableModules[j], availableModules[i]];
        }
        
        KennethGame.Renderer?.updateModuleTray?.(availableModules);
        KennethGame.Utils?.showToast?.('🔀 Modules shuffled!', 'success');
    }
    
    function activateSuperConnect() {
        KennethGame.Utils?.showToast?.('🌟 Super Connect activated for 10 seconds!', 'success');
        // This would temporarily make all ports universal
        // Implementation would require modifying connection logic
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════════════════
    
    function updateUI() {
        KennethGame.Renderer?.updateUI?.({
            score,
            target: currentLevel?.targetScore || 0,
            time: timeRemaining,
            combo
        });
    }
    
    function showFeedback(message) {
        KennethGame.Renderer?.showFeedback?.(message);
    }
    
    function showFloatingMessage(message) {
        const floating = document.getElementById('floating-message');
        if (floating) {
            floating.textContent = message;
            floating.classList.add('active');
            setTimeout(() => floating.classList.remove('active'), 1500);
        }
    }
    
    function getRandomTip() {
        const tips = CONSTANTS?.TIPS || ['Have fun, Kenneth!'];
        return tips[Math.floor(Math.random() * tips.length)];
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // GETTERS
    // ═══════════════════════════════════════════════════════════════════════
    
    function getState() {
        return {
            isPlaying,
            isPaused,
            currentLevel,
            score,
            combo,
            timeRemaining,
            connections: connections.length,
            synergies: activeSynergies.length,
            modulesPlaced: placedModules.length
        };
    }
    
    function getGrid() {
        return grid;
    }
    
    function getAvailableModules() {
        return availableModules;
    }

    /**
     * Initialize game logic (called by main.js)
     */
    function init() {
        console.log('🎮 Game Logic initialized!');
    }

    /**
     * Check if game is currently playing
     * @returns {boolean}
     */
    function checkIsPlaying() {
        return isPlaying;
    }

    /**
     * Pause the game (called from main.js visibility handler)
     */
    function pause() {
        if (isPlaying && !isPaused) {
            pauseGame();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // ADDITIONAL GETTERS & ALIASES
    // ═══════════════════════════════════════════════════════════════════════

    function getScore() {
        return score;
    }

    function getTimeLeft() {
        return timeRemaining;
    }

    function quit() {
        endLevel();
        KennethGame.UI?.showScreen('menu');
    }

    function startSandbox() {
        // Create sandbox level configuration
        currentLevel = {
            id: 'sandbox',
            name: 'Sandbox Mode',
            targetScore: Infinity,
            timeLimit: 0,
            gridSize: { cols: 8, rows: 6 },
            availableModules: KennethGame.Modules?.getAll().map(m => m.id) || [],
            objectives: []
        };

        gridCols = 8;
        gridRows = 6;
        grid = createEmptyGrid(gridCols, gridRows);
        score = 0;
        combo = 1.0;
        connections = [];
        activeSynergies = [];
        placedModules = [];
        availableModules = KennethGame.Modules?.getAll() || [];
        timeRemaining = 0;
        isPlaying = true;
        isPaused = false;

        KennethGame.Renderer?.renderGrid(grid, gridCols, gridRows);
        KennethGame.Renderer?.renderModuleTray(availableModules);
        KennethGame.Renderer?.updateUI({ score, combo, timeRemaining, objectives: [] });

        console.log('🧪 Sandbox mode started!');
        return true;
    }

    function getNextLevel() {
        if (!currentLevel) return null;
        return KennethGame.Levels?.getNextLevel(currentLevel.id) || null;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════

    return {
        init,
        startLevel,
        startSandbox,
        endLevel,
        pauseGame,
        resumeGame,
        restartLevel,
        canPlaceModule,
        placeModule,
        removeModule,
        usePowerUp,
        getState,
        getGrid,
        getAvailableModules,
        getScore,
        getTimeLeft,
        getNextLevel,
        isPlaying: checkIsPlaying,
        // Aliases for UI compatibility
        pause: pauseGame,
        resume: resumeGame,
        restart: restartLevel,
        quit
    };
})();
