/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - Particles System
 * SPECTACULAR visual effects for maximum fun!
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

KennethGame.Particles = (function() {
    
    let canvas = null;
    let ctx = null;
    let particles = [];
    let animationId = null;
    let isRunning = false;
    
    const CONSTANTS = KennethGame.CONSTANTS;
    
    // ═══════════════════════════════════════════════════════════════════════
    // INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════
    
    function init() {
        canvas = document.getElementById('particle-canvas');
        if (!canvas) {
            console.warn('Particles: Canvas not found');
            return;
        }
        
        ctx = canvas.getContext('2d');
        resizeCanvas();
        
        window.addEventListener('resize', resizeCanvas);
        
        // Start ambient particles
        startAmbient();
        
        console.log('✨ Particles system initialized!');
    }
    
    function resizeCanvas() {
        if (!canvas) return;
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // PARTICLE CLASS
    // ═══════════════════════════════════════════════════════════════════════
    
    class Particle {
        constructor(options = {}) {
            this.x = options.x || 0;
            this.y = options.y || 0;
            this.vx = options.vx || 0;
            this.vy = options.vy || 0;
            this.size = options.size || 4;
            this.color = options.color || '#00f5ff';
            this.alpha = options.alpha || 1;
            this.life = options.life || 1000;
            this.maxLife = this.life;
            this.gravity = options.gravity || 0;
            this.friction = options.friction || 0.99;
            this.shrink = options.shrink !== false;
            this.type = options.type || 'circle';
            this.rotation = options.rotation || 0;
            this.rotationSpeed = options.rotationSpeed || 0;
            this.glow = options.glow || false;
        }
        
        update(deltaTime) {
            // Apply gravity
            this.vy += this.gravity * deltaTime;
            
            // Apply velocity
            this.x += this.vx * deltaTime;
            this.y += this.vy * deltaTime;
            
            // Apply friction
            this.vx *= this.friction;
            this.vy *= this.friction;
            
            // Rotation
            this.rotation += this.rotationSpeed * deltaTime;
            
            // Reduce life
            this.life -= deltaTime * 1000;
            
            // Fade and shrink
            const lifeRatio = this.life / this.maxLife;
            this.alpha = lifeRatio;
            if (this.shrink) {
                this.currentSize = this.size * lifeRatio;
            } else {
                this.currentSize = this.size;
            }
            
            return this.life > 0;
        }
        
        draw(ctx) {
            ctx.save();
            ctx.globalAlpha = this.alpha;
            ctx.translate(this.x, this.y);
            ctx.rotate(this.rotation);
            
            if (this.glow) {
                ctx.shadowBlur = 10;
                ctx.shadowColor = this.color;
            }
            
            ctx.fillStyle = this.color;
            
            switch (this.type) {
                case 'circle':
                    ctx.beginPath();
                    ctx.arc(0, 0, this.currentSize, 0, Math.PI * 2);
                    ctx.fill();
                    break;
                    
                case 'square':
                    ctx.fillRect(-this.currentSize, -this.currentSize, 
                        this.currentSize * 2, this.currentSize * 2);
                    break;
                    
                case 'star':
                    this.drawStar(ctx, this.currentSize);
                    break;
                    
                case 'confetti':
                    ctx.fillRect(-this.currentSize, -this.currentSize / 3, 
                        this.currentSize * 2, this.currentSize * 0.6);
                    break;
                    
                case 'spark':
                    ctx.beginPath();
                    ctx.moveTo(-this.currentSize * 2, 0);
                    ctx.lineTo(this.currentSize * 2, 0);
                    ctx.lineWidth = 2;
                    ctx.strokeStyle = this.color;
                    ctx.stroke();
                    break;
            }
            
            ctx.restore();
        }
        
        drawStar(ctx, size) {
            const spikes = 5;
            const outerRadius = size;
            const innerRadius = size * 0.5;
            
            ctx.beginPath();
            for (let i = 0; i < spikes * 2; i++) {
                const radius = i % 2 === 0 ? outerRadius : innerRadius;
                const angle = (i * Math.PI) / spikes - Math.PI / 2;
                const x = Math.cos(angle) * radius;
                const y = Math.sin(angle) * radius;
                
                if (i === 0) {
                    ctx.moveTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                }
            }
            ctx.closePath();
            ctx.fill();
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // AMBIENT PARTICLES
    // ═══════════════════════════════════════════════════════════════════════
    
    function startAmbient() {
        if (isRunning) return;
        isRunning = true;
        
        // Create initial ambient particles
        const config = CONSTANTS.PARTICLES.AMBIENT;
        for (let i = 0; i < config.count; i++) {
            createAmbientParticle();
        }
        
        // Start animation loop
        let lastTime = performance.now();
        
        function animate(currentTime) {
            if (!isRunning) return;
            
            const deltaTime = (currentTime - lastTime) / 1000;
            lastTime = currentTime;
            
            // Clear canvas
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // Update and draw particles
            particles = particles.filter(particle => {
                const alive = particle.update(deltaTime);
                if (alive) {
                    particle.draw(ctx);
                }
                return alive;
            });
            
            // Maintain ambient particle count
            const ambientCount = particles.filter(p => p.isAmbient).length;
            if (ambientCount < config.count / 2) {
                createAmbientParticle();
            }
            
            animationId = requestAnimationFrame(animate);
        }
        
        animationId = requestAnimationFrame(animate);
    }
    
    function createAmbientParticle() {
        const config = CONSTANTS.PARTICLES.AMBIENT;
        const particle = new Particle({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * config.speed.max * 50,
            vy: (Math.random() - 0.5) * config.speed.max * 50,
            size: config.size.min + Math.random() * (config.size.max - config.size.min),
            color: config.colors[Math.floor(Math.random() * config.colors.length)],
            alpha: config.opacity.min + Math.random() * (config.opacity.max - config.opacity.min),
            life: 10000 + Math.random() * 20000,
            friction: 1,
            shrink: false,
            glow: true
        });
        particle.isAmbient = true;
        particles.push(particle);
    }
    
    function stopAmbient() {
        isRunning = false;
        if (animationId) {
            cancelAnimationFrame(animationId);
            animationId = null;
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // EFFECT EMITTERS
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Emit particles at a position
     */
    function emit(x, y, type, options = {}) {
        const settings = KennethGame.State?.getSettings();
        if (settings && !settings.particlesEnabled) return;
        
        switch (type) {
            case 'placement':
                emitPlacement(x, y);
                break;
            case 'connection':
                emitConnection(x, y, options);
                break;
            case 'synergy':
                emitSynergy(x, y);
                break;
            case 'combo':
                emitCombo(x, y, options.level || 1);
                break;
            case 'confetti':
                emitConfetti();
                break;
            case 'star':
                emitStar(x, y);
                break;
            case 'score':
                emitScore(x, y, options.amount || 100);
                break;
            case 'burst':
                emitBurst(x, y, options);
                break;
        }
    }
    
    /**
     * Module placement particles
     */
    function emitPlacement(x, y) {
        const config = CONSTANTS.PARTICLES.PLACEMENT;
        
        for (let i = 0; i < config.count; i++) {
            const angle = (Math.PI * 2 * i) / config.count;
            const speed = config.speed.min + Math.random() * (config.speed.max - config.speed.min);
            
            particles.push(new Particle({
                x,
                y,
                vx: Math.cos(angle) * speed * 30,
                vy: Math.sin(angle) * speed * 30,
                size: config.size.min + Math.random() * (config.size.max - config.size.min),
                color: config.colors[Math.floor(Math.random() * config.colors.length)],
                life: config.lifetime,
                glow: true
            }));
        }
    }
    
    /**
     * Connection particles - travel along a line
     */
    function emitConnection(x, y, options = {}) {
        const config = CONSTANTS.PARTICLES.CONNECTION;
        const endX = options.endX || x + 50;
        const endY = options.endY || y;
        
        for (let i = 0; i < config.count; i++) {
            const t = i / config.count;
            const px = x + (endX - x) * t;
            const py = y + (endY - y) * t;
            
            particles.push(new Particle({
                x: px + (Math.random() - 0.5) * 10,
                y: py + (Math.random() - 0.5) * 10,
                vx: (Math.random() - 0.5) * 50,
                vy: (Math.random() - 0.5) * 50,
                size: config.size.min + Math.random() * (config.size.max - config.size.min),
                color: options.color || config.colors[Math.floor(Math.random() * config.colors.length)],
                life: config.lifetime + Math.random() * 200,
                glow: true,
                type: 'spark'
            }));
        }
    }
    
    /**
     * Synergy particles - big magical burst!
     */
    function emitSynergy(x, y) {
        const config = CONSTANTS.PARTICLES.SYNERGY;
        
        // Create burst effect
        for (let i = 0; i < config.count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = config.speed.min + Math.random() * (config.speed.max - config.speed.min);
            
            particles.push(new Particle({
                x,
                y,
                vx: Math.cos(angle) * speed * 40,
                vy: Math.sin(angle) * speed * 40,
                size: config.size.min + Math.random() * (config.size.max - config.size.min),
                color: config.colors[Math.floor(Math.random() * config.colors.length)],
                life: config.lifetime,
                type: Math.random() > 0.5 ? 'star' : 'circle',
                rotationSpeed: (Math.random() - 0.5) * 5,
                glow: true
            }));
        }
        
        // Add expanding ring
        const ringCount = 20;
        for (let i = 0; i < ringCount; i++) {
            const angle = (Math.PI * 2 * i) / ringCount;
            
            particles.push(new Particle({
                x,
                y,
                vx: Math.cos(angle) * 100,
                vy: Math.sin(angle) * 100,
                size: 3,
                color: '#ffd700',
                life: 500,
                friction: 0.95,
                glow: true
            }));
        }
    }
    
    /**
     * Combo particles - fiery trail!
     */
    function emitCombo(x, y, level) {
        const config = CONSTANTS.PARTICLES.COMBO;
        const count = Math.min(config.count * level, 60);
        
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = config.speed.min + Math.random() * (config.speed.max - config.speed.min);
            
            particles.push(new Particle({
                x: x + (Math.random() - 0.5) * 30,
                y: y + (Math.random() - 0.5) * 30,
                vx: Math.cos(angle) * speed * 30,
                vy: Math.sin(angle) * speed * 30 - 50, // Upward bias
                size: config.size.min + Math.random() * (config.size.max - config.size.min),
                color: config.colors[Math.floor(Math.random() * config.colors.length)],
                life: config.lifetime,
                gravity: -0.5, // Rise up
                type: 'circle',
                glow: true
            }));
        }
    }
    
    /**
     * Confetti celebration!
     */
    function emitConfetti() {
        const config = CONSTANTS.PARTICLES.CONFETTI;
        
        for (let i = 0; i < config.count; i++) {
            const startX = Math.random() * canvas.width;
            const startY = -20;
            
            particles.push(new Particle({
                x: startX,
                y: startY,
                vx: (Math.random() - 0.5) * 100,
                vy: config.speed.min + Math.random() * (config.speed.max - config.speed.min) * 50,
                size: config.size.min + Math.random() * (config.size.max - config.size.min),
                color: config.colors[Math.floor(Math.random() * config.colors.length)],
                life: config.lifetime,
                gravity: 0.2,
                friction: 0.995,
                type: 'confetti',
                rotationSpeed: (Math.random() - 0.5) * 10,
                shrink: false
            }));
        }
    }
    
    /**
     * Star earned effect
     */
    function emitStar(x, y) {
        // Central star burst
        for (let i = 0; i < 20; i++) {
            const angle = (Math.PI * 2 * i) / 20;
            
            particles.push(new Particle({
                x,
                y,
                vx: Math.cos(angle) * 80,
                vy: Math.sin(angle) * 80,
                size: 4 + Math.random() * 4,
                color: '#ffd700',
                life: 600,
                type: 'star',
                rotationSpeed: 3,
                glow: true
            }));
        }
        
        // Golden sparkles
        for (let i = 0; i < 15; i++) {
            particles.push(new Particle({
                x: x + (Math.random() - 0.5) * 40,
                y: y + (Math.random() - 0.5) * 40,
                vx: (Math.random() - 0.5) * 60,
                vy: (Math.random() - 0.5) * 60 - 30,
                size: 2 + Math.random() * 3,
                color: '#ffee88',
                life: 800,
                glow: true
            }));
        }
    }
    
    /**
     * Score popup particles
     */
    function emitScore(x, y, amount) {
        // Create floating score text effect using particles
        const colors = amount >= 100 ? ['#ffd700', '#ffee88'] : ['#00f5ff', '#88ffff'];
        
        for (let i = 0; i < 8; i++) {
            particles.push(new Particle({
                x: x + (Math.random() - 0.5) * 20,
                y: y + (Math.random() - 0.5) * 20,
                vx: (Math.random() - 0.5) * 40,
                vy: -30 - Math.random() * 30,
                size: 3 + Math.random() * 3,
                color: colors[Math.floor(Math.random() * colors.length)],
                life: 500,
                friction: 0.98,
                glow: true
            }));
        }
    }
    
    /**
     * Generic burst effect
     */
    function emitBurst(x, y, options = {}) {
        const count = options.count || 20;
        const colors = options.colors || ['#00f5ff', '#ff00ff', '#00ff88'];
        const speed = options.speed || 100;
        
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const spd = speed * (0.5 + Math.random() * 0.5);
            
            particles.push(new Particle({
                x,
                y,
                vx: Math.cos(angle) * spd,
                vy: Math.sin(angle) * spd,
                size: 3 + Math.random() * 5,
                color: colors[Math.floor(Math.random() * colors.length)],
                life: options.life || 600,
                friction: 0.95,
                glow: true
            }));
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // SPECIAL EFFECTS
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Screen flash effect
     */
    function flash(color = '#ffffff', duration = 150) {
        const settings = KennethGame.State?.getSettings();
        if (settings && !settings.particlesEnabled) return;
        
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: ${color};
            opacity: 0.3;
            pointer-events: none;
            z-index: 9999;
            transition: opacity ${duration}ms ease-out;
        `;
        
        document.body.appendChild(overlay);
        
        requestAnimationFrame(() => {
            overlay.style.opacity = '0';
            setTimeout(() => overlay.remove(), duration);
        });
    }
    
    /**
     * Screen shake effect
     */
    function shake(intensity = 5, duration = 200) {
        const settings = KennethGame.State?.getSettings();
        if (settings && !settings.screenShakeEnabled) return;
        
        const gameScreen = document.getElementById('game-screen');
        if (!gameScreen) return;
        
        const startTime = performance.now();
        
        function doShake(currentTime) {
            const elapsed = currentTime - startTime;
            if (elapsed >= duration) {
                gameScreen.style.transform = '';
                return;
            }
            
            const remaining = 1 - elapsed / duration;
            const x = (Math.random() - 0.5) * intensity * remaining * 2;
            const y = (Math.random() - 0.5) * intensity * remaining * 2;
            
            gameScreen.style.transform = `translate(${x}px, ${y}px)`;
            requestAnimationFrame(doShake);
        }
        
        requestAnimationFrame(doShake);
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ═══════════════════════════════════════════════════════════════════════
    
    return {
        init,
        emit,
        flash,
        shake,
        startAmbient,
        stopAmbient,
        emitPlacement,
        emitConnection,
        emitSynergy,
        emitCombo,
        emitConfetti,
        emitStar,
        emitScore,
        emitBurst
    };
})();
