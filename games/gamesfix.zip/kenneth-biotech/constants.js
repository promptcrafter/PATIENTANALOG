/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - Constants & Configuration
 * 10X MORE DEPTH! More modules, synergies, combos, and FUN!
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

// Initialize the single global namespace
window.KennethGame = window.KennethGame || {};

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * GAME CONSTANTS - Everything Kenneth needs!
 * ═══════════════════════════════════════════════════════════════════════════
 */
KennethGame.CONSTANTS = Object.freeze({
    
    // ═══════════════════════════════════════════════════════════════════════
    // VERSION & META
    // ═══════════════════════════════════════════════════════════════════════
    VERSION: '2.0.0',
    GAME_NAME: "Kenneth's AMAZING Biotech Adventure",
    
    // ═══════════════════════════════════════════════════════════════════════
    // GRID CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════════
    GRID: {
        CELL_SIZE: 70,           // Bigger cells for easier interaction!
        GAP: 6,
        DEFAULT_COLS: 6,
        DEFAULT_ROWS: 5,
        SANDBOX_COLS: 10,
        SANDBOX_ROWS: 8,
        MAX_COLS: 12,
        MAX_ROWS: 10
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // SCORING SYSTEM - Rewarding and Fun!
    // ═══════════════════════════════════════════════════════════════════════
    SCORING: {
        // Base Points
        BASE_PLACEMENT: 50,          // Points for placing any module
        CONNECTION_POINTS: 25,        // Points per connection made
        PERFECT_CONNECTION: 100,      // Bonus for matching port types exactly
        
        // Synergy Bonuses
        SYNERGY_MULTIPLIER: 1.5,     // Base synergy multiplier
        MEGA_SYNERGY_BONUS: 500,     // Bonus for 3+ connected synergy modules
        CHAIN_BONUS_PER_LINK: 50,    // Bonus per module in a chain
        
        // Combo System
        COMBO_INCREMENT: 0.2,        // Combo increases by 0.2 per quick placement
        MAX_COMBO: 5.0,              // Maximum combo multiplier (5x!)
        COMBO_DECAY_TIME: 3000,      // Combo resets after 3 seconds
        
        // Time Bonuses
        TIME_BONUS_RATE: 3,          // Points per second remaining
        EARLY_FINISH_BONUS: 200,     // Bonus for finishing with 50%+ time
        SPEED_BONUS_THRESHOLD: 0.7,  // Finish with 70% time = speed bonus
        SPEED_BONUS_AMOUNT: 150,
        
        // Efficiency Bonuses
        NO_MISTAKES_BONUS: 100,      // Perfect run (no undos)
        ALL_MODULES_USED_BONUS: 75,  // Used every available module
        
        // Star Thresholds (percentage of target score)
        STAR_THRESHOLDS: {
            ONE: 0.4,                // 40% = 1 star
            TWO: 0.7,                // 70% = 2 stars
            THREE: 0.95              // 95% = 3 stars (a bit easier!)
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // PROGRESSION SYSTEM
    // ═══════════════════════════════════════════════════════════════════════
    PROGRESSION: {
        BASE_XP: 100,
        LEVEL_XP_MULTIPLIER: 1.15,   // XP needed increases 15% per level
        XP_PER_STAR: 30,             // Extra XP per star earned
        XP_FOR_COMPLETION: 50,       // Just for finishing a level
        XP_FOR_NEW_HIGH_SCORE: 25,   // Beating your own record
        
        // Era Unlocks
        UNLOCK_THRESHOLDS: {
            ERA_2: 4,                // Level 4 unlocks Era 2
            ERA_3: 10,               // Level 10 unlocks Era 3
            ERA_4: 18                // Level 18 unlocks Era 4
        },
        
        // Module Unlocks (player level required)
        MODULE_UNLOCK_LEVELS: {
            // Basic modules - always available
            'heart': 1,
            'brain': 1,
            'liver': 1,
            'kidney': 1,
            'lung': 1,
            'blood_vessel': 1,
            'nerve_connector': 1,
            
            // Unlocked as Kenneth levels up
            'stomach': 2,
            'intestine': 2,
            'pancreas': 3,
            'spleen': 3,
            'bone_marrow': 4,
            'skin': 4,
            'muscle': 5,
            'eye': 5,
            
            // Organoids (Era 2)
            'brain_organoid': 6,
            'heart_organoid': 7,
            'liver_organoid': 8,
            'kidney_organoid': 9,
            'lung_organoid': 10,
            'gut_organoid': 11,
            'retina_organoid': 12,
            
            // MPS Systems (Era 3)
            'organ_chip': 13,
            'microfluidic_channel': 14,
            'bioreactor': 15,
            'sensor_array': 16,
            'perfusion_system': 17,
            
            // Digital & Advanced (Era 4)
            'digital_twin': 18,
            'ai_predictor': 19,
            'data_hub': 20,
            'quantum_analyzer': 21,
            'synth_tissue': 22
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // TIMERS & ANIMATIONS
    // ═══════════════════════════════════════════════════════════════════════
    TIMERS: {
        DEFAULT_LEVEL_TIME: 180,     // 3 minutes default
        EASY_LEVEL_TIME: 240,        // 4 minutes for easier levels
        HARD_LEVEL_TIME: 120,        // 2 minutes for challenges
        
        // Time warnings
        WARNING_TIME: 60,            // Orange warning at 60 seconds
        CRITICAL_TIME: 30,           // Red warning at 30 seconds
        
        // Animation timings (milliseconds)
        ANIMATION_INSTANT: 50,
        ANIMATION_FAST: 150,
        ANIMATION_MEDIUM: 300,
        ANIMATION_SLOW: 500,
        ANIMATION_VERY_SLOW: 1000,
        
        // Feedback timings
        TOAST_DURATION: 3500,
        ENCOURAGEMENT_DURATION: 2000,
        COMBO_DECAY: 3000,
        
        // Game flow
        LEVEL_START_DELAY: 500,
        LEVEL_END_DELAY: 1000,
        MODAL_TRANSITION: 300
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // MODULE TIERS - Visual Indicators
    // ═══════════════════════════════════════════════════════════════════════
    TIERS: {
        BASIC: {
            level: 1,
            name: 'Basic',
            color: '#4488ff',
            description: 'Fundamental bio-modules'
        },
        ORGANOID: {
            level: 2,
            name: 'Organoid',
            color: '#00ff88',
            description: 'Lab-grown mini-organs'
        },
        MPS: {
            level: 3,
            name: 'MPS',
            color: '#a855f7',
            description: 'Microphysiological systems'
        },
        ADVANCED: {
            level: 4,
            name: 'Advanced',
            color: '#ffd700',
            description: 'Cutting-edge technology'
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // CATEGORIES
    // ═══════════════════════════════════════════════════════════════════════
    CATEGORIES: {
        organs: {
            name: 'Organs',
            icon: '🫀',
            color: '#ff4466',
            description: 'Real human organs'
        },
        organoids: {
            name: 'Organoids',
            icon: '🧫',
            color: '#00ff88',
            description: 'Mini lab-grown organs'
        },
        mps: {
            name: 'MPS',
            icon: '🔬',
            color: '#a855f7',
            description: 'Microphysiological systems'
        },
        digital: {
            name: 'Digital',
            icon: '💻',
            color: '#00f5ff',
            description: 'Digital & AI components'
        },
        synthetic: {
            name: 'Synthetic',
            icon: '🧪',
            color: '#ff8c00',
            description: 'Engineered bio-parts'
        },
        connectors: {
            name: 'Connectors',
            icon: '🔗',
            color: '#ffd700',
            description: 'Connect other modules'
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // CONNECTION TYPES - The Heart of Gameplay!
    // ═══════════════════════════════════════════════════════════════════════
    CONNECTION_TYPES: {
        neural: {
            name: 'Neural',
            color: '#ff00ff',
            icon: '🧠',
            description: 'Carries brain signals and nerve impulses',
            compatibleWith: ['neural', 'data', 'universal'],
            bonusPoints: 30
        },
        vascular: {
            name: 'Vascular',
            color: '#ff4466',
            icon: '🩸',
            description: 'Carries blood and nutrients',
            compatibleWith: ['vascular', 'fluid', 'universal'],
            bonusPoints: 25
        },
        data: {
            name: 'Data',
            color: '#00f5ff',
            icon: '📡',
            description: 'Digital information transfer',
            compatibleWith: ['data', 'neural', 'universal'],
            bonusPoints: 35
        },
        energy: {
            name: 'Energy',
            color: '#ffd700',
            icon: '⚡',
            description: 'Powers systems with bio-energy',
            compatibleWith: ['energy', 'universal'],
            bonusPoints: 40
        },
        fluid: {
            name: 'Fluid',
            color: '#00ff88',
            icon: '💧',
            description: 'Carries fluids and chemicals',
            compatibleWith: ['fluid', 'vascular', 'universal'],
            bonusPoints: 25
        },
        universal: {
            name: 'Universal',
            color: '#ffffff',
            icon: '✨',
            description: 'Connects to ANY type!',
            compatibleWith: ['neural', 'vascular', 'data', 'energy', 'fluid', 'universal'],
            bonusPoints: 20
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // SYNERGIES - Special Combos Kenneth Can Discover!
    // ═══════════════════════════════════════════════════════════════════════
    SYNERGIES: {
        // Organ Synergies
        'cardiovascular_system': {
            name: '❤️ Cardiovascular System',
            modules: ['heart', 'blood_vessel', 'lung'],
            bonus: 200,
            description: 'Heart + Blood Vessels + Lungs = Complete circulation!',
            effect: 'All connected modules produce 2x points'
        },
        'nervous_system': {
            name: '🧠 Nervous System',
            modules: ['brain', 'nerve_connector', 'eye'],
            bonus: 250,
            description: 'Brain + Nerves + Eyes = Perfect perception!',
            effect: 'Unlocks neural cascade bonus'
        },
        'digestive_system': {
            name: '🍽️ Digestive System',
            modules: ['stomach', 'intestine', 'liver', 'pancreas'],
            bonus: 300,
            description: 'Complete digestive tract!',
            effect: '+50 points per second while active'
        },
        'excretory_system': {
            name: '💧 Excretory System',
            modules: ['kidney', 'liver', 'lung'],
            bonus: 175,
            description: 'Filtering and cleaning the body!',
            effect: 'Removes any negative effects'
        },
        'immune_system': {
            name: '🛡️ Immune System',
            modules: ['spleen', 'bone_marrow', 'blood_vessel'],
            bonus: 225,
            description: "The body's defense force!",
            effect: 'Protects combo from decay'
        },
        
        // Organoid Synergies
        'mini_body': {
            name: '🧫 Mini Body',
            modules: ['brain_organoid', 'heart_organoid', 'liver_organoid'],
            bonus: 350,
            description: 'Three organoids working together!',
            effect: 'Creates perfect harmony bonus'
        },
        'organoid_network': {
            name: '🔗 Organoid Network',
            modules: ['brain_organoid', 'gut_organoid', 'kidney_organoid'],
            bonus: 275,
            description: 'Multi-organ communication!',
            effect: 'Signals travel between all organoids'
        },
        
        // MPS Synergies
        'lab_on_chip': {
            name: '🔬 Lab on a Chip',
            modules: ['organ_chip', 'microfluidic_channel', 'sensor_array'],
            bonus: 400,
            description: 'Complete microfluidic laboratory!',
            effect: 'Analyzes all connected modules'
        },
        'living_factory': {
            name: '🏭 Living Factory',
            modules: ['bioreactor', 'perfusion_system', 'organ_chip'],
            bonus: 375,
            description: 'Self-sustaining bio-production!',
            effect: 'Generates passive points'
        },
        
        // Digital Synergies
        'ai_hospital': {
            name: '🤖 AI Hospital',
            modules: ['digital_twin', 'ai_predictor', 'data_hub'],
            bonus: 500,
            description: 'Full AI medical system!',
            effect: 'Predicts optimal placements'
        },
        'quantum_biology': {
            name: '⚛️ Quantum Biology',
            modules: ['quantum_analyzer', 'digital_twin', 'brain_organoid'],
            bonus: 600,
            description: 'Science fiction becomes reality!',
            effect: 'MEGA bonus to all synergies'
        },
        
        // Cross-Era Synergies (Extra Special!)
        'evolution_of_medicine': {
            name: '🌟 Evolution of Medicine',
            modules: ['heart', 'heart_organoid', 'organ_chip', 'digital_twin'],
            bonus: 750,
            description: 'From real to digital - the full journey!',
            effect: 'ULTIMATE bonus + special animation'
        },
        'kennethS_masterpiece': {
            name: '👨‍🔬 Kenneth\'s Masterpiece',
            modules: ['brain', 'brain_organoid', 'ai_predictor', 'quantum_analyzer'],
            bonus: 1000,
            description: 'Kenneth creates the ultimate brain system!',
            effect: 'LEGENDARY achievement + fireworks!'
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // POWER-UPS - Help Kenneth Succeed!
    // ═══════════════════════════════════════════════════════════════════════
    POWER_UPS: {
        hint: {
            name: 'Hint',
            icon: '💡',
            description: 'Shows the best spot for your next module!',
            startingCount: 3,
            effect: 'highlight_best_cell'
        },
        undo: {
            name: 'Undo',
            icon: '↩️',
            description: 'Take back your last move!',
            startingCount: 5,
            effect: 'remove_last_module'
        },
        boost: {
            name: 'Score Boost',
            icon: '🚀',
            description: 'Next placement gives 3x points!',
            startingCount: 2,
            effect: 'triple_next_score'
        },
        time: {
            name: 'Extra Time',
            icon: '⏰',
            description: 'Adds 30 seconds to the clock!',
            startingCount: 1,
            effect: 'add_30_seconds'
        },
        shuffle: {
            name: 'Shuffle',
            icon: '🔀',
            description: 'Get new modules in your tray!',
            startingCount: 2,
            effect: 'refresh_tray'
        },
        superConnect: {
            name: 'Super Connect',
            icon: '🌟',
            description: 'All ports become Universal for 10 seconds!',
            startingCount: 1,
            effect: 'universal_ports'
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // ACHIEVEMENTS
    // ═══════════════════════════════════════════════════════════════════════
    ACHIEVEMENTS: {
        // Beginner
        'first_placement': {
            name: 'First Steps',
            icon: '👶',
            description: 'Place your first module!',
            xpReward: 25
        },
        'first_connection': {
            name: 'Connected!',
            icon: '🔗',
            description: 'Make your first connection!',
            xpReward: 25
        },
        'first_synergy': {
            name: 'Synergy Master',
            icon: '✨',
            description: 'Create your first synergy!',
            xpReward: 50
        },
        'first_star': {
            name: 'Rising Star',
            icon: '⭐',
            description: 'Earn your first star!',
            xpReward: 30
        },
        'three_stars': {
            name: 'Perfectionist',
            icon: '🌟',
            description: 'Get 3 stars on any level!',
            xpReward: 75
        },
        
        // Progression
        'level_5': {
            name: 'Getting Good!',
            icon: '📈',
            description: 'Reach level 5!',
            xpReward: 100
        },
        'level_10': {
            name: 'Bio-Expert',
            icon: '🎓',
            description: 'Reach level 10!',
            xpReward: 200
        },
        'level_20': {
            name: 'Bio-Master',
            icon: '👑',
            description: 'Reach level 20!',
            xpReward: 500
        },
        
        // Combo
        'combo_3x': {
            name: 'Combo King!',
            icon: '🔥',
            description: 'Reach a 3x combo!',
            xpReward: 50
        },
        'combo_5x': {
            name: 'UNSTOPPABLE!',
            icon: '💥',
            description: 'Reach the maximum 5x combo!',
            xpReward: 150
        },
        
        // Speed
        'speed_demon': {
            name: 'Speed Demon',
            icon: '⚡',
            description: 'Complete a level with 70%+ time remaining!',
            xpReward: 75
        },
        'lightning_fast': {
            name: 'Lightning Fast',
            icon: '🏃',
            description: 'Complete a level in under 30 seconds!',
            xpReward: 200
        },
        
        // Collection
        'collector_10': {
            name: 'Collector',
            icon: '📦',
            description: 'Unlock 10 different modules!',
            xpReward: 50
        },
        'collector_25': {
            name: 'Big Collector',
            icon: '🗄️',
            description: 'Unlock 25 different modules!',
            xpReward: 150
        },
        'collector_all': {
            name: 'Complete Collection',
            icon: '🏆',
            description: 'Unlock ALL modules!',
            xpReward: 500
        },
        
        // Special
        'kennethS_pride': {
            name: "Kenneth's Pride",
            icon: '🧬',
            description: 'Create Kenneth\'s Masterpiece synergy!',
            xpReward: 1000
        },
        'no_hints': {
            name: 'Self-Reliant',
            icon: '🧠',
            description: 'Complete 5 levels without using hints!',
            xpReward: 100
        },
        'perfectionist': {
            name: 'True Perfectionist',
            icon: '💯',
            description: 'Get 3 stars on every level in an era!',
            xpReward: 300
        }
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // STORAGE KEYS
    // ═══════════════════════════════════════════════════════════════════════
    STORAGE: {
        SAVE_DATA: 'kenneth_biotech_save_v2',
        HIGH_SCORE: 'kenneth_biotech_highscore_v2',
        SETTINGS: 'kenneth_biotech_settings_v2',
        ACHIEVEMENTS: 'kenneth_biotech_achievements_v2'
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // COLORS (for JavaScript reference)
    // ═══════════════════════════════════════════════════════════════════════
    COLORS: {
        CYAN: '#00f5ff',
        MAGENTA: '#ff00ff',
        GREEN: '#00ff88',
        GOLD: '#ffd700',
        RED: '#ff4466',
        PURPLE: '#a855f7',
        ORANGE: '#ff8c00',
        BLUE: '#4488ff',
        WHITE: '#ffffff'
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // KENNETH'S TITLE PROGRESSION
    // ═══════════════════════════════════════════════════════════════════════
    TITLES: [
        { level: 1, title: 'Bio-Beginner', emoji: '🌱' },
        { level: 3, title: 'Bio-Learner', emoji: '📚' },
        { level: 5, title: 'Junior Bio-Scientist', emoji: '🔬' },
        { level: 8, title: 'Bio-Scientist', emoji: '🧬' },
        { level: 10, title: 'Senior Bio-Scientist', emoji: '👨‍🔬' },
        { level: 12, title: 'Lab Director', emoji: '🏛️' },
        { level: 15, title: 'Chief Bio-Scientist', emoji: '👔' },
        { level: 18, title: 'Bio-Architect', emoji: '🏗️' },
        { level: 20, title: 'Master Bio-Architect', emoji: '🎓' },
        { level: 25, title: 'LEGENDARY Bio-Master', emoji: '👑' },
        { level: 30, title: 'Kenneth the AMAZING', emoji: '🌟' }
    ],
    
    // ═══════════════════════════════════════════════════════════════════════
    // ENCOURAGEMENT MESSAGES FOR KENNETH - Fun and Exciting!
    // ═══════════════════════════════════════════════════════════════════════
    ENCOURAGEMENT: {
        onModulePlace: [
            "Nice placement, Kenneth! 🎯",
            "BOOM! Great choice! 💥",
            "You're building something EPIC! ✨",
            "Perfect spot, Bio-Genius! 👍",
            "Kenneth strikes again! 🧬",
            "That's the way! AWESOME! 🌟",
            "Science is FUN with Kenneth! 🔬",
            "YESSS! Nailed it! 🎉",
            "Look at you GO! 🚀",
            "Bio-tastic placement! 🧫",
            "Kenneth the BUILDER! 🏗️",
            "Smart move, scientist! 🧠"
        ],
        onConnection: [
            "CONNECTED! Super smart, Kenneth! 🔗",
            "The system is ALIVE! 💪",
            "Excellent work, Scientist! ⚡",
            "You're a GENIUS, Kenneth! 🌟",
            "WHOOOOSH! Connection made! 🚀",
            "Bio-circuits activating! 💫",
            "LINK successful! 🔗✨",
            "Pathways forming! 🛤️",
            "Energy flowing! ⚡⚡",
            "PERFECT CONNECTION! 🎯"
        ],
        onSynergy: [
            "WOW! SUPER SYNERGY! Kenneth is BRILLIANT! ✨✨",
            "INCREDIBLE COMBO, Kenneth! 🎉🎉🎉",
            "MEGA SYNERGY! You found a perfect match! 💫",
            "BOOM BOOM BOOM! That's what I call teamwork! 🔥",
            "UNSTOPPABLE Kenneth! 🏆",
            "SYNERGY MASTER! You're amazing! 🌟🌟",
            "The modules are SINGING together! 🎵",
            "BIO-HARMONY achieved! 🎶",
            "Kenneth discovers MAGIC! ✨🪄"
        ],
        onCombo: [
            "COMBO x2! Keep it going! 🔥",
            "COMBO x3! You're ON FIRE! 🔥🔥",
            "COMBO x4! INCREDIBLE KENNETH! 🔥🔥🔥",
            "COMBO x5! MAXIMUM POWER!! 💥💥💥",
            "UNSTOPPABLE COMBO! 🚀🚀🚀",
            "Kenneth is a COMBO MACHINE! ⚡"
        ],
        onLevelComplete: [
            "MISSION COMPLETE! You're AMAZING, Kenneth! 🎉🎉",
            "YOU DID IT! CHAMPION! 🏆🏆",
            "Kenneth SAVES THE DAY! INCREDIBLE! ⭐⭐",
            "VICTORY! Kenneth is the BEST! 🎊",
            "WOOOHOOO! SPECTACULAR work! 🥳",
            "You're a TRUE Bio-Architect! 👑",
            "LEVEL CLEARED! Super Kenneth! 🌟",
            "Kenneth wins AGAIN! 🎖️",
            "Bio-EXCELLENCE! 🏅"
        ],
        onThreeStars: [
            "THREE STARS!!! PERFECT SCORE!!! 🌟🌟🌟",
            "FLAWLESS VICTORY, Kenneth! 💯💯💯",
            "You're a SUPERSTAR!!! ⭐⭐⭐",
            "ABSOLUTELY PERFECT!!! 🎉🎉🎉",
            "Kenneth the PERFECTIONIST! 👑",
            "LEGENDARY performance! 🏆🌟"
        ],
        onLevelStart: [
            "You've GOT THIS, Kenneth! Let's GO! 💪",
            "Time to build something INCREDIBLE! 🚀",
            "Kenneth is READY FOR ACTION! 🧬",
            "Adventure awaits! Let's DO THIS! 🌟",
            "Kenneth's Lab is OPEN! 🔬",
            "Science hero Kenneth reporting! 🦸",
            "Bio-systems: ACTIVATE! ⚡",
            "Let's make SCIENCE! 🧫",
            "Kenneth enters the LAB! 🏛️"
        ],
        onStruggle: [
            "Take your time, Kenneth! You're doing GREAT! 💙",
            "Every scientist learns step by step! Keep going! 🔬",
            "Don't give up! You're SO CLOSE! 🌟",
            "Scientists never quit! You've got this! 💪",
            "Think like a genius - because you ARE one! 🧠",
            "The best discoveries take time! Keep trying! ✨",
            "You're LEARNING! That's what matters! 📚",
            "One step at a time, Kenneth! 🐾",
            "Believe in yourself! I believe in YOU! 💜"
        ],
        onReturn: [
            "KENNETH IS BACK! Ready to be AWESOME? 🧬",
            "Welcome back, Champion! Let's make SCIENCE! 🔬",
            "The Lab missed you, Kenneth! 🌟",
            "The Bio-Legend returns! 🦸",
            "Kenneth! Your experiments await! 🚀",
            "The lab lights up when you arrive! ✨",
            "Ready for more ADVENTURE? 🎮",
            "Kenneth's back in action! 💪"
        ],
        tips: [
            "💡 Tip: Match port colors for bonus points!",
            "💡 Tip: Create synergies by placing matching organs!",
            "💡 Tip: Keep your combo going for higher scores!",
            "💡 Tip: Use power-ups wisely!",
            "💡 Tip: Connectors can link different systems!",
            "💡 Tip: Some modules work better together!",
            "💡 Tip: Watch for the synergy sparkles!",
            "💡 Tip: Plan your placements for maximum connections!",
            "💡 Tip: Universal ports connect to everything!",
            "💡 Tip: The brain connects to almost anything!"
        ]
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // GAME TIPS (for tutorial and loading screens)
    // ═══════════════════════════════════════════════════════════════════════
    TIPS: [
        "Connect modules with matching port colors for bonus points!",
        "Create synergies by placing related organs together!",
        "The faster you place modules, the higher your combo!",
        "Use the Hint power-up if you're stuck!",
        "Universal (white) ports can connect to ANY color!",
        "Some modules have multiple ports - plan carefully!",
        "Completing synergies gives HUGE bonus points!",
        "Watch for the golden glow when a synergy is possible!",
        "Try to use all your available modules for a bonus!",
        "Connectors are great for bridging different systems!",
        "The brain module has neural ports that power everything!",
        "Hearts pump resources through vascular connections!",
        "Organoids are mini versions of real organs!",
        "MPS systems use microfluidic channels!",
        "Digital twins simulate real biology on computers!"
    ],
    
    // ═══════════════════════════════════════════════════════════════════════
    // PARTICLE EFFECTS CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════════
    PARTICLES: {
        // Background ambient particles
        AMBIENT: {
            count: 50,
            size: { min: 2, max: 6 },
            speed: { min: 0.1, max: 0.5 },
            colors: ['#00f5ff', '#ff00ff', '#00ff88', '#ffd700'],
            opacity: { min: 0.2, max: 0.6 }
        },
        
        // Placement celebration
        PLACEMENT: {
            count: 15,
            size: { min: 4, max: 8 },
            speed: { min: 2, max: 5 },
            lifetime: 600,
            colors: ['#00f5ff', '#ffffff']
        },
        
        // Connection sparks
        CONNECTION: {
            count: 20,
            size: { min: 3, max: 6 },
            speed: { min: 3, max: 7 },
            lifetime: 500,
            colors: ['#00ff88', '#ffd700', '#ffffff']
        },
        
        // Synergy explosion
        SYNERGY: {
            count: 40,
            size: { min: 5, max: 12 },
            speed: { min: 4, max: 10 },
            lifetime: 800,
            colors: ['#ffd700', '#ff00ff', '#00f5ff', '#00ff88']
        },
        
        // Level complete confetti
        CONFETTI: {
            count: 100,
            size: { min: 8, max: 15 },
            speed: { min: 2, max: 6 },
            lifetime: 3000,
            colors: ['#ff4466', '#ffd700', '#00f5ff', '#ff00ff', '#00ff88', '#a855f7']
        },
        
        // Combo fire
        COMBO: {
            count: 30,
            size: { min: 6, max: 10 },
            speed: { min: 5, max: 12 },
            lifetime: 400,
            colors: ['#ff8c00', '#ff4466', '#ffd700']
        }
    },

    // ═══════════════════════════════════════════════════════════════════════
    // LAB BUDDIES - Kenneth's cute science companions! 🐾
    // ═══════════════════════════════════════════════════════════════════════
    LAB_BUDDIES: {
        helix: {
            id: 'helix',
            name: 'Helix',
            emoji: '🐕',
            title: 'The DNA Dog',
            color: '#ff6b6b',
            ability: 'Finds hidden connections!',
            unlockStars: 0,
            phrases: [
                "Woof! Let's do science!",
                "I found a connection!",
                "You're doing great, Kenneth!",
                "Science is ruff-ly awesome!",
                "DNA stands for Dogs Need Adventure!"
            ],
            celebratePhrases: [
                "WOOF WOOF! Amazing!",
                "Who's a good scientist? YOU ARE!",
                "Tail wagging intensifies! 🐕"
            ]
        },
        luna: {
            id: 'luna',
            name: 'Luna',
            emoji: '🐱',
            title: 'The Lab Cat',
            color: '#a855f7',
            ability: 'Slows down time!',
            unlockStars: 0,
            phrases: [
                "Meow! Science is purr-fect!",
                "Take your time, Kenneth!",
                "I believe in mew!",
                "Curiosity made the cat... a scientist!"
            ],
            celebratePhrases: [
                "Purrrfect work!",
                "You're the cat's meow!",
                "*happy cat noises* 🐱"
            ]
        },
        spark: {
            id: 'spark',
            name: 'Spark',
            emoji: '🐭',
            title: 'The Science Mouse',
            color: '#ffd700',
            ability: '+50% bonus points!',
            unlockStars: 10,
            phrases: [
                "Squeak! Let's experiment!",
                "Small but mighty, just like cells!",
                "Cheese... I mean, SCIENCE!"
            ],
            celebratePhrases: [
                "SQUEAK SQUEAK! Amazing!",
                "That was mouse-nificent!"
            ]
        },
        bubbles: {
            id: 'bubbles',
            name: 'Bubbles',
            emoji: '🐠',
            title: 'The Bio-Fish',
            color: '#00f5ff',
            ability: 'Shows helpful hints!',
            unlockStars: 20,
            phrases: [
                "Blub blub! Water you waiting for?",
                "Just keep swimming... through science!",
                "Something's fishy... it's FUN!"
            ],
            celebratePhrases: [
                "O-fish-ally amazing!",
                "*happy bubble sounds* 🫧"
            ]
        },
        nova: {
            id: 'nova',
            name: 'Nova',
            emoji: '🦉',
            title: 'The Neuron Owl',
            color: '#ff8c00',
            ability: 'Brain power boost!',
            unlockStars: 30,
            phrases: [
                "Hoo hoo! Wise choice!",
                "Knowledge is power!",
                "I see connections everywhere!"
            ],
            celebratePhrases: [
                "Hoo knew you were this smart!",
                "Owl-standing work!"
            ]
        },
        chem: {
            id: 'chem',
            name: 'Chem',
            emoji: '🐹',
            title: 'The Chemistry Hamster',
            color: '#00ff88',
            ability: 'Extra module power!',
            unlockStars: 40,
            phrases: [
                "Let's make reactions happen!",
                "Running on my wheel... of science!",
                "Every element matters!"
            ],
            celebratePhrases: [
                "Hamster dance time!",
                "You've got the right formula!"
            ]
        },
        gene: {
            id: 'gene',
            name: 'Gene',
            emoji: '🦎',
            title: 'The Genetics Gecko',
            color: '#4488ff',
            ability: 'Auto-connects once per level!',
            unlockStars: 50,
            phrases: [
                "Sssscience is cool!",
                "I can regrow my tail AND knowledge!",
                "Adapting to any challenge!"
            ],
            celebratePhrases: [
                "Ssssspectacular!",
                "You're scaling new heights!"
            ]
        },
        professor: {
            id: 'professor',
            name: 'Professor P',
            emoji: '🐧',
            title: 'The Ultimate Buddy',
            color: '#ff00ff',
            ability: 'ALL abilities combined!',
            unlockStars: 100,
            phrases: [
                "Waddle we discover today?",
                "Ice to meet you, scientist!",
                "Coolest experiments ever!"
            ],
            celebratePhrases: [
                "Ice-credible work!",
                "You're penguin-ally amazing!"
            ]
        }
    }
});

/**
 * Freeze nested objects for immutability
 */
(function deepFreeze(obj) {
    Object.keys(obj).forEach(key => {
        if (typeof obj[key] === 'object' && obj[key] !== null) {
            deepFreeze(obj[key]);
            Object.freeze(obj[key]);
        }
    });
})(KennethGame.CONSTANTS);

console.log('🧬 Kenneth\'s Biotech Adventure - Constants loaded!');
