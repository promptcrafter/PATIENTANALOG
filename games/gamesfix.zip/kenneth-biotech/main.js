/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - Main Entry Point
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 *     🧬 Welcome to Kenneth's Laboratory! 🧬
 * 
 *     Build incredible bio-systems, discover amazing science,
 *     and become the greatest Bio-Scientist ever!
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

// Initialize namespace
window.KennethGame = window.KennethGame || {};

/**
 * Main Game Controller
 */
KennethGame.Main = (function() {
    
    // State
    let isInitialized = false;
    let loadProgress = 0;
    
    /**
     * Initialize the game
     */
    async function init() {
        console.log('═══════════════════════════════════════════════════════════');
        console.log('🧬 Kenneth\'s AMAZING Biotech Adventure');
        console.log('═══════════════════════════════════════════════════════════');
        
        try {
            // Show loading screen
            updateLoadingProgress(0, 'Initializing...');
            
            // Initialize state management
            updateLoadingProgress(10, 'Loading saved data...');
            if (KennethGame.State) {
                try {
                    KennethGame.State.init();
                } catch (e) {
                    console.warn('State init error (continuing):', e);
                }
            }
            await wait(200);
            
            // Initialize audio system
            updateLoadingProgress(20, 'Setting up audio...');
            if (KennethGame.Audio) {
                try {
                    await KennethGame.Audio.init();
                } catch (e) {
                    console.warn('Audio init error (continuing):', e);
                }
            }
            await wait(200);
            
            // Initialize particle system
            updateLoadingProgress(40, 'Creating particle effects...');
            if (KennethGame.Particles) {
                try {
                    KennethGame.Particles.init();
                } catch (e) {
                    console.warn('Particles init error (continuing):', e);
                }
            }
            await wait(200);
            
            // Initialize renderer
            updateLoadingProgress(55, 'Preparing graphics...');
            if (KennethGame.Renderer) {
                try {
                    KennethGame.Renderer.init();
                } catch (e) {
                    console.warn('Renderer init error (continuing):', e);
                }
            }
            await wait(200);
            
            // Initialize UI controller
            updateLoadingProgress(70, 'Building interface...');
            if (KennethGame.UI) {
                try {
                    KennethGame.UI.init();
                } catch (e) {
                    console.warn('UI init error (continuing):', e);
                }
            }
            await wait(200);
            
            // Initialize game logic
            updateLoadingProgress(85, 'Loading game systems...');
            if (KennethGame.Logic) {
                try {
                    KennethGame.Logic.init();
                } catch (e) {
                    console.warn('Logic init error (continuing):', e);
                }
            }
            await wait(200);
            
            // Apply saved settings
            updateLoadingProgress(95, 'Applying settings...');
            applySettings();
            await wait(200);
            
            // Setup event listeners
            setupGlobalEvents();
            setupNameModal();

            // Complete!
            updateLoadingProgress(100, 'Ready to play!');
            await wait(500);

            isInitialized = true;

            // Hide loading screen explicitly
            const loadingScreen = document.getElementById('loading-screen');
            if (loadingScreen) {
                loadingScreen.classList.remove('active');
            }

            // Check if player has entered their name
            const hasName = KennethGame.State?.hasPlayerName();

            if (!hasName) {
                // First time - show name entry modal
                setTimeout(() => {
                    showNameModal();
                }, 100);
            } else {
                // Update UI with saved player name
                updatePlayerNameUI();

                // Check if tutorial completed
                const settings = KennethGame.State?.getSettings();
                if (!settings?.tutorialCompleted) {
                    // Show tutorial for new players
                    setTimeout(() => {
                        if (KennethGame.UI?.showScreen) {
                            KennethGame.UI.showScreen('tutorial');
                        } else {
                            const menuScreen = document.getElementById('menu-screen');
                            if (menuScreen) menuScreen.classList.add('active');
                        }
                    }, 100);
                } else {
                    // Show menu
                    setTimeout(() => {
                        if (KennethGame.UI?.showScreen) {
                            KennethGame.UI.showScreen('menu');
                        } else {
                            const menuScreen = document.getElementById('menu-screen');
                            if (menuScreen) menuScreen.classList.add('active');
                        }
                        showWelcomeBack();
                    }, 100);
                }
            }
            
            console.log('✅ Game initialized successfully!');
            
        } catch (error) {
            console.error('❌ Game initialization failed:', error);
            // Still try to show menu as fallback
            const loadingScreen = document.getElementById('loading-screen');
            const menuScreen = document.getElementById('menu-screen');
            if (loadingScreen) loadingScreen.classList.remove('active');
            if (menuScreen) menuScreen.classList.add('active');
            showError('Some features may be unavailable. Refresh if issues persist.');
        }
    }
    
    /**
     * Update loading progress
     * @param {number} progress - Progress percentage (0-100)
     * @param {string} message - Loading message
     */
    function updateLoadingProgress(progress, message) {
        loadProgress = progress;
        
        const progressBar = document.getElementById('loading-progress');
        const progressText = document.getElementById('loading-text');
        const progressPercent = document.getElementById('loading-percent');
        
        if (progressBar) {
            progressBar.style.width = `${progress}%`;
        }
        if (progressText) {
            progressText.textContent = message;
        }
        if (progressPercent) {
            progressPercent.textContent = `${progress}%`;
        }
    }
    
    /**
     * Apply saved settings
     */
    function applySettings() {
        const settings = KennethGame.State?.getSettings();
        if (!settings) return;
        
        // High contrast mode
        if (settings.highContrast) {
            document.body.dataset.highContrast = 'true';
        }
        
        // Reduced motion
        if (settings.reducedMotion) {
            document.body.dataset.reducedMotion = 'true';
        }
        
        // Particles
        if (KennethGame.Particles && settings.particles === false) {
            KennethGame.Particles.stopAmbient();
        }
        
        // Audio volumes
        if (KennethGame.Audio) {
            if (settings.musicVolume !== undefined) {
                KennethGame.Audio.setMusicVolume(settings.musicVolume);
            }
            if (settings.sfxVolume !== undefined) {
                KennethGame.Audio.setSFXVolume(settings.sfxVolume);
            }
        }
    }
    
    /**
     * Setup global event listeners
     */
    function setupGlobalEvents() {
        // Handle visibility change (tab switching)
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                // Pause when tab is hidden
                if (KennethGame.Logic?.isPlaying()) {
                    KennethGame.Logic.pause();
                    KennethGame.UI?.pauseGame();
                }
            }
        });
        
        // Handle keyboard shortcuts
        document.addEventListener('keydown', handleKeyPress);
        
        // Handle resize
        window.addEventListener('resize', KennethGame.Utils?.debounce(() => {
            // Reinitialize particles on resize
            if (KennethGame.Particles) {
                KennethGame.Particles.init();
            }
        }, 250));
        
        // Resume audio on first interaction
        document.addEventListener('click', resumeAudio, { once: true });
        document.addEventListener('touchstart', resumeAudio, { once: true });
        document.addEventListener('keydown', resumeAudio, { once: true });
        
        // Prevent context menu on game elements
        document.querySelector('.game-container')?.addEventListener('contextmenu', (e) => {
            e.preventDefault();
        });
    }
    
    /**
     * Handle keyboard shortcuts
     * @param {KeyboardEvent} e
     */
    function handleKeyPress(e) {
        // Don't handle if in input
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        
        const currentScreen = KennethGame.UI?.getCurrentScreen();
        
        switch (e.key) {
            case 'Escape':
                if (currentScreen === 'game') {
                    KennethGame.UI?.pauseGame();
                } else if (currentScreen !== 'menu') {
                    KennethGame.UI?.showScreen('menu');
                }
                break;
                
            case ' ': // Spacebar
                if (currentScreen === 'game' && e.ctrlKey) {
                    e.preventDefault();
                    KennethGame.UI?.pauseGame();
                }
                break;
                
            case 'z':
            case 'Z':
                if (e.ctrlKey && currentScreen === 'game') {
                    e.preventDefault();
                    KennethGame.Logic?.usePowerUp('undo');
                }
                break;
                
            case 'h':
            case 'H':
                if (currentScreen === 'game') {
                    KennethGame.Logic?.usePowerUp('hint');
                }
                break;
        }
    }
    
    /**
     * Resume audio context
     */
    function resumeAudio() {
        if (KennethGame.AudioBridge) {
            KennethGame.AudioBridge.resume();
        }
        if (KennethGame.Audio) {
            KennethGame.Audio.playMotif();
        }
    }
    
    /**
     * Show welcome back message (uses player's name)
     */
    function showWelcomeBack() {
        const playerName = KennethGame.State?.getPlayerName() || 'Scientist';

        const messages = [
            `Welcome back, ${playerName}!`,
            `The lab awaits, ${playerName}!`,
            `Ready for more bio-adventures, ${playerName}?`
        ];

        const message = messages[Math.floor(Math.random() * messages.length)];
        KennethGame.Utils?.showToast(message, 'success');
    }

    /**
     * Show name entry modal for new players
     */
    function showNameModal() {
        const modal = document.getElementById('name-modal');
        if (modal) {
            modal.style.display = 'flex';
            modal.classList.add('active');
            const input = document.getElementById('player-name-input');
            if (input) {
                input.focus();
            }
        }
    }

    /**
     * Setup name modal event handlers
     */
    function setupNameModal() {
        const modal = document.getElementById('name-modal');
        const input = document.getElementById('player-name-input');
        const submitBtn = document.getElementById('submit-name');

        if (submitBtn && input) {
            submitBtn.addEventListener('click', () => {
                const name = input.value.trim();
                if (name) {
                    KennethGame.State?.setPlayerName(name);
                    if (modal) {
                        modal.style.display = 'none';
                        modal.classList.remove('active');
                    }
                    // Update all UI with player name
                    updatePlayerNameUI();
                    KennethGame.Utils?.showToast(`Welcome, ${name}! Let's do science!`, 'success');
                    // Show menu
                    KennethGame.UI?.showScreen('menu');
                }
            });

            // Enter key submits
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    submitBtn.click();
                }
            });
        }
    }

    /**
     * Update all UI elements that show player name
     */
    function updatePlayerNameUI() {
        const playerName = KennethGame.State?.getPlayerName() || 'Scientist';

        // Update menu player name
        const playerNameEl = document.querySelector('.player-name');
        if (playerNameEl) {
            playerNameEl.textContent = playerName;
        }

        // Update game title to show player's name
        const kennethNameEl = document.querySelector('.kenneth-name');
        if (kennethNameEl) {
            kennethNameEl.textContent = `${playerName}'s`;
        }

        // Update loading title
        const titleKennethEl = document.querySelector('.title-kenneth');
        if (titleKennethEl) {
            titleKennethEl.textContent = `${playerName}'s`;
        }

        // Update buddy speech
        const buddySpeech = document.getElementById('buddy-speech');
        if (buddySpeech) {
            buddySpeech.textContent = `Hi ${playerName}! Let's do science!`;
        }

        // Update BOB speech
        const bobSpeech = document.getElementById('bob-speech');
        if (bobSpeech) {
            bobSpeech.textContent = `Hi ${playerName}! 💜`;
        }

        // Update pause message
        const pauseMessage = document.querySelector('.pause-message');
        if (pauseMessage) {
            pauseMessage.textContent = `Take a break, ${playerName}! The lab will wait for you. 🧬`;
        }

        // Update complete title placeholder
        const completeTitle = document.getElementById('complete-title');
        if (completeTitle && completeTitle.textContent.includes('KENNETH')) {
            completeTitle.textContent = completeTitle.textContent.replace(/KENNETH/gi, playerName.toUpperCase());
        }

        // Update failure message
        const failMessage = document.querySelector('.fail-message');
        if (failMessage && failMessage.textContent.includes('Kenneth')) {
            failMessage.textContent = failMessage.textContent.replace(/Kenneth/g, playerName);
        }

        // Update tips panel title
        const tipsTitle = document.querySelector('.panel-title');
        if (tipsTitle && tipsTitle.textContent.includes('Kenneth')) {
            tipsTitle.textContent = tipsTitle.textContent.replace(/Kenneth/g, playerName);
        }

        // Update collection screen title
        const collectionTitle = document.querySelector('#collection-screen .screen-title');
        if (collectionTitle && collectionTitle.textContent.includes('Kenneth')) {
            collectionTitle.textContent = collectionTitle.textContent.replace(/Kenneth/g, playerName);
        }

        // Update lab panel title
        const labTitle = document.querySelector('#kenneth-controls h4');
        if (labTitle && labTitle.textContent.includes('Kenneth')) {
            labTitle.textContent = labTitle.textContent.replace(/Kenneth/g, playerName);
        }

        // Update leaderboard name
        const leaderName = document.getElementById('name-1');
        if (leaderName) {
            leaderName.textContent = playerName;
        }

        console.log(`🎮 UI updated for player: ${playerName}`);
    }

    // Make updatePlayerNameUI globally accessible
    window.updatePlayerNameUI = updatePlayerNameUI;
    
    /**
     * Show error message
     * @param {string} message
     */
    function showError(message) {
        const loading = document.getElementById('loading-screen');
        if (loading) {
            loading.innerHTML = `
                <div class="error-screen">
                    <h2>😢 Oops!</h2>
                    <p>${message}</p>
                    <button onclick="location.reload()">Try Again</button>
                </div>
            `;
        }
    }
    
    /**
     * Wait utility
     * @param {number} ms
     * @returns {Promise}
     */
    function wait(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    /**
     * Check if game is initialized
     * @returns {boolean}
     */
    function isReady() {
        return isInitialized;
    }
    
    /**
     * Get version info
     * @returns {Object}
     */
    function getVersion() {
        return {
            name: "Kenneth's AMAZING Biotech Adventure",
            version: '1.0.0',
            author: 'Made with ❤️ for Kenneth',
            description: 'Build incredible bio-systems and become a Bio-Scientist!'
        };
    }
    
    // Public API
    return {
        init,
        isReady,
        getVersion
    };
})();

// ═══════════════════════════════════════════════════════════════════════════
// START THE GAME!
// ═══════════════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
    console.log('🎮 DOM Ready - Starting game initialization...');
    KennethGame.Main.init();
});

// Also handle if DOM is already loaded
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(() => {
        if (!KennethGame.Main.isReady()) {
            KennethGame.Main.init();
        }
    }, 100);
}

console.log('🧬 Kenneth\'s AMAZING Biotech Adventure - Loaded!');
