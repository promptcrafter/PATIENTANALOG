/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - Tutorial System
 * Interactive step-by-step learning for Kenneth!
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

KennethGame.Tutorial = (function() {
    // Safety check for Utils with fallback functions
    const Utils = KennethGame.Utils || {};
    const $ = Utils.$ || function(id) { return document.getElementById(id); };
    const $$ = Utils.$$ || function(sel, parent) { return (parent || document).querySelector(sel); };
    const createElement = Utils.createElement || function(tag, attrs, children) {
        const el = document.createElement(tag);
        if (attrs) {
            Object.entries(attrs).forEach(([k, v]) => {
                if (k === 'className') el.className = v;
                else if (k === 'textContent') el.textContent = v;
                else if (k === 'innerHTML') el.innerHTML = v;
                else el.setAttribute(k, v);
            });
        }
        if (children) children.forEach(c => {
            if (typeof c === 'string') el.appendChild(document.createTextNode(c));
            else if (c) el.appendChild(c);
        });
        return el;
    };
    const clearElement = Utils.clearElement || function(el) { while(el && el.firstChild) el.removeChild(el.firstChild); };
    
    // Tutorial steps
    const STEPS = [
        {
            title: '👋 Welcome, Kenneth!',
            content: `
                <p>Welcome to your AMAZING Biotech Laboratory!</p>
                <p>In this game, you'll build incredible bio-systems by connecting organs, organoids, and high-tech components!</p>
                <p>Are you ready to become a Bio-Scientist? Let's learn how!</p>
            `,
            image: '🧬',
            highlight: null
        },
        {
            title: '🧩 Bio-Modules',
            content: `
                <p>These are <strong>Bio-Modules</strong> - the building blocks of your systems!</p>
                <p>Each module represents something from biology:</p>
                <ul>
                    <li>🫀 <strong>Organs</strong> - Real body parts like hearts and brains</li>
                    <li>🧫 <strong>Organoids</strong> - Mini organs grown in labs</li>
                    <li>🔬 <strong>MPS</strong> - High-tech organ-on-chip systems</li>
                    <li>🔗 <strong>Connectors</strong> - Link other modules together</li>
                </ul>
            `,
            image: '🧩',
            highlight: 'module-tray'
        },
        {
            title: '🔌 Connection Ports',
            content: `
                <p>Every module has <strong>Connection Ports</strong> - the colored dots on each side!</p>
                <p>Port colors mean different things:</p>
                <ul>
                    <li>🟣 <strong>Neural</strong> - Brain signals</li>
                    <li>🔴 <strong>Vascular</strong> - Blood flow</li>
                    <li>🔵 <strong>Data</strong> - Digital information</li>
                    <li>🟢 <strong>Fluid</strong> - Water and nutrients</li>
                    <li>🟡 <strong>Energy</strong> - Power supply</li>
                    <li>⚪ <strong>Universal</strong> - Connects to ANYTHING!</li>
                </ul>
            `,
            image: '🔌',
            highlight: null
        },
        {
            title: '📍 Placing Modules',
            content: `
                <p>To build your system:</p>
                <ol>
                    <li><strong>Click or drag</strong> a module from the tray at the bottom</li>
                    <li>Move it to an <strong>empty cell</strong> on the grid</li>
                    <li>The cell will <strong>glow green</strong> if it's a valid spot</li>
                    <li><strong>Drop it</strong> to place the module!</li>
                </ol>
                <p>Try to place modules so their ports line up with neighbors!</p>
            `,
            image: '📍',
            highlight: 'game-grid'
        },
        {
            title: '🔗 Making Connections',
            content: `
                <p>When two adjacent modules have <strong>compatible ports</strong>, they automatically connect!</p>
                <p><strong>Matching colors = BONUS POINTS!</strong></p>
                <p>Connections create glowing lines between modules showing the flow of:</p>
                <ul>
                    <li>Blood through vessels 🩸</li>
                    <li>Signals through nerves ⚡</li>
                    <li>Data through computers 💻</li>
                </ul>
            `,
            image: '🔗',
            highlight: null
        },
        {
            title: '✨ Synergies',
            content: `
                <p><strong>Synergies</strong> are special combos when certain modules work together!</p>
                <p>For example:</p>
                <ul>
                    <li>❤️ Heart + 🫁 Lungs + 🔴 Blood Vessel = <strong>Cardiovascular System!</strong></li>
                    <li>🧠 Brain + ⚡ Nerves + 👁️ Eyes = <strong>Nervous System!</strong></li>
                </ul>
                <p>Synergies give you <strong>HUGE bonus points</strong> and cool effects!</p>
                <p>Watch for the <strong>golden sparkles</strong> when you're close to a synergy!</p>
            `,
            image: '✨',
            highlight: null
        },
        {
            title: '🔥 Combos',
            content: `
                <p>Place modules <strong>quickly</strong> to build up your <strong>COMBO</strong> multiplier!</p>
                <p>The combo starts at 1x and can go up to <strong>5x!</strong></p>
                <p>Every point you earn is multiplied by your combo!</p>
                <p>⚠️ But be careful - if you wait too long, your combo resets!</p>
            `,
            image: '🔥',
            highlight: 'combo-indicator'
        },
        {
            title: '⚡ Power-Ups',
            content: `
                <p>Use <strong>Power-Ups</strong> when you need help!</p>
                <ul>
                    <li>💡 <strong>Hint</strong> - Shows the best spot for your next module</li>
                    <li>↩️ <strong>Undo</strong> - Take back your last move</li>
                    <li>🚀 <strong>Boost</strong> - Next placement gives 3x points!</li>
                    <li>⏰ <strong>Extra Time</strong> - Adds 30 seconds to the clock</li>
                </ul>
                <p>You get more power-ups as you level up!</p>
            `,
            image: '⚡',
            highlight: 'power-ups-panel'
        },
        {
            title: '⭐ Stars & Progression',
            content: `
                <p>Complete levels to earn <strong>STARS!</strong></p>
                <ul>
                    <li>⭐ 1 Star - You finished the level!</li>
                    <li>⭐⭐ 2 Stars - Great score!</li>
                    <li>⭐⭐⭐ 3 Stars - PERFECT performance!</li>
                </ul>
                <p>Earn <strong>XP</strong> to level up and unlock:</p>
                <ul>
                    <li>🆕 New modules</li>
                    <li>🗺️ New eras with harder challenges</li>
                    <li>🎖️ Cool titles for Kenneth!</li>
                </ul>
            `,
            image: '⭐',
            highlight: null
        },
        {
            title: '🎮 You\'re Ready!',
            content: `
                <p><strong>That's everything you need to know, Kenneth!</strong></p>
                <p>Remember:</p>
                <ul>
                    <li>🎯 Connect modules with matching ports</li>
                    <li>✨ Look for synergies</li>
                    <li>🔥 Keep your combo going</li>
                    <li>⭐ Aim for 3 stars!</li>
                </ul>
                <p><strong>Most importantly: HAVE FUN!</strong></p>
                <p>You're going to be an AMAZING Bio-Scientist! 🧬🚀</p>
            `,
            image: '🎉',
            highlight: null
        }
    ];
    
    // State
    let currentStep = 0;
    let isActive = false;
    
    /**
     * Start the tutorial
     */
    function start() {
        currentStep = 0;
        isActive = true;
        render();
        updateNavigation();
    }
    
    /**
     * Stop the tutorial
     */
    function stop() {
        isActive = false;
        clearHighlight();
    }
    
    /**
     * Go to specific step
     * @param {number} step
     */
    function goToStep(step) {
        if (step < 0 || step >= STEPS.length) return;
        
        currentStep = step;
        render();
        updateNavigation();
        
        if (KennethGame.Audio) KennethGame.Audio.playClick();
    }
    
    /**
     * Next step
     */
    function next() {
        if (currentStep < STEPS.length - 1) {
            goToStep(currentStep + 1);
        } else {
            finish();
        }
    }
    
    /**
     * Previous step
     */
    function previous() {
        if (currentStep > 0) {
            goToStep(currentStep - 1);
        }
    }
    
    /**
     * Finish tutorial
     */
    function finish() {
        stop();
        
        if (KennethGame.State) {
            KennethGame.State.setSetting('tutorialCompleted', true);
        }
        
        KennethGame.UI?.showScreen('menu');
        KennethGame.Utils?.showToast('You\'re ready to be a Bio-Scientist, Kenneth! 🧬', 'success');
    }
    
    /**
     * Render current step
     */
    function render() {
        const content = $('tutorial-content');
        const stepIndicator = $('tutorial-step');
        const totalIndicator = $('tutorial-total');
        
        if (!content) return;
        
        const step = STEPS[currentStep];
        
        content.innerHTML = `
            <div class="tutorial-step">
                <div class="tutorial-image">${step.image}</div>
                <h2>${step.title}</h2>
                <div class="tutorial-text">${step.content}</div>
            </div>
        `;
        
        if (stepIndicator) stepIndicator.textContent = currentStep + 1;
        if (totalIndicator) totalIndicator.textContent = STEPS.length;
        
        // Update dots
        renderDots();
        
        // Highlight element if specified
        if (step.highlight) {
            highlightElement(step.highlight);
        } else {
            clearHighlight();
        }
    }
    
    /**
     * Render navigation dots
     */
    function renderDots() {
        const dotsContainer = $('tutorial-dots');
        if (!dotsContainer) return;
        
        clearElement(dotsContainer);
        
        for (let i = 0; i < STEPS.length; i++) {
            const dot = createElement('div', {
                className: `tutorial-dot ${i === currentStep ? 'active' : ''}`,
                onClick: () => goToStep(i)
            });
            dotsContainer.appendChild(dot);
        }
    }
    
    /**
     * Update navigation buttons
     */
    function updateNavigation() {
        const prevBtn = $('tutorial-prev');
        const nextBtn = $('tutorial-next');
        
        if (prevBtn) {
            prevBtn.disabled = currentStep === 0;
            prevBtn.onclick = previous;
        }
        
        if (nextBtn) {
            nextBtn.textContent = currentStep === STEPS.length - 1 ? 'Start Playing! 🚀' : 'Next →';
            nextBtn.onclick = next;
        }
    }
    
    /**
     * Highlight an element
     * @param {string} elementId
     */
    function highlightElement(elementId) {
        clearHighlight();
        
        const element = $(elementId);
        if (element) {
            element.classList.add('tutorial-highlight');
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    
    /**
     * Clear all highlights
     */
    function clearHighlight() {
        document.querySelectorAll('.tutorial-highlight').forEach(el => {
            el.classList.remove('tutorial-highlight');
        });
    }
    
    /**
     * Check if tutorial is active
     * @returns {boolean}
     */
    function isRunning() {
        return isActive;
    }
    
    /**
     * Get current step
     * @returns {number}
     */
    function getCurrentStep() {
        return currentStep;
    }
    
    // Public API
    return {
        start,
        stop,
        next,
        previous,
        goToStep,
        finish,
        isRunning,
        getCurrentStep
    };
})();

console.log('📖 Tutorial system loaded!');
