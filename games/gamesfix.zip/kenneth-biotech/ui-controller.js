/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - UI Controller
 * Managing screens, modals, and user interactions!
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

KennethGame.UI = (function() {
    // Safety check for Utils with fallback functions
    const Utils = KennethGame.Utils || {};
    
    // Fallback implementations if Utils not available
    const $ = Utils.$ || function(id) { return document.getElementById(id); };
    const $$ = Utils.$$ || function(sel, parent) { return (parent || document).querySelector(sel); };
    const $$$ = Utils.$$$ || function(sel, parent) { return Array.from((parent || document).querySelectorAll(sel)); };
    const createElement = Utils.createElement || function(tag, attrs, children) {
        const el = document.createElement(tag);
        if (attrs) {
            Object.entries(attrs).forEach(([k, v]) => {
                if (k === 'className') el.className = v;
                else if (k === 'textContent') el.textContent = v;
                else if (k.startsWith('data-')) el.setAttribute(k, v);
                else el.setAttribute(k, v);
            });
        }
        if (children) children.forEach(c => {
            if (typeof c === 'string') el.appendChild(document.createTextNode(c));
            else if (c) el.appendChild(c);
        });
        return el;
    };
    const clearElement = Utils.clearElement || function(el) { while(el && el.firstChild) el.removeChild(el.firstChild); };
    const formatTime = Utils.formatTime || function(s) { return Math.floor(s/60) + ':' + String(Math.floor(s%60)).padStart(2,'0'); };
    const formatNumber = Utils.formatNumber || function(n) { return n.toLocaleString(); };
    const showToast = Utils.showToast || function(msg, type) { console.log('[Toast]', type, msg); };
    const getEncouragement = Utils.getEncouragement || function() { return "Great job, Kenneth!"; };
    
    // State
    let currentScreen = 'loading';
    let currentModal = null;
    let timerInterval = null;
    
    /**
     * Initialize the UI controller
     */
    function init() {
        try {
            setupMenuButtons();
            console.log('✓ Menu buttons setup');
        } catch (e) {
            console.error('✗ Menu buttons failed:', e);
        }

        try {
            setupGameButtons();
            console.log('✓ Game buttons setup');
        } catch (e) {
            console.error('✗ Game buttons failed:', e);
        }

        try {
            setupModals();
            console.log('✓ Modals setup');
        } catch (e) {
            console.error('✗ Modals failed:', e);
        }

        try {
            setupSettings();
            console.log('✓ Settings setup');
        } catch (e) {
            console.error('✗ Settings failed:', e);
        }

        try {
            setupFilterButtons();
            console.log('✓ Filter buttons setup');
        } catch (e) {
            console.error('✗ Filter buttons failed:', e);
        }

        try {
            setupEraTabsClick();
            console.log('✓ Era tabs setup');
        } catch (e) {
            console.error('✗ Era tabs failed:', e);
        }

        console.log('🎮 UI Controller initialized!');
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // SCREEN MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════
    
    /**
     * Show a screen
     * @param {string} screenId - Screen ID (menu, game, levels, collection, settings, tutorial)
     */
    function showScreen(screenId) {
        // Hide all screens
        $$$('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        
        // Show target screen
        const screen = $(`${screenId}-screen`);
        if (screen) {
            screen.classList.add('active');
            currentScreen = screenId;
            
            // Screen-specific initialization
            switch (screenId) {
                case 'menu':
                    updateMenuStats();
                    break;
                case 'levels':
                    renderLevelsScreen();
                    break;
                case 'collection':
                    renderCollectionScreen();
                    break;
                case 'tutorial':
                    if (KennethGame.Tutorial) {
                        KennethGame.Tutorial.start();
                    }
                    break;
            }
        }
    }
    
    /**
     * Get current screen
     * @returns {string}
     */
    function getCurrentScreen() {
        return currentScreen;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // MENU SCREEN
    // ═══════════════════════════════════════════════════════════════════════
    
    function setupMenuButtons() {
        // Play button
        const btnPlay = $('btn-play');
        if (btnPlay) {
            btnPlay.addEventListener('click', () => {
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                
                // Continue from last level or start fresh
                const player = KennethGame.State?.getPlayer();
                if (player?.currentLevel) {
                    startLevel(player.currentLevel);
                } else {
                    startLevel('1-1');
                }
            });
        }
        
        // Level select
        const btnLevels = $('btn-levels');
        if (btnLevels) {
            btnLevels.addEventListener('click', () => {
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                showScreen('levels');
            });
        }
        
        // Sandbox mode
        const btnSandbox = $('btn-sandbox');
        if (btnSandbox) {
            btnSandbox.addEventListener('click', () => {
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                startSandbox();
            });
        }
        
        // Collection
        const btnCollection = $('btn-collection');
        if (btnCollection) {
            btnCollection.addEventListener('click', () => {
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                showScreen('collection');
            });
        }
        
        // Tutorial
        const btnTutorial = $('btn-tutorial');
        if (btnTutorial) {
            btnTutorial.addEventListener('click', () => {
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                showScreen('tutorial');
            });
        }
        
        // Settings
        const btnSettings = $('btn-settings');
        if (btnSettings) {
            btnSettings.addEventListener('click', () => {
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                showScreen('settings');
            });
        }
        
        // Back buttons
        $$$('[data-action="back-to-menu"]').forEach(btn => {
            btn.addEventListener('click', () => {
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                showScreen('menu');
            });
        });
    }
    
    /**
     * Update menu screen stats
     */
    function updateMenuStats() {
        const player = KennethGame.State?.getPlayer();
        if (!player) return;
        
        // Level badge
        const levelBadge = $('menu-level-badge');
        if (levelBadge) levelBadge.textContent = player.level;
        
        // Title
        const title = $('menu-player-title');
        if (title) title.textContent = player.title;
        
        // XP bar
        const xpFill = $('menu-xp-fill');
        if (xpFill) {
            const progress = player.xp / player.xpToNextLevel;
            xpFill.style.width = `${progress * 100}%`;
        }
        
        // Stars
        const totalStars = $('menu-total-stars');
        if (totalStars) totalStars.textContent = player.totalStars;
        
        // High score
        const highScore = $('menu-high-score');
        if (highScore) highScore.textContent = formatNumber(player.highScore);
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // LEVELS SCREEN
    // ═══════════════════════════════════════════════════════════════════════
    
    function setupEraTabsClick() {
        $$$('.era-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const eraId = parseInt(tab.dataset.era);
                selectEra(eraId);
            });
        });
    }
    
    function selectEra(eraId) {
        const player = KennethGame.State?.getPlayer();
        const era = KennethGame.Levels?.getEra(eraId);
        
        if (!era) return;
        
        // Check if era is unlocked
        const isUnlocked = KennethGame.Levels.isEraUnlocked(eraId, player?.level || 1);
        
        if (!isUnlocked) {
            showToast(`Reach level ${era.unlockLevel} to unlock ${era.name}!`, 'warning');
            return;
        }
        
        // Update tabs
        $$$('.era-tab').forEach(tab => {
            tab.classList.toggle('active', parseInt(tab.dataset.era) === eraId);
        });
        
        // Render levels
        renderLevelsGrid(eraId);
    }
    
    function renderLevelsScreen() {
        const player = KennethGame.State?.getPlayer();
        
        // Update era tab states
        $$$('.era-tab').forEach(tab => {
            const eraId = parseInt(tab.dataset.era);
            const isUnlocked = KennethGame.Levels?.isEraUnlocked(eraId, player?.level || 1);
            
            tab.classList.toggle('locked', !isUnlocked);
            const lockIcon = $$('.lock-icon', tab);
            if (lockIcon) lockIcon.style.display = isUnlocked ? 'none' : 'inline';
        });
        
        // Render first unlocked era
        renderLevelsGrid(1);
    }
    
    function renderLevelsGrid(eraId) {
        const grid = $('levels-grid');
        if (!grid) return;
        
        clearElement(grid);
        
        const levels = KennethGame.Levels?.getLevelsByEra(eraId) || [];
        const player = KennethGame.State?.getPlayer();
        
        levels.forEach(level => {
            const stars = player?.completedLevels?.[level.id]?.stars || 0;
            const isCompleted = stars > 0;
            const isUnlocked = isLevelUnlocked(level.id);
            
            const card = createElement('div', {
                className: `level-card ${isCompleted ? 'completed' : ''} ${!isUnlocked ? 'locked' : ''}`,
                'data-level-id': level.id
            });
            
            // Level number
            card.appendChild(createElement('div', {
                className: 'level-number',
                textContent: level.id
            }));
            
            // Level name
            card.appendChild(createElement('div', {
                className: 'level-name',
                textContent: level.name
            }));
            
            // Stars
            const starsEl = createElement('div', { className: 'level-stars' });
            for (let i = 1; i <= 3; i++) {
                starsEl.appendChild(createElement('span', {
                    className: `star ${i <= stars ? 'earned' : ''}`,
                    textContent: '⭐'
                }));
            }
            card.appendChild(starsEl);
            
            // Lock icon
            if (!isUnlocked) {
                card.appendChild(createElement('div', {
                    className: 'level-lock',
                    textContent: '🔒'
                }));
            }
            
            // Click handler
            card.addEventListener('click', () => {
                if (!isUnlocked) {
                    showToast('Complete the previous level first!', 'warning');
                    return;
                }
                
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                startLevel(level.id);
            });
            
            grid.appendChild(card);
        });
    }
    
    function isLevelUnlocked(levelId) {
        const player = KennethGame.State?.getPlayer();
        if (!player) return levelId === '1-1';
        
        // First level always unlocked
        if (levelId === '1-1') return true;
        
        // Check if previous level has at least 1 star
        const prevLevelId = getPreviousLevelId(levelId);
        if (prevLevelId) {
            return (player.completedLevels?.[prevLevelId]?.stars || 0) > 0;
        }
        
        return false;
    }
    
    function getPreviousLevelId(levelId) {
        const allEras = KennethGame.Levels?.getAllEras() || [];
        let prevLevel = null;
        
        for (const era of allEras) {
            for (const level of era.levels) {
                if (level.id === levelId) return prevLevel;
                prevLevel = level.id;
            }
        }
        
        return null;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // COLLECTION SCREEN
    // ═══════════════════════════════════════════════════════════════════════
    
    function renderCollectionScreen() {
        const grid = $('collection-grid');
        if (!grid) return;
        
        clearElement(grid);
        
        const allModules = KennethGame.Modules?.getAll() || [];
        const player = KennethGame.State?.getPlayer();
        const unlocked = player?.unlockedModules || ['heart', 'brain', 'blood_vessel', 'nerve_connector'];
        
        // Update counts
        const countEl = $('collection-count');
        const totalEl = $('collection-total');
        if (countEl) countEl.textContent = unlocked.length;
        if (totalEl) totalEl.textContent = allModules.length;
        
        // Render modules
        allModules.forEach(module => {
            const isUnlocked = unlocked.includes(module.id);
            
            const card = createElement('div', {
                className: `collection-card ${!isUnlocked ? 'locked' : ''}`,
                'data-module-id': module.id
            });
            
            card.appendChild(createElement('div', {
                className: 'module-icon',
                textContent: isUnlocked ? module.icon : '❓'
            }));
            
            card.appendChild(createElement('div', {
                className: 'module-name',
                textContent: isUnlocked ? module.name : '???'
            }));
            
            card.appendChild(createElement('div', {
                className: 'module-category',
                textContent: module.category
            }));
            
            if (isUnlocked) {
                card.addEventListener('click', () => {
                    showModuleDetail(module);
                });
            }
            
            grid.appendChild(card);
        });
    }
    
    function showModuleDetail(module) {
        const modal = $('module-detail-modal');
        const content = $('module-detail-content');
        
        if (!modal || !content) return;
        
        content.innerHTML = `
            <div class="module-detail-header">
                <span class="detail-icon">${module.icon}</span>
                <h2>${module.name}</h2>
                <span class="detail-tier tier-${module.tier}">${KennethGame.CONSTANTS.TIERS[Object.keys(KennethGame.CONSTANTS.TIERS)[module.tier - 1]]?.name || 'Basic'}</span>
            </div>
            <p class="detail-description">${module.description}</p>
            <div class="detail-funfact">
                <span class="funfact-icon">💡</span>
                <p>${module.funFact}</p>
            </div>
            <div class="detail-science">
                <span class="science-icon">🔬</span>
                <p>${module.scienceNote}</p>
            </div>
            <div class="detail-ports">
                <h3>Connection Ports</h3>
                <div class="ports-list">
                    ${Object.entries(module.ports || {}).map(([dir, type]) => `
                        <div class="port-item">
                            <span class="port-direction">${dir}</span>
                            <span class="port-type ${type}">${type}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        
        modal.classList.add('active');
        
        $('close-module-detail')?.addEventListener('click', () => {
            modal.classList.remove('active');
        }, { once: true });
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // GAME SCREEN
    // ═══════════════════════════════════════════════════════════════════════
    
    function setupGameButtons() {
        // Pause button
        const btnPause = $('btn-pause');
        if (btnPause) {
            btnPause.addEventListener('click', () => {
                if (KennethGame.Audio) KennethGame.Audio.playClick();
                pauseGame();
            });
        }
        
        // Power-up buttons
        $$$('.power-up-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const power = btn.dataset.power;
                if (KennethGame.Logic) {
                    KennethGame.Logic.usePowerUp(power);
                }
            });
        });
    }
    
    function setupFilterButtons() {
        $$$('.filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const filter = btn.dataset.filter;
                
                // Update active state
                $$$('.filter-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                // Filter modules
                filterModuleTray(filter);
            });
        });
    }
    
    function filterModuleTray(filter) {
        $$$('.module-card', $('module-tray')).forEach(card => {
            const moduleId = card.dataset.moduleId;
            const module = KennethGame.Modules?.getById(moduleId);
            
            if (!module) return;
            
            const show = filter === 'all' || module.category === filter;
            card.style.display = show ? '' : 'none';
        });
    }
    
    /**
     * Start a level
     * @param {string} levelId
     */
    function startLevel(levelId) {
        showScreen('game');
        
        if (KennethGame.Logic) {
            KennethGame.Logic.startLevel(levelId);
        }
        
        // Show encouragement
        showToast(getEncouragement('onLevelStart'), 'success');
    }
    
    /**
     * Start sandbox mode
     */
    function startSandbox() {
        showScreen('game');
        
        if (KennethGame.Logic) {
            KennethGame.Logic.startSandbox();
        }
        
        showToast('🔬 Free Build mode! Create anything you want!', 'info');
    }
    
    /**
     * Update game header display
     * @param {Object} data - Game state data
     */
    function updateGameHeader(data) {
        // Level name
        const levelName = $('game-level-name');
        const levelSubtitle = $('game-level-subtitle');
        if (levelName) levelName.textContent = data.levelName || 'Sandbox';
        if (levelSubtitle) levelSubtitle.textContent = data.levelSubtitle || '';
        
        // Score
        const scoreEl = $('game-score');
        if (scoreEl) scoreEl.textContent = formatNumber(data.score || 0);
        
        // Target
        const targetEl = $('game-target');
        if (targetEl) targetEl.textContent = formatNumber(data.target || 0);
        
        // Combo
        updateCombo(data.combo || 1);
    }
    
    /**
     * Update timer display
     * @param {number} seconds - Remaining seconds
     * @param {number} totalSeconds - Total seconds
     */
    function updateTimer(seconds, totalSeconds) {
        const timerValue = $('game-timer');
        const timerFill = $('timer-fill');
        const timerContainer = $('timer-container');
        
        if (timerValue) timerValue.textContent = formatTime(seconds);
        
        if (timerFill) {
            const progress = seconds / totalSeconds;
            timerFill.style.width = `${progress * 100}%`;
        }
        
        if (timerContainer) {
            timerContainer.classList.remove('warning', 'critical');
            if (seconds <= 30) {
                timerContainer.classList.add('critical');
            } else if (seconds <= 60) {
                timerContainer.classList.add('warning');
            }
        }
    }
    
    /**
     * Update combo display
     * @param {number} combo
     */
    function updateCombo(combo) {
        const indicator = $('combo-indicator');
        const value = $('combo-value');
        
        if (!indicator || !value) return;
        
        if (combo > 1) {
            indicator.classList.add('active');
            value.textContent = `x${combo.toFixed(1)}`;
            
            // Fire effect for high combo
            if (combo >= 2 && KennethGame.Particles) {
                const rect = indicator.getBoundingClientRect();
                KennethGame.Particles.comboFire(rect.left + rect.width / 2, rect.top, combo / 5);
            }
        } else {
            indicator.classList.remove('active');
        }
    }
    
    /**
     * Update objectives list
     * @param {Array} objectives
     */
    function updateObjectives(objectives) {
        const list = $('objectives-list');
        if (!list) return;
        
        clearElement(list);
        
        objectives.forEach(obj => {
            const item = createElement('li', {
                className: `objective-item ${obj.completed ? 'completed' : ''}`
            });
            
            item.appendChild(createElement('span', {
                textContent: `${obj.description} (${obj.current}/${obj.target})`
            }));
            
            list.appendChild(item);
        });
    }
    
    /**
     * Update current tip
     * @param {string} tip
     */
    function updateTip(tip) {
        const tipContent = $('current-tip');
        if (tipContent) {
            tipContent.innerHTML = `<p>${tip}</p>`;
        }
    }
    
    /**
     * Show score popup at position
     * @param {number} x
     * @param {number} y
     * @param {number} score
     */
    function showScorePopup(x, y, score) {
        const prefix = score > 0 ? '+' : '';
        const color = score > 0 ? '#ffd700' : '#ff4466';
        
        if (KennethGame.Particles) {
            KennethGame.Particles.scorePopup(x, y, `${prefix}${score}`, color);
        }
    }
    
    /**
     * Show feedback message
     * @param {string} message
     */
    function showFeedback(message) {
        const area = $('feedback-area');
        if (!area) return;
        
        const feedback = createElement('div', {
            className: 'feedback-message',
            textContent: message
        });
        
        clearElement(area);
        area.appendChild(feedback);
        
        setTimeout(() => feedback.remove(), 2000);
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // MODALS
    // ═══════════════════════════════════════════════════════════════════════
    
    function setupModals() {
        // Pause modal
        $('resume-game')?.addEventListener('click', () => {
            hideModal('pause-modal');
            if (KennethGame.Logic) KennethGame.Logic.resume();
        });
        
        $('restart-level')?.addEventListener('click', () => {
            hideModal('pause-modal');
            if (KennethGame.Logic) KennethGame.Logic.restart();
        });
        
        $('quit-to-menu')?.addEventListener('click', () => {
            hideModal('pause-modal');
            if (KennethGame.Logic) KennethGame.Logic.quit();
            showScreen('menu');
        });
        
        // Complete modal
        $('complete-menu')?.addEventListener('click', () => {
            hideModal('complete-modal');
            showScreen('menu');
        });
        
        $('complete-retry')?.addEventListener('click', () => {
            hideModal('complete-modal');
            if (KennethGame.Logic) KennethGame.Logic.restart();
        });
        
        $('complete-next')?.addEventListener('click', () => {
            hideModal('complete-modal');
            if (KennethGame.Logic) {
                const nextLevel = KennethGame.Logic.getNextLevel();
                if (nextLevel) {
                    startLevel(nextLevel);
                } else {
                    showScreen('menu');
                    showToast('Congratulations! You\'ve completed all levels!', 'success');
                }
            }
        });
        
        // Game over modal
        $('gameover-menu')?.addEventListener('click', () => {
            hideModal('gameover-modal');
            showScreen('menu');
        });
        
        $('gameover-retry')?.addEventListener('click', () => {
            hideModal('gameover-modal');
            if (KennethGame.Logic) KennethGame.Logic.restart();
        });
    }
    
    /**
     * Show modal
     * @param {string} modalId
     */
    function showModal(modalId) {
        const modal = $(modalId);
        if (modal) {
            modal.classList.add('active');
            currentModal = modalId;
        }
    }
    
    /**
     * Hide modal
     * @param {string} modalId
     */
    function hideModal(modalId) {
        const modal = $(modalId);
        if (modal) {
            modal.classList.remove('active');
            currentModal = null;
        }
    }
    
    /**
     * Pause the game
     */
    function pauseGame() {
        if (KennethGame.Logic) KennethGame.Logic.pause();
        
        const pauseScore = $('pause-score');
        const pauseTime = $('pause-time');
        
        if (pauseScore && KennethGame.Logic) {
            pauseScore.textContent = formatNumber(KennethGame.Logic.getScore());
        }
        if (pauseTime && KennethGame.Logic) {
            pauseTime.textContent = formatTime(KennethGame.Logic.getTimeLeft());
        }
        
        showModal('pause-modal');
    }
    
    /**
     * Show level complete modal
     * @param {Object} results
     */
    function showLevelComplete(results) {
        const titleEl = $('complete-title');
        const messageEl = $('complete-message');
        const finalScore = $('final-score');
        const finalConnections = $('final-connections');
        const finalSynergies = $('final-synergies');
        const finalTimeBonus = $('final-time-bonus');
        const xpEarned = $('xp-earned');
        const xpFill = $('xp-fill-reward');
        
        // Set stars
        const starsDisplay = $('stars-display');
        if (starsDisplay) {
            $$$('.star', starsDisplay).forEach((star, i) => {
                setTimeout(() => {
                    star.classList.toggle('earned', i < results.stars);
                }, 200 + i * 200);
            });
        }
        
        // Set title based on stars
        const titles = [
            "Good try, Kenneth!",
            "Nice work, Kenneth! ⭐",
            "Great job, Kenneth! ⭐⭐",
            "AMAZING, KENNETH! ⭐⭐⭐"
        ];
        if (titleEl) titleEl.textContent = titles[results.stars] || titles[0];
        
        // Message
        if (messageEl) {
            messageEl.textContent = results.stars >= 3 
                ? getEncouragement('onThreeStars')
                : getEncouragement('onLevelComplete');
        }
        
        // Stats
        if (finalScore) finalScore.textContent = formatNumber(results.score);
        if (finalConnections) finalConnections.textContent = results.connections;
        if (finalSynergies) finalSynergies.textContent = results.synergies;
        if (finalTimeBonus) finalTimeBonus.textContent = '+' + formatNumber(results.timeBonus);
        if (xpEarned) xpEarned.textContent = results.xpEarned;
        
        // XP bar animation
        if (xpFill) {
            xpFill.style.width = '0%';
            setTimeout(() => {
                xpFill.style.width = `${results.xpProgress * 100}%`;
            }, 500);
        }
        
        // Confetti!
        if (results.stars >= 2 && KennethGame.Particles) {
            KennethGame.Particles.confetti(results.stars >= 3 ? 5000 : 3000);
        }
        
        // Play sounds
        if (KennethGame.Audio) {
            KennethGame.Audio.playSuccess();
            if (results.stars >= 3) {
                setTimeout(() => KennethGame.Audio.playFanfare(), 500);
            }
        }
        
        showModal('complete-modal');
    }
    
    /**
     * Show game over modal
     * @param {Object} results
     */
    function showGameOver(results) {
        const scoreEl = $('gameover-score');
        const targetEl = $('gameover-target');
        const tipEl = $('gameover-tip');
        
        if (scoreEl) scoreEl.textContent = formatNumber(results.score);
        if (targetEl) targetEl.textContent = formatNumber(results.target);
        if (tipEl) tipEl.textContent = KennethGame.Utils.getRandomTip();
        
        showModal('gameover-modal');
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // SETTINGS
    // ═══════════════════════════════════════════════════════════════════════
    
    function setupSettings() {
        // Volume controls
        const musicVolume = $('music-volume');
        const sfxVolume = $('sfx-volume');
        
        if (musicVolume) {
            musicVolume.addEventListener('input', (e) => {
                const value = e.target.value / 100;
                if (KennethGame.Audio) KennethGame.Audio.setMusicVolume(value);
                e.target.nextElementSibling.textContent = `${e.target.value}%`;
            });
        }
        
        if (sfxVolume) {
            sfxVolume.addEventListener('input', (e) => {
                const value = e.target.value / 100;
                if (KennethGame.Audio) KennethGame.Audio.setSFXVolume(value);
                e.target.nextElementSibling.textContent = `${e.target.value}%`;
            });
        }
        
        // Toggle settings
        const particlesToggle = $('particles-toggle');
        if (particlesToggle) {
            particlesToggle.addEventListener('change', (e) => {
                if (KennethGame.Particles) {
                    KennethGame.Particles.setEnabled(e.target.checked);
                }
                KennethGame.State?.setSetting('particles', e.target.checked);
            });
        }
        
        const shakeToggle = $('shake-toggle');
        if (shakeToggle) {
            shakeToggle.addEventListener('change', (e) => {
                KennethGame.State?.setSetting('screenShake', e.target.checked);
            });
        }
        
        const contrastToggle = $('contrast-toggle');
        if (contrastToggle) {
            contrastToggle.addEventListener('change', (e) => {
                document.body.dataset.highContrast = e.target.checked;
                KennethGame.State?.setSetting('highContrast', e.target.checked);
            });
        }
        
        const motionToggle = $('motion-toggle');
        if (motionToggle) {
            motionToggle.addEventListener('change', (e) => {
                document.body.dataset.reducedMotion = e.target.checked;
                KennethGame.State?.setSetting('reducedMotion', e.target.checked);
            });
        }
        
        // Reset progress
        const resetBtn = $('reset-progress');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                if (confirm('Are you sure you want to reset ALL progress? This cannot be undone!')) {
                    KennethGame.State?.reset();
                    showToast('Progress has been reset', 'info');
                    showScreen('menu');
                }
            });
        }
    }
    
    // Public API
    return {
        init,
        showScreen,
        getCurrentScreen,
        updateMenuStats,
        startLevel,
        startSandbox,
        updateGameHeader,
        updateTimer,
        updateCombo,
        updateObjectives,
        updateTip,
        showScorePopup,
        showFeedback,
        showModal,
        hideModal,
        pauseGame,
        showLevelComplete,
        showGameOver
    };
})();
