/**
 * ═══════════════════════════════════════════════════════════════════════════
 * Kenneth's AMAZING Biotech Adventure - State Management
 * Tracks Kenneth's progress, XP, achievements, and unlocks!
 * ═══════════════════════════════════════════════════════════════════════════
 */

'use strict';

KennethGame.State = (function() {
    
    const CONSTANTS = KennethGame.CONSTANTS;
    
    // Default player state
    const DEFAULT_PLAYER = {
        name: 'Kenneth',
        level: 1,
        xp: 0,
        totalXpEarned: 0,
        
        // Progress
        currentEra: 1,
        unlockedEras: [1],
        completedLevels: {},  // { levelId: { stars, highScore, bestTime } }
        
        // Stats
        totalScore: 0,
        highScore: 0,
        totalConnections: 0,
        totalSynergies: 0,
        totalModulesPlaced: 0,
        levelsCompleted: 0,
        perfectLevels: 0, // 3-star levels
        
        // Unlocked modules
        unlockedModules: ['heart', 'brain', 'lung', 'liver', 'kidney', 'blood_vessel', 'nerve_connector'],
        
        // Achievements
        achievements: [],
        
        // Power-ups inventory
        powerUps: {
            hint: 3,
            undo: 5,
            boost: 2,
            time: 1,
            shuffle: 2,
            superConnect: 1
        },
        
        // Settings synced with state
        hintsUsedThisSession: 0,
        noHintStreak: 0,

        // Lab Buddies 🐾
        activeBuddy: 'helix',
        treats: 10,
        buddies: {
            helix: { unlocked: true, level: 1, xp: 0, happiness: 3 },
            luna: { unlocked: true, level: 1, xp: 0, happiness: 3 },
            spark: { unlocked: false, level: 1, xp: 0, happiness: 3 },
            bubbles: { unlocked: false, level: 1, xp: 0, happiness: 3 },
            nova: { unlocked: false, level: 1, xp: 0, happiness: 3 },
            chem: { unlocked: false, level: 1, xp: 0, happiness: 3 },
            gene: { unlocked: false, level: 1, xp: 0, happiness: 3 },
            professor: { unlocked: false, level: 1, xp: 0, happiness: 3 }
        },

        // Timestamps
        firstPlayDate: null,
        lastPlayDate: null,
        totalPlayTime: 0
    };
    
    let player = null;
    let settings = null;
    let useLocalStorage = true;
    
    // ═══════════════════════════════════════════════════════════════════════
    // INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════
    
    function init(options = {}) {
        useLocalStorage = options.useLocalStorage !== false;
        
        // Load saved state or create new
        player = load() || createNewPlayer();
        settings = loadSettings();
        
        // Update last play date
        player.lastPlayDate = new Date().toISOString();
        if (!player.firstPlayDate) {
            player.firstPlayDate = player.lastPlayDate;
        }
        
        // Ensure all default modules are unlocked
        DEFAULT_PLAYER.unlockedModules.forEach(moduleId => {
            if (!player.unlockedModules.includes(moduleId)) {
                player.unlockedModules.push(moduleId);
            }
        });
        
        save();
        console.log('📊 State initialized for Kenneth!', player);
    }
    
    function createNewPlayer() {
        return JSON.parse(JSON.stringify(DEFAULT_PLAYER));
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // SAVE & LOAD
    // ═══════════════════════════════════════════════════════════════════════
    
    function save() {
        if (!useLocalStorage) return;
        
        try {
            localStorage.setItem(CONSTANTS.STORAGE.SAVE_DATA, JSON.stringify(player));
            // High score persists even on reset
            localStorage.setItem(CONSTANTS.STORAGE.HIGH_SCORE, player.highScore.toString());
        } catch (e) {
            console.warn('Failed to save state:', e);
        }
    }
    
    function load() {
        if (!useLocalStorage) return null;
        
        try {
            const data = localStorage.getItem(CONSTANTS.STORAGE.SAVE_DATA);
            if (data) {
                const loaded = JSON.parse(data);
                // Merge with defaults to ensure all fields exist
                return { ...createNewPlayer(), ...loaded };
            }
        } catch (e) {
            console.warn('Failed to load state:', e);
        }
        return null;
    }
    
    function loadSettings() {
        if (!useLocalStorage) return getDefaultSettings();
        
        try {
            const data = localStorage.getItem(CONSTANTS.STORAGE.SETTINGS);
            return data ? JSON.parse(data) : getDefaultSettings();
        } catch (e) {
            return getDefaultSettings();
        }
    }
    
    function saveSettings() {
        if (!useLocalStorage) return;
        
        try {
            localStorage.setItem(CONSTANTS.STORAGE.SETTINGS, JSON.stringify(settings));
        } catch (e) {
            console.warn('Failed to save settings:', e);
        }
    }
    
    function getDefaultSettings() {
        return {
            musicVolume: 70,
            sfxVolume: 80,
            particlesEnabled: true,
            screenShakeEnabled: true,
            highContrast: false,
            reducedMotion: false,
            showHints: true,
            autoRotateModules: true,
            tutorialCompleted: false
        };
    }
    
    function reset() {
        const permanentHighScore = player.highScore;
        player = createNewPlayer();
        player.highScore = permanentHighScore;
        save();
        console.log('🔄 Kenneth\'s progress reset!');
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // XP & LEVELING
    // ═══════════════════════════════════════════════════════════════════════
    
    function getXpForLevel(level) {
        return Math.floor(CONSTANTS.PROGRESSION.BASE_XP * 
            Math.pow(CONSTANTS.PROGRESSION.LEVEL_XP_MULTIPLIER, level - 1));
    }
    
    function getXpProgress() {
        const currentLevelXp = getXpForLevel(player.level);
        const nextLevelXp = getXpForLevel(player.level + 1);
        const xpInCurrentLevel = player.xp;
        const xpNeeded = nextLevelXp - currentLevelXp;
        return {
            current: xpInCurrentLevel,
            needed: xpNeeded,
            percent: Math.min(100, (xpInCurrentLevel / xpNeeded) * 100)
        };
    }
    
    function addXP(amount) {
        const oldLevel = player.level;
        player.xp += amount;
        player.totalXpEarned += amount;
        
        // Check for level up
        while (player.xp >= getXpForLevel(player.level + 1) - getXpForLevel(player.level)) {
            player.xp -= getXpForLevel(player.level + 1) - getXpForLevel(player.level);
            player.level++;
            
            // Check for module unlocks
            checkModuleUnlocks();
            
            // Check for era unlocks
            checkEraUnlocks();
        }
        
        save();
        
        return {
            amount,
            levelUp: player.level > oldLevel,
            newLevel: player.level,
            oldLevel
        };
    }
    
    function checkModuleUnlocks() {
        const unlockLevels = CONSTANTS.PROGRESSION.MODULE_UNLOCK_LEVELS;
        
        Object.entries(unlockLevels).forEach(([moduleId, reqLevel]) => {
            if (player.level >= reqLevel && !player.unlockedModules.includes(moduleId)) {
                player.unlockedModules.push(moduleId);
                console.log(`🔓 Kenneth unlocked: ${moduleId}!`);
            }
        });
    }
    
    function checkEraUnlocks() {
        const thresholds = CONSTANTS.PROGRESSION.UNLOCK_THRESHOLDS;
        
        if (player.level >= thresholds.ERA_2 && !player.unlockedEras.includes(2)) {
            player.unlockedEras.push(2);
            console.log('🔓 Era 2 unlocked!');
        }
        if (player.level >= thresholds.ERA_3 && !player.unlockedEras.includes(3)) {
            player.unlockedEras.push(3);
            console.log('🔓 Era 3 unlocked!');
        }
        if (player.level >= thresholds.ERA_4 && !player.unlockedEras.includes(4)) {
            player.unlockedEras.push(4);
            console.log('🔓 Era 4 unlocked!');
        }
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // LEVEL COMPLETION
    // ═══════════════════════════════════════════════════════════════════════
    
    function completeLevel(levelId, score, stars, timeRemaining, stats = {}) {
        const isNewLevel = !player.completedLevels[levelId];
        const previousBest = player.completedLevels[levelId] || { stars: 0, highScore: 0 };
        
        // Update level record
        player.completedLevels[levelId] = {
            stars: Math.max(previousBest.stars, stars),
            highScore: Math.max(previousBest.highScore, score),
            bestTime: previousBest.bestTime 
                ? Math.max(previousBest.bestTime, timeRemaining) 
                : timeRemaining,
            completedAt: new Date().toISOString()
        };
        
        // Update global stats
        player.totalScore += score;
        if (score > player.highScore) {
            player.highScore = score;
        }
        player.totalConnections += stats.connections || 0;
        player.totalSynergies += stats.synergies || 0;
        player.totalModulesPlaced += stats.modulesPlaced || 0;
        
        if (isNewLevel) {
            player.levelsCompleted++;
        }
        
        if (stars === 3 && previousBest.stars < 3) {
            player.perfectLevels++;
        }
        
        // Calculate XP earned
        let xpEarned = CONSTANTS.PROGRESSION.XP_FOR_COMPLETION;
        xpEarned += stars * CONSTANTS.PROGRESSION.XP_PER_STAR;
        
        if (isNewLevel) {
            xpEarned += 50; // Bonus for first completion
        }
        
        if (score > previousBest.highScore) {
            xpEarned += CONSTANTS.PROGRESSION.XP_FOR_NEW_HIGH_SCORE;
        }
        
        const xpResult = addXP(xpEarned);
        
        // Check achievements
        const newAchievements = checkAchievements();
        
        save();
        
        return {
            xpEarned,
            levelUp: xpResult.levelUp,
            newLevel: xpResult.newLevel,
            newAchievements,
            isNewRecord: score > previousBest.highScore,
            isNewLevel,
            newStars: stars > previousBest.stars ? stars - previousBest.stars : 0
        };
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // ACHIEVEMENTS
    // ═══════════════════════════════════════════════════════════════════════
    
    function checkAchievements() {
        const newAchievements = [];
        const achievements = CONSTANTS.ACHIEVEMENTS;
        
        // Check each achievement
        Object.entries(achievements).forEach(([id, achievement]) => {
            if (player.achievements.includes(id)) return;
            
            let earned = false;
            
            switch (id) {
                case 'first_placement':
                    earned = player.totalModulesPlaced >= 1;
                    break;
                case 'first_connection':
                    earned = player.totalConnections >= 1;
                    break;
                case 'first_synergy':
                    earned = player.totalSynergies >= 1;
                    break;
                case 'first_star':
                    earned = Object.values(player.completedLevels).some(l => l.stars >= 1);
                    break;
                case 'three_stars':
                    earned = player.perfectLevels >= 1;
                    break;
                case 'level_5':
                    earned = player.level >= 5;
                    break;
                case 'level_10':
                    earned = player.level >= 10;
                    break;
                case 'level_20':
                    earned = player.level >= 20;
                    break;
                case 'collector_10':
                    earned = player.unlockedModules.length >= 10;
                    break;
                case 'collector_25':
                    earned = player.unlockedModules.length >= 25;
                    break;
                case 'collector_all':
                    earned = player.unlockedModules.length >= (KennethGame.Modules?.getTotalCount?.() || 50);
                    break;
            }
            
            if (earned) {
                player.achievements.push(id);
                newAchievements.push({ id, ...achievement });
                console.log(`🏆 Achievement unlocked: ${achievement.name}!`);
            }
        });
        
        return newAchievements;
    }
    
    function hasAchievement(id) {
        return player.achievements.includes(id);
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // MODULES & UNLOCKS
    // ═══════════════════════════════════════════════════════════════════════
    
    function isModuleUnlocked(moduleId) {
        return player.unlockedModules.includes(moduleId);
    }
    
    function unlockModule(moduleId) {
        if (!player.unlockedModules.includes(moduleId)) {
            player.unlockedModules.push(moduleId);
            save();
            return true;
        }
        return false;
    }
    
    function getUnlockedModules() {
        return player.unlockedModules;
    }
    
    function isEraUnlocked(eraId) {
        return player.unlockedEras.includes(eraId);
    }
    
    function isLevelUnlocked(levelId) {
        const level = KennethGame.Levels.getLevel(levelId);
        if (!level) return false;
        
        // First level of each era is unlocked if era is unlocked
        const era = level.era;
        if (!isEraUnlocked(era.id)) return false;
        
        const levelIndex = era.levels.findIndex(l => l.id === levelId);
        
        // First level always available
        if (levelIndex === 0) return true;
        
        // Subsequent levels require previous level completed
        const previousLevel = era.levels[levelIndex - 1];
        return !!player.completedLevels[previousLevel.id];
    }
    
    function getLevelProgress(levelId) {
        return player.completedLevels[levelId] || null;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // POWER-UPS
    // ═══════════════════════════════════════════════════════════════════════
    
    function usePowerUp(type) {
        if (player.powerUps[type] > 0) {
            player.powerUps[type]--;
            save();
            return true;
        }
        return false;
    }
    
    function addPowerUp(type, count = 1) {
        player.powerUps[type] = (player.powerUps[type] || 0) + count;
        save();
    }
    
    function getPowerUpCount(type) {
        return player.powerUps[type] || 0;
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // TITLE & ENCOURAGEMENT
    // ═══════════════════════════════════════════════════════════════════════
    
    function getTitle() {
        const titles = CONSTANTS.TITLES;
        let currentTitle = titles[0];
        
        for (const title of titles) {
            if (player.level >= title.level) {
                currentTitle = title;
            }
        }
        
        return `${currentTitle.emoji} ${currentTitle.title}`;
    }
    
    function getEncouragement(type) {
        const messages = CONSTANTS.ENCOURAGEMENT[type];
        if (!messages || messages.length === 0) return '';
        return messages[Math.floor(Math.random() * messages.length)];
    }
    
    // ═══════════════════════════════════════════════════════════════════════
    // GETTERS & SETTERS
    // ═══════════════════════════════════════════════════════════════════════
    
    function getPlayer() {
        return { 
            ...player,
            title: getTitle(),
            totalStars: getTotalStars(),
            xpToNextLevel: getXpForLevel(player.level + 1)
        };
    }
    
    function getSettings() {
        return { ...settings };
    }
    
    function updateSettings(newSettings) {
        settings = { ...settings, ...newSettings };
        saveSettings();
        return settings;
    }

    function setSetting(key, value) {
        settings[key] = value;
        saveSettings();
        return settings;
    }

    function getTotalStars() {
        return Object.values(player.completedLevels).reduce((sum, l) => sum + l.stars, 0);
    }
    
    function exportState() {
        return {
            player: getPlayer(),
            settings: getSettings()
        };
    }

    // ═══════════════════════════════════════════════════════════════════════
    // LAB BUDDIES 🐾
    // ═══════════════════════════════════════════════════════════════════════

    function getActiveBuddy() {
        const buddyId = player.activeBuddy;
        const buddyData = CONSTANTS.LAB_BUDDIES[buddyId];
        const buddyState = player.buddies[buddyId];
        return { ...buddyData, ...buddyState };
    }

    function selectBuddy(buddyId) {
        if (player.buddies[buddyId]?.unlocked) {
            player.activeBuddy = buddyId;
            save();
            return true;
        }
        return false;
    }

    function feedBuddy() {
        if (player.treats <= 0) return false;

        const buddy = player.buddies[player.activeBuddy];
        player.treats--;
        buddy.happiness = Math.min(5, buddy.happiness + 1);
        buddy.xp += 10;

        // Level up buddy
        if (buddy.xp >= 100) {
            buddy.xp -= 100;
            buddy.level++;
        }

        save();
        return true;
    }

    function petBuddy() {
        const buddy = player.buddies[player.activeBuddy];
        buddy.xp += 5;

        // Level up buddy
        if (buddy.xp >= 100) {
            buddy.xp -= 100;
            buddy.level++;
        }

        save();
        return true;
    }

    function addTreats(amount) {
        player.treats += amount;
        save();
    }

    function getTreats() {
        return player.treats;
    }

    function checkBuddyUnlocks() {
        const totalStars = getTotalStars();
        const buddies = CONSTANTS.LAB_BUDDIES;
        const newUnlocks = [];

        Object.keys(buddies).forEach(buddyId => {
            if (!player.buddies[buddyId].unlocked && totalStars >= buddies[buddyId].unlockStars) {
                player.buddies[buddyId].unlocked = true;
                newUnlocks.push(buddyId);
            }
        });

        if (newUnlocks.length > 0) {
            save();
        }
        return newUnlocks;
    }

    function getBuddyPhrase(type = 'phrases') {
        const buddyId = player.activeBuddy;
        const buddyData = CONSTANTS.LAB_BUDDIES[buddyId];
        const phrases = buddyData[type] || buddyData.phrases;
        return phrases[Math.floor(Math.random() * phrases.length)];
    }

    function getAllBuddies() {
        const buddies = CONSTANTS.LAB_BUDDIES;
        return Object.keys(buddies).map(id => ({
            ...buddies[id],
            ...player.buddies[id]
        }));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // PLAYER NAME SYSTEM
    // ═══════════════════════════════════════════════════════════════════════

    function getPlayerName() {
        return player?.name || 'Scientist';
    }

    function setPlayerName(name) {
        if (player && name && name.trim()) {
            player.name = name.trim();
            save();
            console.log(`👋 Welcome, ${player.name}!`);
        }
    }

    function hasPlayerName() {
        // Check if player has set a custom name (not the default)
        return player?.name && player.name !== 'Kenneth' && player.name.trim() !== '';
    }

    return {
        init,
        save,
        reset,
        getPlayer,
        getSettings,
        updateSettings,
        setSetting,
        getXpForLevel,
        getXpProgress,
        addXP,
        completeLevel,
        checkAchievements,
        hasAchievement,
        isModuleUnlocked,
        unlockModule,
        getUnlockedModules,
        isEraUnlocked,
        isLevelUnlocked,
        getLevelProgress,
        usePowerUp,
        addPowerUp,
        getPowerUpCount,
        getTitle,
        getEncouragement,
        getTotalStars,
        exportState,
        // Lab Buddies
        getActiveBuddy,
        selectBuddy,
        feedBuddy,
        petBuddy,
        addTreats,
        getTreats,
        checkBuddyUnlocks,
        getBuddyPhrase,
        getAllBuddies,
        // Player Name
        getPlayerName,
        setPlayerName,
        hasPlayerName
    };
})();
